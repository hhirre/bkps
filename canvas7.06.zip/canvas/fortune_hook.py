#!/usr/bin/env python
##ImmunityHeader v1 
###############################################################################
## File       :  fortune_hook.py
## Description:  (mis)fortunes exception hook
##            :  
## Created_On :  Mon Mar 22 15:44:35 2010
## Created_By :  Rich
## Modified_On:  Mon Mar 22 16:27:13 2010
## Modified_By:  Rich
##
## (c) Copyright 2010, Immunity, Inc. all rights reserved.
###############################################################################

import random
import traceback

class MisFortuneHook:
    """
    Exception hook to show a (mis)fortune upon an unhandled exception
    USAGE:
          mfh = MisFortuneHook()
          sys.excepthook = mfh
    """
    def __init__(self, fortune="misfortunes.txt", canvas = True):
        
        try:
            f = open(fortune, "r")
            self.f_list = f.readlines()
            f.close()
        except:
            self.f_list = []
        
        random.shuffle(self.f_list)
        
        self.f_index = 0
        
        self.canvas = canvas
        
        
    def __call__(self, exc_type, value, tb):
        """
        Append a fortune to the traceback
        """
        traceback.print_exception(exc_type, value, tb)
        
        try:
            fortune = self.f_list[self.f_index]
            if self.canvas:
                fortune = fortune.replace("&", "\n")
            
            if fortune:
                print "\n\n==Traceback (mis)fortune==\n\n%s"%( fortune )
                self.f_index += 1
        except:
            pass
        
        
if __name__ == "__main__":
    
    print "Testing exception hook"

    mfh = MisFortuneHook()
    
    import sys
    sys.excepthook = mfh
    
    print "Raising exception......"
    hjkhk
    
    