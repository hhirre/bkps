"""
(c) Immunity, Inc. 2004-2007


U{Immunity Inc.<http://www.immunityinc.com>}

calltree.py - graph an ID calltree list
"""

__VERSION__ = "0.1"

import sys
if "." not in sys.path: sys.path.append(".")

import immlib
import immvcglib

DESC = "Graph a call tree"

### main ###

def usage(imm):
    imm.Log("!calltree address")

def main(args):
    imm = immlib.Debugger()

    if not args:
        return "Error - no <address> argument"

    # init call tree graphing class
    from immvcglib import graphTree
    
    callGraph = graphTree(int(args[0], 16), imm)

    # go ahead and graph it out ...        
    callGraph.graphCallTree()    
