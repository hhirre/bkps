#!/usr/bin/env python

"""
Graph helper

This includes an abstraction class that will encapsulate the things needed
for both the "debugger" and "gtk" to do drawing properly.

I.E. We need to start windows, draw boxes, maybe even respond to events!

A primary component is logging and error display.
"""


win32_ImmDrawColors = {"Black":0,"Maroon":128,"Green":32768,"Olive":32896,"Navy":8388608,"Purple":8388736,"Teal":8421376,\
                       "Gray":8421504,"Silver":12632256,"Red":255,"Lime":65280,"Yellow":65535,"Blue":16711680,"Fuchsia":16711935,\
                       "Aqua":16776960,"LightGray":12632256,"DarkGray":8421504,"White":16777215,"MoneyGreen":12639424,\
                       "SkyBlue":15780518,"Cream":15793151,"MedGray":10789024,"red":255,"darkgreen":32768}

ImmDrawColors = {} 

class graphhelper(object):
    def __init__(self, logger , gui):
        self.logger=logger
        self.gui=gui #overall GUI
        self.window=None  #our specific window
        return 
    
    def Creategraphwindow(self, title, address=None):
        """
        Create the window on the screen
        """

    def Gettextsize(self, handler, line):
        """
        return the pixel size of a line as a tuple
        """
        #stub
        return (1,1) 
    
    def Drawtext(self, handler, x, y, msg, color):
        """
        Draws text in our buffer - returns x,y of how big it was.
        """
        #stub
        return (1,1)
    
    def Drawline(self, handler, x, y, x2, y2, color, start=False):
        """
        Draws a line in our graph
        """
        
        return 

    def set_window(self, window):
        """
        Our internal actual GUI window
        """
        self.window=window 
        return 
    
    
#if fail, then we cannot proceed!
import goocanvas

class gtk_graph_helper(graphhelper):
    """
    Our gtk version. This requires pyGooCanvas to be installed!
    """
    def __init__(self, logger=None , gui=None):
        """
        logger == None means use print
        gui == None means use a new GTK window
        """
        graphhelper.__init__(self, logger, gui)
        return 
    
    def Gettextsize(self, handler, line):
        """
        Draws it, then gets how big it would be
        """
        
        item= goocanvas.Text(text=line)
        extents=item.get_natural_extents()
        
        width = float(extents[1][2])/1000.0
        height = float(extents[1][3])/1000.0
        print "Gettextsize %s = %d,%d"%(line,width,height)
        
        return width,height
        
    def Drawtext(self, handler, x, y, msg, color):
        """
        Draws text on our screen. Returns text height and width as a tuple.
        """
        print "Drawing text(%d,%d) (color=%s): %s"%(x,y,color,msg)
        item = goocanvas.Text(parent=self.root, x=x, y=y, text=msg, stroke_color=color)
        extents=item.get_natural_extents()
        #print "Extents=%r"%(extents,)
        #extents is tuple of 4 tuples
        
        width = float(extents[1][2])/1000.0
        height = float(extents[1][3])/1000.0
        print "Text size: %d, %d"%(width,height)
        return height,width
        
    def Drawline(self, handler, x, y, x2, y2, color, start=False):
        """
        Draws a line in our graph
        """
        print "Drawline(%s): %d,%d -> %d,%d"%(color, x,y,x2,y2)
        points=goocanvas.Points([(x,y),(x2,y2)])
        goocanvas.Polyline(parent=self.root, points=points,line_width=1.0, stroke_color=color)
        return 
    
    def DrawRect(self, x, y, width, height, color):
        """
        Draws a rectangle.
        If you have a fill color, you will not currently see text in that box (it will overwrite it since we draw this second)
        """
        print "Drawing a rectangle: Color=%s"%color
        rect=goocanvas.Rect(parent=self.root, x=x, y=y, width=width, height=height, radius_x=7, radius_y=7, stroke_color=color)
        return 