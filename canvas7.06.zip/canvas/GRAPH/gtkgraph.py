#!/usr/bin/env python
"""
gtkgraph.py 

This will display a window and allow you to view a simple .vcg file or a .pkl
of a graph structure.

"""
import sys
if "." not in sys.path: sys.path.append(".")

import immvcglib

def usage():
    print "gtkgraph.py filename"
    sys.exit(1)

def main():
    """
    Display the window, load the graph file, and display that within.
    """
    if len(sys.argv)!=2:
        usage()

    filename=sys.argv[1]
    print "Loading %s"%filename
    data=file(filename).read()
    if not data:
        print "No data in file?"
        return False
    
    #now initialize gtk
    import pygtk
    import gtk, gobject
    import gtk.glade
    import goocanvas
    glade_filename="graph.glade"
    graph_tree=gtk.glade.XML(glade_filename,"window1")
    main_window=graph_tree.get_widget("window1")
    main_window.connect("destroy",gtk.main_quit)
    canvas=goocanvas.Canvas()
    parent=graph_tree.get_widget("scrolledwindow1")
    parent.add(canvas)
    root=canvas.get_root_item()
    canvas.set_size_request(300,300)
    canvas.set_bounds(0,0,8000,8000)
    
    main_window.show_all()
    
    from graphhelper import gtk_graph_helper
    helper = gtk_graph_helper()
    helper.set_window(canvas)
    helper.root=root
    #read it all in and generate the graph
    g = immvcglib.generateGraphFromBuf(data, helper)
    print "Generated graph!"
    gtk.main()
    return True

if __name__=="__main__":
    main() 