from datetime import datetime
from turbogears.database import PackageHub
from sqlobject import *
from turbogears import identity

hub = PackageHub('immunitysafewebui')
__connection__ = hub

class Config(SQLObject):
    """Container for global config knobs, name: value pairs."""
    name=StringCol(alternateID=True)
    value=StringCol(default="")

class Target(SQLObject):
    name = UnicodeCol()
    organisation = ForeignKey("Organisation")
    include = StringCol(default="")
    exclude = StringCol(default="")
    scanSpecs = RelatedJoin("ScanSpec")
    adHoc = BoolCol(default=False)

class ScanSpec(SQLObject):
    """A scan specifier - an instance of a scan template for a given customer's targets, with a schedule for when to run it, and 
    potentially many scan instances, one for each time this scan has run. 
    """
    name = UnicodeCol()
    organisation = ForeignKey("Organisation")
    targets = RelatedJoin("Target")
    scanTemplate = ForeignKey("ScanTemplate")
    time = StringCol(default=None)
    schedule = EnumCol(enumValues=["Ad-Hoc", "Scheduled", "Recurring"], default="Scheduled")    
    instances = MultipleJoin("ScanInstance")
    enabled = BoolCol(default=True)
    deleted = BoolCol(default=False)

class ScanTemplate(SQLObject):
    """A scan template stores a set of default options for running a scan, such as "Aggressive" or "Assessment only" or some other 
    sort of variation. Needs to store all the config options that will be required to make it so, so details here left until we 
    actually implement the scanner engine"""
    name = StringCol(notNone = True)
    description = UnicodeCol(default = "")
    scanSpecs = MultipleJoin("ScanSpec")
    # If user is None, it's a global template, if there is a user, it's a customised one, only for that user.
    organisation = ForeignKey("Organisation", default=None)
    # Scan option details go here :)
    defaultOptions = RelatedJoin("ScanTemplateOption", addRemoveName="DefaultOption")
    optionValues = MultipleJoin("ScanTemplateOptionValue")
    
class ScanTemplateOption(SQLObject):
    """Stores options for a scan template. These relate directly to a template when default, and once
    edited/applied to a user template, via ScanTemplateOptionValue, which stores the non-default value"""
    name = StringCol()
    description = UnicodeCol()
    defaultValue = UnicodeCol()
    defaultTemplates = RelatedJoin("ScanTemplate")
    type = EnumCol(default="string", enumValues=["string", "ip", "iprange", "enum", "number", "bool"])
    # opaque, up to the code that validates to interpret
    validatorData = StringCol(default=None)
    values = MultipleJoin("ScanTemplateOptionValues")

class ScanTemplateOptionValue(SQLObject):
    scanTemplate = ForeignKey("ScanTemplate")
    scanTemplateOption = ForeignKey("ScanTemplateOption")
    value = StringCol()

    
class ScanInstance(SQLObject):
    """Created for each instance of a scan - these could be scheduled, or if no schedule, then are ad-hoc once off scans
    """
    class sqlmeta:
        cacheValues = False
        
    scanSpec = ForeignKey("ScanSpec")
    report = SingleJoin("Report")
    status = MultipleJoin("ScanStatus")
    state = EnumCol(enumValues = ["Scheduled", "Starting", "Running", "Failed", "Complete"], default="Scheduled")
    lastChange = DateTimeCol(default=datetime.now)
    
class ScanStatus(SQLObject):
    """Stores status messages for a scan. Probably the result of logging from the CANVAS engine
    """
    class sqlmeta:
        cacheValues = False
        
    details = UnicodeCol()
    time = DateTimeCol(default = datetime.now)
    scanInstance = ForeignKey("ScanInstance")
        
class Report(SQLObject):
    
    class sqlmeta:
        cacheValues = False
        
    name = UnicodeCol()
    created = DateTimeCol(default = datetime.now)
    scanInstance = ForeignKey("ScanInstance")
    # So whats' in a report? :(

class NewsItem(SQLObject):
    title = UnicodeCol()
    text = UnicodeCol(default="")
    created = DateTimeCol(default = datetime.now)
    deleted = BoolCol(default=False)
    url = UnicodeCol(default=None)
    author = ForeignKey("User")

# identity models.
class Visit(SQLObject):
    """
    A visit to your site
    """
    class sqlmeta:
        table = 'visit'

    visit_key = StringCol(length=40, alternateID=True,
                          alternateMethodName='by_visit_key')
    created = DateTimeCol(default=datetime.now)
    expiry = DateTimeCol()

    def lookup_visit(cls, visit_key):
        try:
            return cls.by_visit_key(visit_key)
        except SQLObjectNotFound:
            return None
    lookup_visit = classmethod(lookup_visit)


class VisitIdentity(SQLObject):
    """
    A Visit that is link to a User object
    """
    visit_key = StringCol(length=40, alternateID=True,
                          alternateMethodName='by_visit_key')
    user_id = IntCol()


class Group(SQLObject):
    """
    An ultra-simple group definition.
    """
    # names like "Group", "Order" and "User" are reserved words in SQL
    # so we set the name to something safe for SQL
    class sqlmeta:
        table = 'tg_group'

    group_name = UnicodeCol(length=16, alternateID=True,
                            alternateMethodName='by_group_name')
    display_name = UnicodeCol(length=255)
    created = DateTimeCol(default=datetime.now)

    # collection of all users belonging to this group
    users = RelatedJoin('User', intermediateTable='user_group',
                        joinColumn='group_id', otherColumn='user_id')

    # collection of all permissions for this group
    permissions = RelatedJoin('Permission', joinColumn='group_id',
                              intermediateTable='group_permission',
                              otherColumn='permission_id')


class Organisation(SQLObject):
    """A customer or organisation. Each user must belong to one only.
    """
    name = UnicodeCol(length=64, alternateID=True)
    deleted = BoolCol(default = False)
    users = MultipleJoin("User")
    targets = MultipleJoin("Target")
    scanSpecs = MultipleJoin("ScanSpec")

class User(SQLObject):
    """
    Reasonably basic User definition.
    Probably would want additional attributes.3
    """
    # names like "Group", "Order" and "User" are reserved words in SQL
    # so we set the name to something safe for SQL
    class sqlmeta:
        table = 'tg_user'

    user_name = UnicodeCol(length=16, alternateID=True,
                           alternateMethodName='by_user_name')
    email_address = UnicodeCol(length=255,default= "")
    display_name = UnicodeCol(length=255,default = "New User")
    password = UnicodeCol(length=40, default="")
    created = DateTimeCol(default=datetime.now)
    deleted = BoolCol(default = False)
    organisation = ForeignKey("Organisation", default=None)
    newsItems = MultipleJoin("NewsItem")

    # groups this user belongs to
    groups = RelatedJoin('Group', intermediateTable='user_group',
                         joinColumn='user_id', otherColumn='group_id')

    def _get_permissions(self):
        perms = set()
        for g in self.groups:
            perms = perms | set(g.permissions)
        return perms

    def _set_password(self, cleartext_password):
        "Runs cleartext_password through the hash algorithm before saving."
        password_hash = identity.encrypt_password(cleartext_password)
        self._SO_set_password(password_hash)

    def set_password_raw(self, password):
        "Saves the password as-is to the database."
        self._SO_set_password(password)


class Permission(SQLObject):
    """
    A relationship that determines what each Group can do
    """
    permission_name = UnicodeCol(length=16, alternateID=True,
                                 alternateMethodName='by_permission_name')
    description = UnicodeCol(length=255)

    groups = RelatedJoin('Group',
                         intermediateTable='group_permission',
                         joinColumn='permission_id',
                         otherColumn='group_id')
