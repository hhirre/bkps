from turbogears import widgets, validators
import turbogears
import formencode
from model import *
from cherrypy import request
import copy


# Grr. So, afaict, the is_validated method in InputWidget doesn't actually work.
# It checks that the validated_form of request is the same as the first widget's form
# for reasons that are not immediately apparent. Anyway, I can't actually ever get
# it to return true, even when it looks like the test should pass to me (eg, when
# __repr__(validated_form) == __repr__(form), form is validated_form == False :(
# So uh, in the spirit of everyone's favorite german pythonista, we monkey patch the 
# class. I love python, and I hate turbogears so very much right now. 
def monkeypatch_get_is_validated(self):
    #print "Grr, monkeypatching, ooo-ooo-ooo"
    if self.path:
        validated_form = getattr(request, "validated_form", None)
        if validated_form:
            return True
        else:
            return False
    else:
        return False
    
widgets.InputWidget.is_validated = property(monkeypatch_get_is_validated)

def monkeypatch_is_option_selected(self, option_value, value):
    try:
        value = self.validator.from_python(value)
    except validators.Invalid, info:
        #print "Got exception: %s" % info
        return False
    if value is not None:
        if self._multiple_selection:
            if option_value in value:
                return True
        else:
            #print "%s == %s? %s" % (option_value, value, option_value == value)
            if option_value == value:
                return True
    return False

widgets.SelectionField._is_option_selected = monkeypatch_is_option_selected


class LimitedNumber(validators.FancyValidator):
    """Validator that checks that it's a number, and that the number returns true when passed to callable val"""
    def __init__(self, val, fail_msg, **kwargs):
        self.valFunc = val
        self.fail_msg = fail_msg
        super(LimitedNumber, self).__init__(**kwargs)
        
    def to_python(self, value, state=None):
        z = validators.Number()
        v = z.to_python(value, state)
        if self.valFunc(v):
            return v
        else:
            raise validators.Invalid(self.fail_msg, value, state)


class CIDR(validators.FancyValidator):
    """
    Formencode validator to check whether a string is in correct CIDR
    notation (IP address, or IP address plus /mask)
    """
    messages = {
            'not_cidr_format' : u'Please enter a valid IP address (a.b.c.d) or IP network (a.b.c.d/e)',
            'illegal_octets' : u'The octets must be within the range of 0-255 (not %(octet)r)',
            'illegal_bits' : u'The network size (bits) must be within the range of 8-32 (not %(bits)r)',
            }

    def validate_python(self, value, state):
        print "In CIDR.validate_python, called with %s" % value
        try:
            # Split into octets and bits
            if '/' in value: # a.b.c.d/e
                addr, bits = value.split('/')
            else: # a.b.c.d
                addr, bits = value, 32

            octets = addr.split('.')

            # Only 4 octets?
            if len(octets) != 4:
                raise validators.Invalid(self.message("not_cidr_format", state, value=value), value, state)

            # Correct octets?
            for octet in octets:
                if int(octet) < 0 or int(octet) > 255:
                    raise validators.Invalid(self.message("illegal_octets", state, octet=octet), value, state)

            # Bits (netmask) correct?
            if int(bits) < 8 or int(bits) > 32:
                    raise validators.Invalid(self.message("illegal_bits", state, bits=bits), value, state)

        # Splitting faild: wrong syntax
        except ValueError:
            raise validators.Invalid(self.message("not_cidr_format", state), value, state)

# The packaged formencode in ubuntu/gutsy lacks the CIDR validator.
if not hasattr(validators, "CIDR"):
    validators.CIDR = CIDR
    
class IPAddrRange(validators.FancyValidator):
    def to_python(self, value, state=None):
        strVal = validators.String()
        cidrVal = validators.CIDR()
        csvVal = CommaListValidator()
        rv = []
        value = strVal.to_python(value)
        value = csvVal.to_python(value)
        print "In IPAddrRange: value: %s" % value
        for i,v in enumerate(value):
            try :
                i = cidrVal.to_python(v)
                rv.append(i)
            except validators.Invalid, info:
                raise validators.Invalid("Error validating address element %d: %s. %s" % (i, v, info), v, state)
            
        return rv

class IDValidator(validators.FancyValidator):
    def __init__(self, dbClass, **kwargs):
        self.dbClass = dbClass
        super(IDValidator, self).__init__(**kwargs)
        
    def to_python(self, value, state=None):
        print "Validing ID: %s" % value

        vi = validators.Int(not_empty=True)
        id = vi.to_python(value)
        try:
            x = self.dbClass.get(id)
            print "IdValidator returning: %s" % x
            return x
        except SQLObjectNotFound:
            raise validators.Invalid('No such %s' % self.dbClass.__name__, value, state)
    
    def from_python(self, value, state=None):
        if isinstance(value, self.dbClass):
            return value.id
        else:
            raise validators.Invalid('Called from_python with %s, not a %s' % (value, self.dbClass), value, None)
        
class SameOrUnique(validators.FancyValidator):
    
    def to_python(self, value, state=None):
        print "Hai, state: %s" % state
        x = self.dbClass.select(self.query == value)
        if x.count() != 0:
            if self.match(state) == value:
                return value
            else:
                raise validators.Invalid("Duplicate value", value, state)
        else:
            return value

class SameOrg(validators.FormValidator):
    def validate_python(self, value, state):
        if identity.in_group("uberAdmins"):
            return
        
        if identity.current.user.organisation == value["u"].organisation:
            return
        
        raise validators.Invalid("User is not from same organisation", value, state)

class IdentityValidator(validators.FormValidator):
    def validate_python(self, value, state):
        if self.condition():
            return
        
        raise validators.Invalid("User failed identity validator", value, state)

class CommaListValidator(validators.FancyValidator):
    def to_python(self, value, state=None):
        print "in CommaListValidator value: %s" % value
        if isinstance(value, basestring):
            x = value.split(",")
        elif isinstance(value, list):
            x = value
        else:
            raise validators.Invalid("CommaList validator failed")
        return x

class Help(widgets.FormField):
    "Form help"

    template = """
    <p xmlns:py="http://purl.org/kid/ns#"
        id="${field_id}"
        class="${field_class}"
        py:content="value"
    />
    """
    params = ["attrs"]
    params_doc = {'attrs' : 'Dictionary containing extra (X)HTML attributes for'
                            'the label tag'}
    attrs = {}


class EditUserSchema(validators.Schema):
    u = IDValidator(User)
    chained_validators=[validators.Any(SameOrg(), IdentityValidator(condition = lambda: identity.in_group("uberAdmins") ))]
    
class JoinMultipleSelectField(widgets.MultipleSelectField):
    
    def _is_option_selected(self, option_value, value):
        print "In is_option_selected: option_value: %s, value: %s" % (option_value, value)
        try:
            if value == None:
                return False
            if not isinstance(value, list):
                value = [value]
        
            if len(value) > 0:
                if isinstance(value[0], basestring):
                    x = str(option_value)
                else:
                    x = self.validator.to_python(option_value)
                
                return x[0] in value
            else:
                return False
        except validators.Invalid:
            return False


class TransformLabel(widgets.Label):
    def __init__(self, transform, **kwargs):
        super(TransformLabel, self).__init__(**kwargs)
        self.transform = transform
        
    def update_params(self, params):
        super(TransformLabel, self).update_params(params)

        if params["value"] != None:
            params["value"] = self.transform(params["value"])

class TableViewForm(widgets.Form):
    template = """
    <div xmlns:py="http://purl.org/kid/ns#"        
        class="tableform"
        py:attrs="form_attrs"
    >
        <table border="0" cellspacing="0" cellpadding="2" py:attrs="table_attrs">
            <tr py:for="i, field in enumerate(fields)" 
                class="${i%2 and 'odd' or 'even'}"
            >
                <th>
                    <label class="fieldlabel" for="${field.field_id}" py:content="field.label" />
                </th>
                <td>
                    <span py:replace="field.display(value_for(field), **params_for(field))" />
                    <span py:if="error_for(field)" class="fielderror" py:content="error_for(field)" />
                    <span py:if="field.help_text" class="fieldhelp" py:content="field.help_text" />
                </td>
            </tr>
        </table>
    </div>
    """
    params = ["table_attrs"]
    params_doc = {'table_attrs' : 'Extra (X)HTML attributes for the Table tag'}
    table_attrs = {}


def get_group_options(validGroups = ["userAdmins", "reportUsers", "fullUsers"]):
    opts = []
    for n in validGroups:
        g = Group.by_group_name(n)
        opts.append((g.id, g.display_name))
    return opts
    
class UserEditFields(widgets.WidgetsList):
    
    user_name = widgets.TextField(label="User Name")
    email_address = widgets.TextField(label="Email Address")
    display_name = widgets.TextField(label="Full Name")
    new_password = widgets.PasswordField(label="Password")
    confirm_password = widgets.PasswordField(label="Confirm Password")
    organisation = TransformLabel(label="Organisation", transform=lambda o: o.name)
    groups = JoinMultipleSelectField(options=get_group_options, validator=IDValidator(Group))

class UserEditSchema(validators.Schema):
    user_name = formencode.All(validators.String(not_empty=True), SameOrUnique(dbClass=User, query=User.q.user_name, match=lambda x: x.u.user_name))
    email_address = validators.Email(not_empty=True)
    display_name = validators.String(not_empty=True)
    new_password = validators.String()
    confirm_password = validators.String()
    groups = validators.ForEach(IDValidator(Group))
    chained_validators = [validators.FieldsMatch("new_password", "confirm_password"),  ]
    

class UberUserEditSchema(UserEditSchema):
    organisation = IDValidator(Organisation, if_empty=None)
    deleted = validators.Bool()

class UberUserEditFields(widgets.WidgetsList):
    
    def get_group_options():
        return get_group_options(validGroups=["uberAdmins","userAdmins", "reportUsers", "fullUsers"])
    
    def get_options():
        opts = []
        for o in Organisation.select():
            opts.append((o.id, o.name))
        return opts
    
    user_name = widgets.TextField(label="User Name")
    email_address = widgets.TextField(label="Email Address")
    deleted = widgets.CheckBox(label="Inactive")
    display_name = widgets.TextField(label="Full Name")
    new_password = widgets.PasswordField(label="Password")
    confirm_password = widgets.PasswordField(label="Confirm Password")
    organisation = widgets.SingleSelectField(options=get_options, validator=IDValidator(Organisation))
    groups = JoinMultipleSelectField(options=get_group_options, validator=IDValidator(Group))
    

def getUserEditForm(user=None):
    """Factory function that builds a form ,based on whether or not we need the regular or the uber form"""
    if user != None:
        g = Group.by_group_name("uberAdmins")
        if g in user.groups:
            fields = UberUserEditFields
            schema = UserEditSchema
        else:
            fields = UserEditFields
            schema = UberUserEditSchema
    else:
        fields = UserEditFields
        schema = UserEditSchema
        
    userEditForm = widgets.TableForm(fields=fields(), validator=schema())
    return userEditForm

class OrgEditFields(widgets.WidgetsList):
    name = widgets.TextField(label="Name")
    deleted = widgets.CheckBox(label='Inactive')

class OrgEditSchema(validators.Schema):
    name = formencode.All(validators.String(not_empty=True), SameOrUnique(dbClass=Organisation, query=Organisation.q.name, match=lambda x: x.o.name))
    deleted = validators.Bool()
    
OrgEditForm = widgets.TableForm(fields=OrgEditFields(), validator=OrgEditSchema())

class NewsEditFields(widgets.WidgetsList):
    title = widgets.TextField(label="Title")
    text = widgets.TextArea(label="Body")
    url = widgets.TextField(label="Url")
    deleted = widgets.CheckBox(label="Inactive")

class NewsEditSchema(validators.Schema):
    title = validators.String(not_empty=True)
    text = validators.String()
    url = validators.URL()
    deleted = validators.Bool()
    
NewsEditForm = widgets.TableForm(fields=NewsEditFields(),validator=NewsEditSchema())

class TargetViewFields(widgets.WidgetsList):
    name = widgets.Label(label="Name")
    include = widgets.Label(label="Target Addresses")
    exclude = widgets.Label(label="Exclusions")
    organisation = TransformLabel(label="Organistion", transform=lambda o: o.name)
    
TargetViewForm = TableViewForm(fields = TargetViewFields())

class TargetEditFields(widgets.WidgetsList):
    name = widgets.TextField(label="Name")
    include = widgets.TextArea(label="Target Addresses")
    exclude = widgets.TextArea(label="Exclusions")
    organisation = TransformLabel(label="Organisation", transform=lambda o: o.name)
    help = Help(default=_("""Both target and exclusion lists can be specified as a range of addresses, separated by commas.
    Addresses may be provided as:
    a hostname (e.g. www.target.com),
    a single ip address (e.g. 192.168.1.23),
    a range (e.g. 192.168.1.120-140)
    or with CIDR style netmasks (e.g. 192.168.1.0/24)."""))

class TargetEditSchema(validators.Schema):
    name = validators.String(not_empty=True)
    include = IPAddrRange()
    exclude = IPAddrRange()

TargetEditForm = widgets.TableForm(fields=TargetEditFields(), validator=TargetEditSchema())

class AdHocScanFields(widgets.WidgetsList):
    def get_options():
        opts = []
        for s in ScanTemplate.select(OR(ScanTemplate.q.organisationID == identity.current.user.organisation.id, 
                                        ScanTemplate.q.organisationID == None)):
            opts.append((s.id, s.name))
        return opts
    
    target = widgets.TextField(label="Target")
    scanTemplate = widgets.SingleSelectField(label="Scan Template", options=get_options, validator=IDValidator(ScanTemplate))

class AdHocScanSchema(validators.Schema):
    target = IPAddrRange()
    scanTemplate = IDValidator(ScanTemplate)

class AdHocScanFormWidget(widgets.Form):
    template = """
    <form xmlns:py="http://purl.org/kid/ns#"
        name="${name}"
        action="${action}"
        method="${method}"
        class="adHocScanForm"
        py:attrs="form_attrs"
    >
      <div>
       <span py:for="field in fields">
        <span py:replace="field.display(value_for(field), **params_for(field))" />
        <span py:if="error_for(field)" class="fielderror" py:content="error_for(field)" />
        <span py:if="field.help_text" class="fieldhelp" py:content="field.help_text" />
       </span>
       <span py:content="submit.display(submit_text)" />
      </div>
    </form>
    
    """    

AdHocScanForm = AdHocScanFormWidget(fields=AdHocScanFields(), validator=AdHocScanSchema(), action="/scanner/adHocScan", submit_text="Scan!")

class ScanSpecViewFields(widgets.WidgetsList):
    name = widgets.Label(label="Name")
    organisation = TransformLabel(label="Organisation", transform=lambda o: o.name)
    targets = TransformLabel(label="Targets", transform=lambda o: ", ".join([x.name for x in o]))
    scanTemplate = TransformLabel( label="Scan Template", transform=lambda o: o.name)
    schedule = widgets.Label(label="Scheduling")
    startAt = widgets.Label(label="Run At")
    crontab = widgets.Label(label="Recurring Time")
    deleted = widgets.Label(label="Inactive")
    enabled = widgets.Label(label="Enabled")
    
ScanSpecViewForm = TableViewForm(fields=ScanSpecViewFields())


class ScanSpecEditFields(widgets.WidgetsList):
    def get_scanTemplates():
        opts = []
        for s in ScanTemplate.select(OR(ScanTemplate.q.organisationID == identity.current.user.organisation.id, 
                                        ScanTemplate.q.organisationID == None)):
            opts.append((s.id, s.name))
        return opts
    
    def get_targets():
        opts = []
        for t in identity.current.user.organisation.targets:
            opts.append((t.id, t.name))
        return opts
    
    def get_scanSchedule():
        opts = copy.copy(ScanSpec.sqlmeta.columns["schedule"].enumValues)
        if "Ad-Hoc" in opts:
            opts.remove("Ad-Hoc")
        return opts

    
    javascript=[widgets.JSSource("""
        function toggleRecurring() {
            var radiobutton = filter(
                itemgetter('checked'),
                $$('input[name=schedule]')
                )[0];
            var selectedvalue = (radiobutton  != undefined) ? radiobutton .value : null;
            
            if (selectedvalue == 'Recurring') {
                $("form_startAt").disabled = true;
                $("form_startAt_trigger").disabled = true;
                $("form_crontab").disabled = false;
            } else {
                $("form_startAt").disabled = false;
                $("form_startAt_trigger").disabled = false;
                $("form_crontab").disabled = true;
            }
        }
        MochiKit.DOM.addLoadEvent(toggleRecurring);
        """)]
    
    name = widgets.TextField(label="Name")
    organisation = TransformLabel(transform=lambda o: o.name)
    targets = widgets.CheckBoxList(label="Targets", options=get_targets, validator=IDValidator(Target))
    scanTemplate = widgets.SingleSelectField(label="Scan Template", options=get_scanTemplates, validator=IDValidator(ScanTemplate))
    schedule = widgets.RadioButtonList(label="Scheduling", options=get_scanSchedule, list_attrs={"onClick":"toggleRecurring()"})
    startAt = widgets.CalendarDateTimePicker(label="Run At")
    crontab = widgets.TextField(label="Recurring Time")
    deleted = widgets.CheckBox(label="Inactive")
    enabled = widgets.CheckBox(label="Enabled")

    
class ScanSpecEditSchema(validators.Schema):
    name = validators.String()
    #targets = Dunno yet.
    scanTemplate = IDValidator(ScanTemplate)
    schedule = ScanSpec.sqlmeta.columns["schedule"].createValidators()
    startAt = validators.DateValidator()
    #crontab = # invent cron validator

ScanSpecEditForm = widgets.TableForm(fields=ScanSpecEditFields(), validator=ScanSpecEditSchema())
ScanSpecEditForm.javascript = ScanSpecEditFields.javascript

class STOFieldSet(widgets.FieldSet):
    template = """
    <tr xmlns:py="http://purl.org/kid/ns#"
         py:for="i, field in enumerate(fields)" class="${i%2 and 'odd' or 'even'}">
        <td>
            <label class="fieldlabel" for="${field.field_id}" py:content="field.label" />
        </td>
        <td>
            <span py:replace="field.display(value_for(field), **params_for(field))" />
            <span py:if="error_for(field)" class="fielderror" py:content="error_for(field)" />
            <span py:if="field.help_text" class="fieldhelp" py:content="field.help_text" />
        </td>
    </tr>
    """

class MultiFieldSetTable(widgets.TableForm):
    template = """
    <form xmlns:py="http://purl.org/kid/ns#"
        name="${name}"
        action="${action}"
        method="${method}"
        class="tableform"
        py:attrs="form_attrs"
    >
        <div py:for="field in hidden_fields" py:replace="field.display(value_for(field), **params_for(field))" />
        <table py:attrs="table_attrs">
            <div py:for="fieldset in fieldsets" py:strip="True">
                <tr py:if="fieldset.legend">
                    <td colspan="2">
                        <h1 py:content="fieldset.legend">This is a Heading</h1>
                    </td>
                </tr>
                <div py:replace="fieldset.display(value_for(fieldset), **params_for(fieldset))" />
            </div>
            <tr>
                <td>&#160;</td>
                <td py:content="submit.display(submit_text)" />
            </tr>
        </table>
    </form>
    """
    member_widgets = ["fieldsets"]
    fieldsets = []

class ScanTemplateEditFields(widgets.WidgetsList):
    name = widgets.TextField(label="Name", validator = validators.String(not_empty=True))
    description = widgets.TextArea(label="Description")
    organisation = TransformLabel(label="Organisation", transform=lambda o: o.name)



def generateSTOEditWidget(sto):
    
    t = sto.type
    if t in ["string", "ip", "iprange","number"]:        
        w = widgets.TextField()
        
        if t in ["string", "number"]:
            w.label = "Value"
            if t == "number":
                if sto.validatorData == None:
                    w.validator = validators.Number()
                else:
                    min,max = sto.validatorData.split(",")
                    min = int(min)
                    max = int(max)
                    w.validator = LimitedNumber(lambda x: x > min and x < max, "Number must be between range %d - %d" % (min, max) )
        elif t == "ip":
            w.label = "IP Address"
            w.validator = CIDR()
        elif t == "iprange":
            w.label = "IP Range"
            w.validator = IPAddrRange()
            
    elif t == "bool":
        w = widgets.CheckBox(label="Enabled", validator=validators.Bool())
    elif t == "enum":
        def get_options():
            return sto.validatorData.split(",")
        w = widgets.SingleSelectField(label="Options", options=get_options, validator=validators.OneOf(get_options()))
    
    w.name = "value"
        
    return w

class ScanTemplateOptionEditFields(widgets.WidgetsList):
    description =  TransformLabel(label="Description", transform = lambda o: o.scanTemplateOption.description)

def getScanTemplateEditForm(st):
    wl = []
    wl.append(("Template", ScanTemplateEditFields()))
    
    for o in st.optionValues:        
        fs = ScanTemplateOptionEditFields()
        fs.append(generateSTOEditWidget(o.scanTemplateOption))
        wl.append((o.scanTemplateOption.name, fs))

    trwl = widgets.WidgetsList()
    for k, v in wl:
        trwl.append(STOFieldSet(fields = v, name=k,legend = k))
    
    form = MultiFieldSetTable(fieldsets = trwl)
        
    return form
        



