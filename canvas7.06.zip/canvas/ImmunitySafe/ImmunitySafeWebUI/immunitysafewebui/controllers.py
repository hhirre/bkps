from turbogears import controllers, expose, flash
from model import *
from turbogears import identity, redirect, validate, error_handler, config
from cherrypy import request, response, NotFound, HTTPError
from forms import *
from sqlobject import dberrors
# from immunitysafewebui import json
# import logging
# log = logging.getLogger("immunitysafewebui.controllers")

GENERIC_FORM_ERROR=_("An error occurred during validation, please check the values and try again")

class StateContainer():
    """Used to shoehorn state into validators, more complicated than it should be."""
    def __init__(self, data={}):
        self.__dict__.update(data)
        
    def __str__(self):
        return reduce(lambda x, y: x + "\n%s: %s" % (y[0], y[1]), self.__dict__.iteritems(), "")

def stateFactory(**data):
    """Returns a lazy callable factory lambda; creates a StateContainer at some point in the future.
    This is a bit silly huh? I'm not so sure Turbogears is sane :)"""
    return lambda: StateContainer(data)


class Admin(controllers.Controller):
    @expose(template="genshi:immunitysafewebui.templates.useradmin")
    @identity.require(identity.in_any_group("uberAdmins", "userAdmins"))
    @validate(validators={'undelete':validators.Bool()})
    def index(self, undelete=False):
        rv = {}
        if undelete:
            if identity.has_permission("undelete"):
                rv["undelete"] = True
            else:
                raise identity.IdentityFailure("Requires undelete permission")
            
        if identity.in_group("uberAdmins"):
            if undelete:
                rv["org"] = Organisation.select()                
            else:
                rv["org"] = Organisation.select(Organisation.q.deleted != True)
        else: 
            rv["org"] = [identity.current.user.organisation]
            
        if identity.has_permission("newsAdmin"):
            if undelete:    
                rv["news"] = NewsItem.select()
            else:
                rv["news"] = NewsItem.select(NewsItem.q.deleted != True)
        return rv
    
    def handleError(self, **kw):
        msg = "Not Found"
        if config.get("server.environment") == "development":
            msg = str(kw)
        raise HTTPError(status=404, message=msg)

    @expose()
    @identity.require(identity.in_any_group("uberAdmins", "userAdmins"))
    def newUser(self):
        i = 0
        u = None
        while u == None:
            try:
                u = User(user_name="New User %d" % i)
            except dberrors.DuplicateEntryError:
                i += 1
                
        if identity.in_group("userAdmins"):
            u.organisation = identity.current.user.organisation
        
        raise redirect("editUser/%d" % u.id)

    @expose()
    @identity.require(identity.in_any_group("uberAdmins", "userAdmins"))
    @validate(validators=EditUserSchema)
    @error_handler(handleError)
    def deleteUser(self, u):
        u.deleted = True
        flash("User %s deactivated" % u.user_name)
        raise redirect("/admin")
            
    @expose()
    @identity.require(identity.in_group("uberAdmins"))    
    def newOrg(self):
        i = 0
        o = None
        while o == None:
            
            try:
                o = Organisation(name="Untitled-%d" % i)
            except dberrors.DuplicateEntryError:
                i += 1
        raise redirect('editOrg/%d' % o.id)


    @expose()
    @identity.require(identity.in_group("uberAdmins"))
    @validate(validators={'o':IDValidator(Organisation)})
    @error_handler(handleError)
    def deleteOrg(self, o):
        o.deleted = True
        flash("Organisation %s deactivated" % o.name)
        raise redirect("/admin")

    @expose(template="genshi:immunitysafewebui.templates.genericedit")
    @identity.require(identity.in_group("uberAdmins"))
    @validate(validators={'o':IDValidator(Organisation)})
    @error_handler(handleError)
    def editOrg(self, o, **kwargs):
        rv = {}
        if kwargs:
            @validate(form=OrgEditForm, state_factory=stateFactory(o=o))
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            tg_errors, data = get_errors(self, **kwargs)
            if not tg_errors:
                o.name = data['name']
                o.deleted = data['deleted']
                flash(_("Organisation %s updated" % o.name))
                redirect("/admin")
            else:
                flash(GENERIC_FORM_ERROR)
                
    
        rv['title'] = _("Edit Organistion")
        rv['value'] = o
        rv['form'] = OrgEditForm
        rv['action'] = "/admin/editOrg/%d" % o.id
    
        return rv
    
    @expose(template="genshi:immunitysafewebui.templates.genericedit")
    @identity.require(identity.in_any_group("uberAdmins", "userAdmins"))
    @validate(validators=EditUserSchema)
    @error_handler(handleError)
    def editUser(self, u, **kwargs):
        rv = {}
        
        if kwargs:
            # Form posting time.
            @validate(form=getUserEditForm(identity.current.user), state_factory=stateFactory(u=u))
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            
            tg_errors, data = get_errors(self, **kwargs)
            if not tg_errors:
                u.user_name = data["user_name"]
                u.display_name = data["display_name"]
                u.email_address = data["email_address"]
                if data["new_password"] != "":
                    u.password = data["new_password"]
                for g in u.groups:
                    if g not in data["groups"]:
                        u.removeGroup(g)
                for g in data["groups"]:
                    if g not in u.groups:
                        u.addGroup(g)
                if data["organisation"] != None:
                    u.organisation = data["organisation"].id
                if data["deleted"] != None:
                    u.deleted = data["deleted"]
                
                flash(_("User %s updated" % u.user_name))
                raise redirect("/admin")
                
            else:
                flash(GENERIC_FORM_ERROR)
            
        
        rv["title"] = _("Edit User")
        rv["form"] = getUserEditForm(identity.current.user)
        rv["action"] = "/admin/editUser/%d" % u.id
        rv["value"] = u
        
        return rv

    @expose()
    @identity.require(identity.has_permission("newsAdmin"))
    def newNews(self):
        n = NewsItem(title="New News Item", author=identity.current.user.id)
        raise redirect('editNews/%d' % n.id)

    @expose()
    @identity.require(identity.has_permission("newsAdmin"))
    @validate(validators={'n':IDValidator(NewsItem)})
    @error_handler(handleError)
    def deleteNews(self, n):
        n.deleted = True
        flash(_("News item %s deactivated" % n.title))
        raise redirect("/admin")

    @expose(template="genshi:immunitysafewebui.templates.genericedit")
    @identity.require(identity.has_permission("newsAdmin"))
    @validate(validators={'n':IDValidator(NewsItem)})
    @error_handler(handleError)
    def editNews(self, n, **kwargs):
        rv = {}
        if kwargs:
            @validate(form=NewsEditForm)
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            tg_errors, data = get_errors(self, **kwargs)
            if not tg_errors:
                n.title = data['title']
                n.text = data['text']
                n.url = data['url']
                n.deleted = data['deleted']
                flash(_("News Item %s updated" % n.title))
                redirect("/admin")
            else:
                flash(GENERIC_FORM_ERROR)
                
    
        rv['title'] = _("Edit News Item")
        rv['value'] = n
        rv['form'] = NewsEditForm
        rv['action'] = "/admin/editNews/%d" % n.id
    
        return rv

class Scanner(controllers.Controller):

    def handleError(self, **kw):
        msg = _("Not Found")
        if config.get("server.environment") == "development":
            msg = str(kw)
        raise HTTPError(status=404, message=msg)

    @expose(template="genshi:immunitysafewebui.templates.scanner")
    @identity.require(identity.not_anonymous())
    @error_handler(handleError)
    @validate(validators={'undelete':validators.Bool()})
    def index(self, undelete=False):
        rv = {}
        if undelete:
            if identity.has_permission("undelete"):
                rv["undelete"] = True
            else:
                raise identity.IdentityFailure("Requires undelete permission")
            
        if undelete:            
            rv["scanSpecs"] = ScanSpec.select(AND(ScanSpec.q.schedule != "Ad-Hoc",
                                  ScanSpec.q.organisationID == identity.current.user.organisation.id))
        else:
            rv["scanSpecs"] = ScanSpec.select(AND(ScanSpec.q.deleted != True,
                                              ScanSpec.q.schedule != "Ad-Hoc",
                                              ScanSpec.q.organisationID == identity.current.user.organisation.id))
        
        rv["targets"] = Target.select(AND(Target.q.organisationID == identity.current.user.organisation.id,
                                          Target.q.adHoc == False))
        rv["defaultScanTemplates"] = ScanTemplate.select(ScanTemplate.q.organisationID == None)
        rv["orgScanTemplates"] = ScanTemplate.select(ScanTemplate.q.organisationID == identity.current.user.organisation.id )
        
        rv["scanInstances"] = ScanInstance.select(AND(ScanInstance.q.scanSpecID == ScanSpec.q.id,
                                                      ScanSpec.q.organisationID == identity.current.user.organisation.id),
                                                      orderBy=ScanInstance.q.lastChange)
                                                      
        
        return rv

    @expose()
    @identity.require(identity.has_permission("alterTargets"))
    @validate(validators={'t':IDValidator(Target)})
    @error_handler(handleError)
    def deleteTarget(self, t):
        flash(_("Target %s deleted" % t.name))        
        Target.delete(t.id)
        raise redirect("/scanner")
    
    @expose()
    @identity.require(identity.has_permission("alterTargets"))
    def newTarget(self):
        t = Target(name="New Target", organisation = identity.current.user.organisation.id)
        raise redirect("editTarget/%d" % t.id)
        
    @expose(template="genshi:immunitysafewebui.templates.genericedit")
    @identity.require(identity.has_permission("alterTargets"))
    @validate(validators={'t':IDValidator(Target)})
    @error_handler(handleError)
    def editTarget(self, t, **kwargs):
        rv = {}
        if kwargs:
            @validate(form=TargetEditForm)
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            tg_errors, data = get_errors(self, **kwargs)
            
            if not tg_errors:
                if t.adHoc:
                    raise RuntimeError("Unable to edit an adhoc target")
                
                t.name = data['name']
                if data['include'][0] == None:
                    t.include = None
                else:
                    t.include = ",".join(data['include'])
                if data['exclude'][0] == None:
                    t.exclude = None
                else:
                    t.exclude = ",".join(data['exclude'])
                
                flash(_("Target %s updated" % t.name))
                redirect("/scanner")
            else:
                flash(GENERIC_FORM_ERROR)
                    
        
        rv['title'] = _("Edit Target")
        rv['value'] = t
        if t.adHoc:
            rv['form'] = TargetViewForm
            rv['title'] = _("View Target")
        else:
            rv['form'] = TargetEditForm
        rv['action'] = "/scanner/editTarget/%d" % t.id
    
        return rv
    
    @expose()
    @identity.require(identity.has_permission("runScan"))
    @validate(validators={'s':IDValidator(ScanSpec)})
    @error_handler(handleError)
    def deleteScanSpec(self, s):
        flash(_("Scan %s deleted" % s.name))        
        #ScanSpec.delete(s.id)
        s.deleted = True
        raise redirect("/scanner")
    
    @expose()
    @identity.require(identity.has_permission("runScan"))
    def newScanSpec(self):
        s = ScanSpec(name="New Scan", organisation = identity.current.user.organisation.id, scanTemplate=int(Config.byName("DefaultScanTemplate").value))
        raise redirect("editScanSpec/%d" % s.id)
        
    @expose(template="genshi:immunitysafewebui.templates.genericedit")
    @identity.require(identity.has_permission("runScan"))
    @validate(validators={'s':IDValidator(ScanSpec)})
    @error_handler(handleError)
    def editScanSpec(self, s, **kwargs):
        rv = {}
        if kwargs:
            @validate(form=ScanSpecEditForm)
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            tg_errors, data = get_errors(self, **kwargs)
            print "data: %s" %data
            print "errors: %s" % tg_errors
            if not tg_errors:
                if s.schedule == "Ad-Hoc":
                    raise RuntimeError("Unable to edit an Ad-Hoc scan")
                
                s.name = data["name"]
                for t in s.targets:
                    s.removeTarget(t)
                for t in data["targets"]:
                    s.addTarget(t)
                
                s.schedule = str(data["schedule"])
                s.time = data["startAt"]
                s.crontab = data["crontab"]
                s.deleted = data["deleted"]
                s.enabled = data["enabled"]
                
                flash(_("Scan %s updated" % s.name))
                redirect("/scanner")
            else:
                
                flash(GENERIC_FORM_ERROR)
                    
        rv['title'] = _("Edit Scan")
        rv['value'] = s
        if s.schedule =="Ad-Hoc":
            rv['form'] = ScanSpecViewForm
            rv['title'] = _("View Scan")
        else:
            rv['form'] = ScanSpecEditForm
            
        rv['action'] = "/scanner/editScanSpec/%d" % s.id
    
        return rv
    
    
    @expose()
    @identity.require(identity.has_permission("runScan"))
    @error_handler(handleError)
    def adHocScan(self, **kwargs):
        if kwargs:
            @validate(form=AdHocScanFormWidget())
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            
            tg_errors, data = get_errors(self, **kwargs)
            print "data: %s" % data
            print "errors: %s" % tg_errors
            
            st = ScanTemplate.get(data["scanTemplate"])
            if st.organisation != None and st.organisation != current.user.organisation:
                # IDS Trigger here plz :)
                raise identity.IdentityException(_("Out of organisation scan template not permitted"))
            
            t = Target(name="Ad-Hoc Target", organisationID = identity.current.user.organisation.id, include = data["target"], adHoc=True)
            sc = ScanSpec(name="Ad-Hoc Scan", time = datetime.now(), scanTemplateID = st.id,  schedule="Ad-Hoc", organisationID = identity.current.user.organisation.id)
            sc.addTarget(t)
            flash(_("Created new Ad-Hoc Scan, starting soon..."))
        
        redirect("/scanner")
            
    
    
    @expose(template="genshi:immunitysafewebui.templates.genericedit")
    @identity.require(identity.has_permission("runScan"))
    @validate(validators={'s':IDValidator(ScanTemplate)})
    @error_handler(handleError)
    def editScanTemplate(self, s, **kwargs):
        rv = {}
        if kwargs:
            @validate(form=getScanTemplateEditForm(s))
            def get_errors(self, tg_errors=None, **kw):
                return tg_errors, kw
            
            tg_errors, data = get_errors(self, **kwargs)
            print "data: %s" % data
            print "errors: %s" % tg_errors
            
            if not tg_errors:
                if s.organisation != identity.current.user.organisation:
                    raise identity.IdentityException("Unable to edit global scan template")
                
                s.name = data["Template"]["name"]
                s.description = data["Template"]["description"]
                for o in s.optionValues:
                    if data.has_key(o.scanTemplateOption.name):
                        o.value = str(data[o.scanTemplateOption.name]["value"])
                    else:
                        print "No value for %s" % o.scanTemplateOption.name
                
                flash(_("Scan Template %s updated" % s.name))
                redirect("/scanner")
            else:
                flash(GENERIC_FORM_ERROR)
            
        else:
            if s.organisation == None:
                # The user is customising their defaults, so we have to make a new one for them.
                n = ScanTemplate(name = s.name + " (custom)", description = s.description, organisation = identity.current.user.organisation.id)
                for o in s.defaultOptions:
                    n.addDefaultOption(o)
                for o in s.optionValues:
                    stov = ScanTemplateOptionValue(scanTemplate = n.id, scanTemplateOption = o.scanTemplateOption.id, value = o.value)
                    
                s = n
                    
        rv['title'] = _("Edit Scan Template")
        rv['value'] = {"Template":s}
        for o in s.optionValues:
            rv["value"][o.scanTemplateOption.name] = {"description":o, "value":o.value}                
        rv['form'] = getScanTemplateEditForm(s)
        rv['action'] = "/scanner/editScanTemplate/%d" % s.id
            
        return rv
    
    
class Root(controllers.RootController):

    admin = Admin()
    scanner = Scanner()

    @identity.require(identity.not_anonymous())
    @expose(template="immunitysafewebui.templates.front")
    def front(self):
        rv = {}
        rv["news"] = NewsItem.select(NewsItem.q.deleted != True)[0:5]
        rv["adHocScanForm"] = AdHocScanForm
        
        return rv
    
    @expose()
    def index(self):
        raise redirect("/front")

    @expose(template="genshi:immunitysafewebui.templates.login")
    def login(self, forward_url=None, previous_url=None, *args, **kw):

        if not identity.current.anonymous \
           and identity.was_login_attempted() \
           and not identity.get_identity_errors():
            raise redirect(forward_url)

        forward_url=None
        previous_url= request.path

        if identity.was_login_attempted():
            msg=_("The credentials you supplied were not correct or "
                  "did not grant access to this resource.")
        elif identity.get_identity_errors():
            msg=_("You must provide your credentials before accessing "
                  "this resource.")
        else:
            msg=_("Please log in.")
            forward_url= request.headers.get("Referer", "/")

        response.status=403
        return dict(message=msg, previous_url=previous_url, logging_in=True,
                    original_parameters=request.params,
                    forward_url=forward_url)

    @expose()
    def logout(self):
        identity.current.logout()
        raise redirect("/")
