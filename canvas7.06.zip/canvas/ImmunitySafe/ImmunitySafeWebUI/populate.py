#!/usr/bin/python

import turbogears
from turbogears.database import PackageHub
turbogears.update_config(configfile="dev.cfg", modulename="immunitysafewebui.config")
hub = PackageHub("populate")

from immunitysafewebui.model import *

# Base organisations
oImm = Organisation(name="Immunity")
oTest = Organisation(name="Bobs Vulnerable Emporium")
oTestTwo = Organisation(name="Korean Cheezburgr.com")

# Group definitions
gAdmins = Group(group_name="uberAdmins", display_name="Uber Admins")
gUserAdmins = Group(group_name="userAdmins", display_name="User Admins")
gReportUsers = Group(group_name="reportUsers", display_name="Report View Users")
gFullUsers = Group(group_name="fullUsers", display_name="Full Users")

# Permission definitions
pUberAdmin = Permission(permission_name="uberAdmin", description="Whole system administrators")
pUserAdmin = Permission(permission_name="userAdmin", description="Can administer user accounts for a single organisation")
pOrgAdmin = Permission(permission_name="orgAdmin", description="Can edit orgnisations")
pReportView = Permission(permission_name="reportView", description="Permitted to read reports for an organisation")
pRunScan = Permission(permission_name="runScan", description="Permitted to initiate a scan")
pAlterTargets = Permission(permission_name="alterTargets", description="Can alter the targets for an organisation")
pNewsAdmin = Permission(permission_name="newsAdmin", description="Can edit news posts")
pUndelete = Permission(permission_name="undelete", description="Can undelete things")

# Allocate perms to groups
gAdmins.addPermission(pUberAdmin)
gAdmins.addPermission(pNewsAdmin)
gAdmins.addPermission(pUndelete)
gAdmins.addPermission(pOrgAdmin)
gAdmins.addPermission(pAlterTargets)
gAdmins.addPermission(pRunScan)
gAdmins.addPermission(pUserAdmin)

gUserAdmins.addPermission(pUserAdmin)
gUserAdmins.addPermission(pReportView)
gUserAdmins.addPermission(pRunScan)
gUserAdmins.addPermission(pAlterTargets)

gReportUsers.addPermission(pReportView)

gFullUsers.addPermission(pReportView)
gFullUsers.addPermission(pRunScan)

# Add users 

uMetl = User(user_name="metlstorm", email_address="adam@immunityinc.com", display_name="Adam Boileau", password="admin", organisation=oImm.id)
uBobAdmin = User(user_name="bobAdmin", email_address="bobAdmin@bob", display_name="Big Bob", password="bobAdmin", organisation=oTest.id)
uBobUser = User(user_name="bobUser", email_address="bobUser@bob", display_name="Jim Bob", password="bobUser", organisation = oTest.id)
uKUser = User(user_name="koreanUser", email_address="sneaky@kr", display_name="Sneaky Korean", password="koreanUser", organisation = oTestTwo.id)

# Allocate users to groups
uMetl.addGroup(gAdmins)
uBobAdmin.addGroup(gUserAdmins)
uBobUser.addGroup(gFullUsers)
uKUser.addGroup(gReportUsers)

# Some default scan templates
stSafe = ScanTemplate(name="Safe Assessment", description="Performs reconnaisance and non-intrusive attacks only. Does not attempt to actively exploit vulnerabilities")
stAggressive = ScanTemplate(name="Full Exploitation", description="Performs an aggressive, active attack, including attempting to exploit vulnerabilities found.")
stQuick = ScanTemplate(name="Quick Scan", description="Checks for the  most common vulnerabilities only.")

# Scan Template Options

stoExploits = ScanTemplateOption(name="Exploits", description="Select the set of exploits to use.", type="enum", defaultValue="All", validatorData="Common,Web Only,All")
stoExploit = ScanTemplateOption(name="Exploitation", description="When enabled, ImmunitySafe will compromise systems vulnerable systems", type="bool", defaultValue="True")
stoMaxConnects = ScanTemplateOption(name="Max Connections", description="Limits the maximum number of connections used during the scan", type="number", defaultValue="50", validatorData="1,200")
stoBruteForceOptions = ScanTemplateOption(name="Brute Force", description="Chooses the amount of username/password bruteforcing to attempt", type="enum", defaultValue="Basic", validatorData="None,Basic,Full")
stoScreenshot = ScanTemplateOption(name="Screenshot", description="Take screenshots of compromised systems", type="bool", defaultValue="True")
stoPasswordHashes = ScanTemplateOption(name="Password Hashes", description="Retreive password hashes of compromised systems", type="bool", defaultValue="True")

# Creates ScanTemplateOptionValues with default values
for i in [stoMaxConnects, stoBruteForceOptions, stoExploit, stoExploits, stoScreenshot, stoPasswordHashes]:
    for j in [stSafe, stAggressive, stQuick]:
        j.addDefaultOption(i)
        x = ScanTemplateOptionValue(scanTemplateID = j.id, scanTemplateOptionID = i.id, value = i.defaultValue)

# Set up non-default values for each ScanTemplate
values = {stQuick: {stoBruteForceOptions:"None", stoScreenshot:"False", stoPasswordHashes:"False", stoExploits:"Common"},
          stSafe:{stoBruteForceOptions:"Basic", stoExploit:"False"},
          stAggressive:{stoBruteForceOptions:"Full"},
      }

for st, opts in values.iteritems():
    for o,v in opts.iteritems():
        stov = ScanTemplateOptionValue.select(ScanTemplateOptionValue.q.scanTemplateID == st.id and ScanTemplateOptionValue.q.scanTemplateOptionID == o.id)
        stov.value = v


# News items
nTest = NewsItem(title="Test news", text="Zomg, it's alive", url="http://www.immunityinc.com", authorID=uMetl.id)

# Config defaults
configDefaultScan = Config(name="DefaultScanTemplate", value=str(stQuick.id))

hub.commit()

