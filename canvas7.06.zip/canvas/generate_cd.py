#! /usr/bin/env python
##ImmunityHeader v1
###############################################################################
## File       :  generate_cd.py
## Description:
##            :
## Created_On :  Wed Sep  2 07:29:18 2009
## Created_By :  Justin Seitz
## Modified_On:  Wed Sep  2 07:33:29 2009
## Modified_By:  Justin Seitz
##
## (c) Copyright 2009, Immunity, Inc. all rights reserved.
###############################################################################

#Proprietary CANVAS source code - use only under the license agreement
#specified in LICENSE.txt in your CANVAS distribution
#Copyright Immunity, Inc, 2002-2006
#http://www.immunityinc.com/CANVAS/ for more information
"""
generate_cd.py
(c) Immunity, Inc.
2002


This program/python module takes in a number and generates
/tmp/CANVAS_NUMBER/ with the necessary files and changes

"""
import sys, os, os.path
import shutil
import md5

#change this to True after release
PPC=True

canvas_platform = "default"
currdir=os.getcwd()
tmpdir="/tmp"
tmpdir="/home/OUT/"
import socket
tmpdir=os.path.join("/home",os.environ.get("USER","xdave"),"OUT")


if socket.gethostname()=="fist":
    tmpdir="/var/CANVAS"
elif os.path.isdir("/dev/shm"):
    tmpdir = "/dev/shm"

def normalizeDate(date):
    if date.count("/")==0:
        return date
    dates=date.split("/")
    #add the year if just a 05 -> 2005
    if len(dates[2])==2:
        dates[2]="20"+dates[2]
    newdate="%4.4d%2.2d%2.2d"%(int(dates[2]),int(dates[0]),int(dates[1]))
    return newdate

dateDict={}
emailDict={}
customersDict={}
customersDict[101]="DEMO"
customersDict[1005]="DB"
customersDict[1006]="MSDTF_BHFED2008"
customersDict[763]="AlexMcGeorge"
customersDict[800]="TerremarkClass"
customersDict[803]="blu3"
customersDict[761]="Paychex"
customersDict[2103]="d2_prerelease"
customersDict[675]="D2"
customersDict[855]="cert.org"
customersDict[859]="techcrime.ca"
customersDict[846]="ARMY_1IO"
customersDict[2223]="LockHeed_test_1"
customersDict[2224]="HomeDepotClass"
customersDict[2225]="UEH_April09"
customersDict[2226]="UEH_UK_April09"
canvasgui_glade_file = "gui/canvasgui2_%s.glade" % canvas_platform


# QA.list import, only things that have been QA'd get shipped

modulesdir = "exploits"
exploitslist = []
silicalist=[]
# EXPLOITS EXPLOITS EXPLOITS

#clientside
exploitslist += ["clientside/windows/speech"] #added Oct 10


# HCN Rootkit
# As of today - August 6th 2015 - HCN is deprecated
# - Can't find the source code for the rootkit
# - Bugs
# - Basically ticket #138

# exploitslist += ["trojan/hcn_load"]
# exploitslist += ["trojan/hcn_unload"]
# exploitslist += ["trojan/hcn_beaconconfig"]
# exploitslist += ["trojan/hcn_beaconlistener"]
# exploitslist += ["trojan/hcn_hidedirectory"]
# exploitslist += ["trojan/hcn_hideprocessbypid"]
# exploitslist += ["trojan/hcn_hideregistrykey"]
# exploitslist += ["trojan/hcn_hidenetstat"]

# windows
exploitslist += ["remote/windows/cam"]
exploitslist += ["remote/universal/nss"]
exploitslist += ["remote/windows/ms04_007"]
exploitslist += ["remote/windows/mssqlhello"]
#exploitslist += ["msrpcheap"] #removed because it doesn't work
exploitslist += ["clientside/windows/ms06_014"]
exploitslist += ["clientside/windows/wmf_setabort"]
# This is broken we shouldnt be using it
#exploitslist += ["iisphonebook"]
exploitslist += ["remote/windows/abyss"]
exploitslist += ["remote/unix/webmin"]
exploitslist += ["remote/windows/vsploit_exchangepop3"]

#exploitslist += ["iis5printer"] #PURGED (replaced by ms01_023)
exploitslist += ["remote/windows/eznet"]
#exploitslist += ["lsass"] #PURGED (replaced by ms04_011)
exploitslist += ["DoS/msrpccrash"]
exploitslist += ["remote/windows/w3who"]
exploitslist += ["remote/windows/IAWebMail"]
exploitslist += ["remote/windows/Insight"]
exploitslist += ["remote/windows/blackice"]
exploitslist += ["remote/windows/slwebsupervisor"]
exploitslist += ["remote/windows/mdaemon"]
exploitslist += ["remote/windows/ut2004secure"]
exploitslist += ["remote/windows/fp30reg"]
exploitslist += ["remote/windows/harborlisten"]
#exploitslist += ["ms03026"] #PURGED (replaced by ms03_026)
exploitslist += ["remote/windows/mssqlresolvestack"]
exploitslist += ["remote/windows/apachechunk_win32"]
exploitslist += ["remote/windows/WS_FTPD"]
exploitslist += ["remote/windows/naimas32"]
exploitslist += ["remote/windows/msxexch50"]
#exploitslist += ["iis5ida"] #PURGED (replaced by ms01_033)
exploitslist += ["remote/windows/realserver"]
exploitslist += ["remote/windows/iis5asp"]
exploitslist += ["remote/windows/icecast"]
exploitslist += ["remote/windows/niprint"]
exploitslist += ["remote/windows/mswinstcp"]
exploitslist += ["web/blindisapi"]
exploitslist += ["remote/windows/norton_upx"]
exploitslist += ["remote/windows/ms04_011_sslpct"]
exploitslist += ["remote/windows/ms04_011_lsass"]
#exploitslist += ["iis5webdav"] #PURGED (replaced by ms03_007)
#exploitslist += ["msworkstation"] #PURGED (replaced by ms03_049)
exploitslist += ["DoS/realserver2"]
exploitslist += ["tool/smbbrute"]
exploitslist += ["remote/windows/awservices"]
#exploitslist += ["iis5mediaservices"] #PURGED (replaced by ms03_022)
#exploitslist += ["iis5nsiislog2"] #PURGED (replaced by ms03_022)
#exploitslist += ["llssrv"] #PURGED (replaced by ms05_010)
exploitslist += ["remote/windows/savant"]
#exploitslist += ["brightstor"] #renamed brightstor_discovery
#exploitslist += ["mqsvc"] #PURGED (replaced by ms05_017)
exploitslist += ['remote/windows/ms05_017']
exploitslist += ["remote/windows/ca_lic"]
exploitslist += ["remote/windows/radexecd"]
exploitslist += ["remote/windows/ms05_021"]
exploitslist += ["remote/windows/imail_imap"]
#exploitslist += ["locator"] #PURGED (replaced by ms03_001)
exploitslist += ["remote/windows/zen"]
exploitslist += ["remote/windows/ipswitch_cal"]
exploitslist += ["web/MEWebMail"]
exploitslist += ["remote/windows/oracle8listener_win32"]
exploitslist += ["tool/find_null_vnc"]
exploitslist += ["remote/windows/mailenable_imap"]
exploitslist += ["remote/windows/veritas_decrypt"]
exploitslist += ["remote/windows/mailenable"]
exploitslist += ["remote/windows/ms05_039"]
exploitslist += ["remote/windows/ms05_043"] #added Jan 2nd, 2007 (for canvas release)
#exploitslist += ["spooler"]
exploitslist += ["local/windows/ms05_040"]
#exploitslist += ["ms_netware"] #PURGED (replaced by ms05_046)
exploitslist += ["DoS/ms_msdtc"]
#exploitslist += ["goldenftp"] #does not work
exploitslist += ["remote/windows/worldmail"]
exploitslist += ["remote/windows/vsploit_winprox"]
exploitslist += ["remote/windows/vsploit_winamp512"]
exploitslist += ["remote/windows/vsploit_mercurimap"]
exploitslist += ["remote/universal/realvnc_noauth"]
exploitslist += ["clientside/windows/gapple_client"]
exploitslist += ["remote/windows/groupwise_messenger"]
exploitslist += ["remote/windows/wingate_httpproxy"]
exploitslist += ["remote/windows/ms06_025b"]
exploitslist += ["remote/windows/ms06_025"]
exploitslist += ["remote/windows/smartag_word"]
exploitslist += ["clientside/windows/ms06_024"]
exploitslist += ["remote/windows/ms06_040"]
exploitslist += ["clientside/windows/ms06_055"]
#exploitslist += ["SALVO_outlook"]
exploitslist += ["remote/windows/imail_rcptoverflow"]
exploitslist += ["DoS/Exchange_DoS"]
exploitslist += ["remote/windows/ws_ftpd_xcrc"]
exploitslist += ["clientside/windows/ms06_057"]
exploitslist += ["remote/windows/ms06_066"]
exploitslist += ["remote/windows/ms06_070"]
exploitslist += ["remote/windows/edirectory_http"]
exploitslist += ["clientside/windows/ms06_071"]
exploitslist += ["remote/windows/nwspool_a"]


#exploitslist += ["heroes"] PURGED (replaced by ms06_074)
exploitslist += ["remote/windows/symantec_rm"]
exploitslist += ["remote/windows/netmail"]
exploitslist += ["remote/windows/ms01_023"]
exploitslist += ["remote/windows/ms01_033"]
exploitslist += ["remote/windows/ms03_022"]
exploitslist += ["remote/windows/ms04_045"]
exploitslist += ["remote/windows/ms03_026"]
exploitslist += ["remote/windows/ms03_001"]
exploitslist += ["remote/windows/3comtftp"]
exploitslist += ["remote/windows/iis_doubledecode"]
exploitslist += ["remote/windows/citrix_pp"]
exploitslist += ["remote/windows/ms04_031"]
#exploitslist += ["ms04_011_lsass"]

#exploitslist += ["danfs_pp"] #still being QA'd for SP2
exploitslist += ["clientside/windows/qt_rtsp"] #quicktime client side
exploitslist += ["clientside/windows/ms07_004"] #VML
exploitslist += ["remote/windows/ms03_049"]
exploitslist += ["DoS/ms07_031"]

exploitslist += ["remote/windows/wftpd"]
exploitslist += ["remote/windows/easyfilesharing"]
exploitslist += ["remote/windows/cesarftp"]
exploitslist += ["remote/windows/filecopa"]
exploitslist += ["remote/windows/MercurImapSubscribe"]
exploitslist += ["remote/windows/netmail_webadmin"]
exploitslist += ["remote/windows/tm_sprotect"]
exploitslist += ["remote/windows/samiftp"]
exploitslist += ["remote/windows/warftp_165"]
exploitslist += ["clientside/windows/utorrent"]
exploitslist += ["remote/universal/snortrpc"]
exploitslist += ["clientside/windows/ani_cursor"]

exploitslist += ["remote/windows/domino_cram"]
#exploitslist += ["STOIC"] #replaced by ms07_019
#exploitslist += ["msdnsrpc"] #PURGED
exploitslist += ["remote/windows/groupwise_webaccess"]
#exploitslist += ["ca_mediasvr"] #renamed brightstor_media
exploitslist += ["remote/windows/tm_sprotectagent"]
exploitslist += ["remote/windows/ms07_029"]
exploitslist += ["remote/windows/borland_ib"]
exploitslist += ["remote/windows/nwspool_b"] #not there yet?
exploitslist += ["remote/windows/ms06_074"]
exploitslist += ["remote/windows/ms05_046"]
exploitslist += ["DoS/ms07_019"]
exploitslist += ["remote/windows/ms05_010"]
exploitslist += ["remote/windows/brightstor_discovery"]
exploitslist += ["remote/windows/brightstor_message"]
exploitslist += ["remote/windows/brightstor_media"]
exploitslist += ["remote/windows/openview_trace"]
exploitslist += ["remote/windows/ms03_007"]

#September 2007
exploitslist += ["remote/windows/vmware_dhcpd"]
exploitslist += ["remote/windows/tivoli_storage"]
exploitslist += ["remote/windows/xitami"]
exploitslist += ["clientside/windows/ms07_051"]
exploitslist += ["remote/windows/netbackup_javaui"]

#October 2007
exploitslist += ["remote/windows/db2_jdbc"]
exploitslist += ["clientside/windows/real_import"]
exploitslist += ["local/windows/ms07_067"]
exploitslist += ["clientside/windows/iepdf"]
exploitslist += ["clientside/windows/ie7wmp"]
exploitslist += ["clientside/windows/gomplayer"]
exploitslist += ["remote/unix/xfs_swapchar2b"]

# PHP bugs
exploitslist += ["web/flatchat2_exec"]
exploitslist += ["web/dfblog4_exec"]
exploitslist += ["web/blog_pixelmotion"]
exploitslist += ["web/lsgb_exec"]
exploitslist += ["web/aimstats_exec"]
exploitslist += ["web/mygallery_remote"]
exploitslist += ["web/shoutpro_exec"]
exploitslist += ["web/wordtube_remote"]
exploitslist += ["web/wptable_remote"]
exploitslist += ["web/geeklog2_remote"]
exploitslist += ["web/phphtml_remote"]
exploitslist += ["web/xoops_cjcontent"]
exploitslist += ["web/xoops_tinycontent"]
exploitslist += ["web/mazensphpchat_remote"]
exploitslist += ["web/sitellite_remote"]
exploitslist += ["web/xoops_horoscope"]
exploitslist += ["web/xoops_xtconteudo"]
exploitslist += ["web/persism_remote"]
exploitslist += ["web/WAnewsletter_remote"]
exploitslist += ["web/xoops_icontent"]

# august 29 modules from ryan
exploitslist += ["web/adminbot_include"]
exploitslist += ["web/cep_include"]
exploitslist += ["web/flip_include"]
exploitslist += ["web/frontaccount_include"]
exploitslist += ["web/gallery1_include"]
exploitslist += ["web/gneric_include"]
exploitslist += ["web/lavague_include"]
exploitslist += ["web/linksnet_include"]
exploitslist += ["web/ncaster_include"]
exploitslist += ["web/news2_include"]
exploitslist += ["web/ote_include"]
exploitslist += ["web/pbd_include"]
exploitslist += ["web/philex_include"]
exploitslist += ["web/phpnews_include"]
exploitslist += ["web/someryc_include"]
exploitslist += ["web/troforum_include"]

#added on Aug 1st release
exploitslist += ["web/b1gbb_include"]
exploitslist += ["web/limesurvey_include"]
exploitslist += ["web/minibill_include"]
exploitslist += ["web/musoo_include"]
exploitslist += ["web/powl_include"]
exploitslist += ["web/serweb_include"]
exploitslist += ["web/sunboard_include"]
exploitslist += ["web/dagger_include"]
exploitslist += ["web/lms_include"]
exploitslist += ["web/mknoboard_include"]
exploitslist += ["web/phpsitebackup_include"]
exploitslist += ["web/ripecms_include"]
exploitslist += ["web/sphpell_include"]

#added on Oct 1st Release
exploitslist += ["web/cmsmadesimple_eval",
                 "web/joomla_eval",
                 "web/phpbb_highlight",
                 "web/ajaxfb_include",
                 "web/offl_include",
                 "web/txxcms_include",
                 "web/anyinventory_include",
                 "web/phpffl_include",
                 "web/webed_include",
                 "web/izicontents_include",
                 "web/enetman_include",
                 "web/joomlaradiov5_include",
                 "web/phpmytourney_include",
                 "web/helplink_include",
                 "web/dfdcart_include",
                 "web/phpbg_include",
                 "web/nuclearbb_include",
                 "web/phprealty_include",
                 "web/wordsmith_include",
                 "web/phpbbplus_include",
                 "web/streamline_include"]


# December 2007 release
exploitslist += ["clientside/windows/qt73_rtsp",
                 "clientside/windows/ssreader",
                 "clientside/windows/installshield",
                 "web/awzmb_include",
                 "web/livealbum_include",
                 "remote/universal/lshttpd_disc",
                 "web/nuboard_include",
                 "web/ossigeno_include",
                 "web/peopleaggregator_include",
                 "web/phpdj_include",
                 "web/phppm_include",
                 "web/phpwcms_include",
                 "web/pindorama_include",
                 "web/scwiki_include",
                 "web/segue_include",
                 "web/sige_include",
                 "web/smf_exec",
                 "web/tikiwiki_exec",
                 "web/towel_include",
                 "web/trionic_include",
                 "web/vportal_include",
                 "web/webdesktop_include"]

# January 2008 release
exploitslist += ["clientside/universal/ooo_230",
                 "remote/windows/ms07_065",
                 "web/punbb_langexec"]

# February 2008 release
exploitslist += ["web/phpmybb1210_include",
                 "web/coppermine",
                 ]

# March 2008 release
exploitslist += ["remote/windows/ms08_001",
                 "remote/unix/gpsd",
                 "clientside/windows/acrobat_js",
                 "web/journalness_exec",
                 "web/lookstrike_include",
                 "web/openads_exec",
                 "web/openrealty_exec",
                 "web/pacercms_exec",
                 "web/phpprofiles_include",
                 "web/phpqladmin_include",
                 "web/phpuserbase_include",
                 "web/portallwebphp_include",
                 "web/qgs_include",
                 "web/cutenews_exec",
                 "web/joomla12pic_include",
                 "web/joomlachronoforms_include",
                 "web/joomlacolorlab_include",
                 "web/joomlaflashfun_include",
                 "web/joomlaflashup_include",
                 "web/joomlajcs_include",
                 "web/joomlajuser_include",
                 "web/joomlamosdirectory_include",
                 "web/joomlamosmedia_include",
                 "web/joomlamp3_include",
                 "web/joomlaslideshow_include",
                 "web/joompana_include",
                 "web/lamasoft_include",
                 "web/loudblog_exec",
                 "web/mindmeld_include",
                 "web/netrisk_include",
                 "web/phplinks_include",
                 "web/smallaxe_include",
                 "web/smartpub_exec",
                 "remote/windows/nwspool_c",
                 ]

# April 2008 release
exploitslist += ["local/unix/vmsplice"]
exploitslist += ["local/windows/ms07_066"]
exploitslist += ["remote/unix/asus_samba"]
exploitslist += ["web/barryvan_include"]
exploitslist += ["web/groupe_include"]
exploitslist += ["web/phporacle_include"]
exploitslist += ["web/podcastgen_include"]
exploitslist += ["web/wpsniplets_exec"]

# may 2008 release
exploitslist += ["clientside/windows/flash_duke"]
# exploitslist += ["fuzzer"] # A. 2015: Not in the tree
exploitslist += ["remote/unix/wuglob"]
exploitslist += ["local/windows/ms08_025"]
exploitslist += ["command/universal/diskspider"]


#daniel rootkit Jul 10
exploitslist += ["trojan/loadlinrootkit"]
exploitslist += ["trojan/linrootkitinject"]

# o dave
wwwlist = "web/dragoon_include web/joomlacp_include web/phpblock_include web/wpflash_include web/fuzzylime_include web/joomlaoflq_include web/quinsonnas_include web/grape_include web/newsoffice_include web/visualpic_include web/jafcms_include web/phpauction_include web/wpbackup_include".split(" ")
for w in wwwlist:
    exploitslist+=[w]

#fuzzers
exploitslist += ["fuzzer/msrpcfuzz"] #may 1 release
exploitslist += ["fuzzer/tftp_fuzzer"] #may 1 release

# August Release 2008
exploitslist += ["clientside/windows/firefox_definesetter"]


##########################################
#older stuff
# solaris
exploitslist += ["remote/unix/sunlogin"]
exploitslist += ["remote/unix/rexd"]
exploitslist += ["remote/unix/sadmind"]
exploitslist += ["remote/unix/ttdb_xdrarray"]
exploitslist += ["remote/unix/cmsd_xdrarray"]
exploitslist += ["remote/unix/dtspcd"]
exploitslist += ["remote/unix/sunlogin_pamh"]
exploitslist += ["remote/unix/in_lpd"]
exploitslist += ["remote/unix/cachefsd_lpd"]
exploitslist += ["remote/unix/iplanet_chunked"]
exploitslist += ["remote/unix/solaris_samba"]


# UNTESTED
exploitslist += ["remote/unix/ypbind"]
exploitslist += ["remote/unix/yppasswdd"]
exploitslist += ["remote/unix/snmpXdmid"]

# UNPORTED !!!
#exploitslist += ["answerbook2"]
#exploitslist += ["kcms_server"]
#exploitslist += ["aolserver_solaris"]

# linux
exploitslist += ["remote/unix/sapdb"]
exploitslist += ["remote/unix/rsync"]
exploitslist += ["remote/unix/openssl_keylen"]
exploitslist += ["remote/unix/svndate"]
exploitslist += ["remote/unix/wuftpd_sexec"]
exploitslist += ["remote/unix/pserverd"]
exploitslist += ["remote/unix/php_limit"]
exploitslist += ["remote/unix/samba_nttrans"]
exploitslist += ["remote/universal/mysql_auth_bypass"] #looks ported to me! (dave)
exploitslist += ["remote/unix/samba_trans2"]
exploitslist += ["remote/unix/stinky"]
exploitslist += ["remote/unix/stinky_debug"]
exploitslist += ["remote/unix/linksys_apply_cgi"]
exploitslist += ["local/unix/chfnescape"]
exploitslist += ["remote/unix/horde_eval"] #really any unix
exploitslist += ["web/php_includetest"] #for Ryan
exploitslist += ["remote/unix/solaris_telnet"]
exploitslist += ["remote/windows/openview_trace"]
# new websploits

# useful if you want to run only 1 exploit with silica/autohack

#added Aug 1, 07
exploitslist += ["remote/unix/netopia_adsl"]

#OS X Exploits
exploitslist += ["remote/unix/mu"]

# UNPORTED !!!
#exploitslist += ["proftpd"]
#exploitslist += ["proftpd_off_by_one"]
#exploitslist += ["proftpd_off_by_two"]
#exploitslist += ["aolserver4"]
#exploitslist += ["mysql_stmt_execute"]

# local exploits
# windows
exploitslist += ["local/windows/GDIWrite4"]
exploitslist += ["local/windows/msimpersonate"]
exploitslist += ["local/windows/localLPC"]
exploitslist += ["local/windows/winpcap"]
# solaris
exploitslist += ["local/unix/solaris_LD_PRELOAD"]
# linux
exploitslist += ["local/unix/DSU"]
exploitslist += ["local/unix/PROCFS"]


#VMWare Exploits
exploitslist += ["remote/windows/vmware_dhcpd"]

# May 29, 2008
exploitslist += ["clientside/windows/foxit_printf"]
exploitslist += ["remote/windows/bigant22"]
exploitslist += ["local/windows/i2omgmt"]

# COMMANDS AND TOOLS

# recon
reconlist=[]
reconlist += ["recon/smtp_fingerprint"]
reconlist += ["recon/traceroute"]
reconlist += ["recon/dcedump"]
reconlist += ["recon/portscan"]
reconlist += ["recon/portsweep"]
reconlist += ["recon/udpsweep"]
reconlist += ["recon/mssqlresolve"]
reconlist += ["tool/autohack"]
reconlist += ["recon/testhost"]
reconlist += ["recon/spdetect"]
reconlist += ["recon/rpcdump"]
reconlist += ["recon/osdetect"]
reconlist += ["recon/telnetbanner"]
reconlist += ["recon/userenum"]
reconlist += ["recon/getservices"]
reconlist += ["recon/httpfingerprint"]
reconlist += ["server/httpserver"]
reconlist += ["server/httpuploader"] #added 6.36
reconlist += ["importexport/importscan"]
reconlist += ["recon/shareenum"]
reconlist += ["trojan/connecttoservice"]
reconlist += ["command/windows/touchfromfile"]
reconlist += ["recon/getremotelanguage"]
#added in Aug 1, 07 release
reconlist += ["recon/getwwwhostnames"]
#added Dec 1 08 releae
reconlist += ["tool/autoassess"]
reconlist += ["tool/VulnAssess2"]

exploitslist+=reconlist
silicalist+=reconlist

# general
generallist=[]
generallist += ["command/windows/createservice"]
generallist += ["command/universal/checkvm"]
generallist += ["tool/emailsender"]
generallist += ["command/universal/unlink"]
generallist += ["command/universal/ps"]
generallist += ["command/universal/killprocess"]
generallist += ["tool/addhostsfromfile"]
generallist += ["command/windows/exitthread"]
generallist += ["command/universal/exitprocess"]
generallist += ["command/windows/setthreadtoken"]
generallist += ["tool/addhost"]
generallist += ["command/universal/getcwd"]
generallist += ["command/universal/runcommand"]
generallist += ["command/universal/gethostbyname"]
generallist += ["command/universal/tcphostfind"]
generallist += ["command/universal/chdir"]
generallist += ["command/universal/upload"]
generallist += ["command/universal/download"]
generallist += ["command/universal/startup"]
generallist += ["command/windows/screengrab"]
generallist += ["command/universal/drinkcoaster"]
generallist += ["command/windows/getkey"]
generallist += ["command/universal/whoami"]
generallist += ["recon/whereami"]
generallist += ["command/windows/getthreadsinfo"]
generallist += ["command/universal/dir"]
generallist += ["command/windows/arpscan"]
generallist += ["command/universal/getpid"]
generallist += ["command/universal/computername"]
generallist += ["command/windows/processinject"]
generallist += ["command/windows/getpriv"]
generallist += ["command/windows/addnullshare"]
generallist += ["command/universal/spawn"]
generallist += ["command/windows/touch"]
generallist += ["command/windows/getprocessname"]
generallist += ["command/windows/getpasswordhashes"]
generallist += ["command/universal/rmdir"]
generallist += ["command/windows/startservice"]
generallist += ["command/windows/enumservices"]
generallist += ["tool/compile"]
generallist += ["remote/windows/mssql_auth"]
generallist += ["remote/unix/unixshellfromport"]
generallist += ["command/windows/stopservice"]
generallist += ["command/windows/restartservice"]
generallist += ["tool/smbclient"]
generallist += ["command/windows/deleteservice"]
generallist += ["trojan/installmosdefservice"]
generallist += ["importexport/importscan"]
generallist += ["server/spikeproxy"]
generallist += ["command/windows/getallprocessdata"]
generallist += ["command/unix/switch_user"]
generallist += ["trojan/installremotemosdefservice"]
generallist += ["command/windows/startremoteservice"]
generallist += ["command/windows/GetUserActive"]
generallist += ["recon/ifids"]
generallist += ["command/windows/keylog"]
generallist += ["command/windows/mosdefmigrate"]
generallist += ["config/configuration"]
generallist += ["config/remark_in_log"]
generallist += ["importexport/nessusxml"]
generallist += ["importexport/nmapxml"]
generallist += ["remote/universal/ftpd_check"]
generallist += ["command/windows/callbackloop"]
generallist += ["recon/getprintproviders"]
generallist += ["command/universal/upexec"]
generallist += ["tool/atsvc"] #win32 only
generallist += ["command/windows/ExitWindows"]
generallist += ["trojan/BuildCallbackTrojan"] #added Oct 4/2007
generallist += ["command/universal/adduser"]#added Jan 15 09
generallist += ["command/universal/deluser"]#added Jan 15 09
silicalist  += generallist

#added Aug 1, 2007
generallist += ["tool/smtp_mass_scan"]
generallist += ["command/universal/converttomosdef"]
silicalist  += ["command/universal/converttomosdef"]

#May 1st 2008
#some token stuff
generallist += ["command/windows/DuplicateToken"]
generallist += ["command/windows/LogonUser"]
#generallist += ["CreateProcessAsUser"]
silicalist  += ["command/windows/LogonUser", "command/windows/DuplicateToken"]

#May 29, 2008
generallist  += ["command/windows/disable_windows_defender"]
silicalist   += ["command/windows/disable_windows_defender"]

#June 1st 2008
generallist += ["tool/ssh_brute"]
generallist += ["tool/debian_ssh_key_brute"] #key auth bug
generallist += ["clientside/windows/binder"] #OLE2 binder (needs Resources/templates)
generallist += ["local/windows/i2omgmt"]
generallist += ["remote/windows/bigant22"]

# July 2nd 2008
generallist += ["local/windows/ms08_034"]
generallist += ["remote/unix/shoutcast_fs"]
generallist += ["web/booby_include"]
generallist += ["remote/windows/altn_sg"]
generallist += ["remote/unix/sol_printer_conf"]
generallist += ["web/browsercrm_include"]

# August Release 2008
generallist += ["command/universal/memory_harvest"]
generallist += ["command/windows/get_dnscache"]
generallist += ["web/trixbox_exec"]

# September Release 2008
generallist += ["local/windows/ms08_049"]
generallist += ["web/dokuwiki_exec"]
generallist += ["web/e107_exec"]
generallist += ["remote/windows/citrix_metaframe"]

# October Release 2008
generallist += ["remote/windows/citect_scada"]
generallist += ["clientside/windows/firefox_utf8"]
generallist += ["clientside/windows/ms08_053"]

# November Release 2008
generallist += ["remote/windows/ms08_062"]
generallist += ["DoS/ms08_063"]
generallist += ["remote/windows/ms08_059"]
generallist += ["remote/windows/ms08_067"]
generallist += ["command/windows/injectdll"]
generallist += ["local/unix/CVE_2007_4003"]
generallist += ["local/unix/CVE_2007_4513"]
generallist += ["local/unix/aixroot"]
generallist += ["remote/windows/iis_webdav"]
generallist += ["clientside/windows/acrobat_js3"]
generallist += ["web/mantis113"]
generallist += ["trojan/ram_dumper"]

# December Release 2008
generallist += ["remote/windows/lotus_domino_http"]
generallist += ["remote/windows/goodtech_ssh"]
generallist += ["web/smf_exec_gif"]
generallist += ["server/icmp_proxy"]
generallist += ["tool/massattack2"]

# January Release 2009
generallist += ["server/ms08_068"]
generallist += ["clientside/windows/ms08_078"]
generallist += ["web/roundcube"]
generallist += ["recon/icmpsweep"]
generallist += ["command/windows/arpscan"]
generallist += ["recon/udpportscan"]
generallist += ["recon/ipfingerprint"]
generallist += ["recon/ipheuristic"]
silicalist  += ["recon/ipfingerprint"]
silicalist  += ["irecon/pheuristic"]
silicalist  += ["irecon/cmpsweep"]

# February Release 2009
exploitslist += ["local/unix/CVE_2004_1329"]
exploitslist += ["DoS/ms09_001"]
exploitslist += ["remote/windows/mssql_replwritetovarbin"]
exploitslist += ["web/smf_csrf"]
exploitslist += ["trojan/BuildHTTPCallback"]

# March Release 2009
exploitslist += ["clientside/windows/ms09_002"]
exploitslist += ["web/sourdough_include"]
exploitslist += ["web/phplist_lfi"]
exploitslist += ["web/phpslash_rce"]
exploitslist += ["web/1024cms_rfi"]
exploitslist += ["web/phpyabs_rfi"]
exploitslist += ["command/windows/GetBrowserInfo"]
exploitslist += ["command/windows/GetAddressBookInfo"] ##Dont forget associated resources - "Resources/Redemption.dll" & "Resources/getOutlookAddressBook.vbs"
exploitslist += ["recon/dnsfind"]  ##Dont forget associated resources - "Resources/dns.txt" & "Resources/dns-short.txt"

# April Release 2009
exploitslist += ["command/unix/NetworkManagerUnSecret"]  ##Dont forget associated resource - "Resources/nm.py
exploitslist += ['server/http_proxy']
exploitslist += ["clientside/windows/mosdef_activex"]
exploitslist += ["clientside/windows/foxit_Action"]
exploitslist += ["clientside/windows/FoxitLaunchit"]
exploitslist += ["clientside/windows/acrobat_js4"]
exploitslist += ["clientside/windows/acrobat_jbig"]

# May Release 2009
# exploits
exploitslist += ["clientside/universal/java_deserialize"]
exploitslist += ["local/unix/udevd"]
# dos
exploitslist += ["DoS/ms09_013"]
exploitslist += ["DoS/pgpwdef"]
# modules
exploitslist += ["recon/urlmangle"]
exploitslist += ["command/windows/saycheese"]
exploitslist += ["command/windows/motiondetect"]
# exploitslist += ["facedetection"] # deprecated
# rich's thingamabobber
exploitslist += ["remote/windows/VAASeline_Control"]

# June Release 2009
# exploits
exploitslist += ["local/windows/CLOUDBURST"]
#Commands
exploitslist += ["command/windows/WiFi_Key_Dumper"]
exploitslist += ["command/windows/recordaudio"]
exploitslist += ["command/windows/recordvideo"]

# web exploits
exploitslist += ["web/joomlagooglebase_rfi"]
exploitslist += ["web/joomlarss_rfi"]
exploitslist += ["web/dokeos_rce"]
exploitslist += ["web/phplinkadmin_rfi"]
exploitslist += ["web/slogin_rfi"]
exploitslist += ["web/pluck_lfi"]

# July Release 2009
exploitslist += ["remote/windows/ms09_022"]
exploitslist += ["remote/windows/ms09_022_loaddll"]
exploitslist += ['clientside/windows/greendam_url']
exploitslist += ['local/unix/solroot']
exploitslist += ['local/unix/CVE_2006_4842']
exploitslist += ['remote/unix/aixttdb']
exploitslist += ['command/windows/cleareventlog']
exploitslist += ['web/phpmyadmin_injection']
exploitslist += ['web/sugarcrm_fileupload']
exploitslist += ['web/joomlacompetitions_rfi']
exploitslist += ['web/joomladadamail_rfi']
exploitslist += ['web/dokuwiki_exec2']
exploitslist += ['recon/dot_dot_slash']
exploitslist += ['web/joomlarss_rfi']
exploitslist += ['web/pnphpbb2_lfi']
exploitslist += ['web/joomlaclickheat_rfi']
exploitslist += ['web/joomlatimesheet_rfi']
exploitslist += ['web/joomlafeedrator_rfi']
exploitslist += ['clientside/universal/safari_file_stealing']
exploitslist += ['clientside/universal/safari_file_stealing2']
exploitslist += ['remote/windows/symantec_iao']

#August 2009
exploitslist += ['clientside/windows/ms09_032']
exploitslist += ['DoS/ms09_029']
exploitslist += ['clientside/windows/firefox_35']
exploitslist += ['clientside/windows/acrobat_flash']
exploitslist += ['web/nagios_ping']
exploitslist += ['web/zencart_remote']

#September 2009
exploitslist += ['local/unix/proto_ops_null']
exploitslist += ['DoS/ms09_041']
exploitslist += ['remote/windows/iisftp_nlst']
exploitslist += ['DoS/iisftp_globbing']
exploitslist += ['server/clientd']
exploitslist += ['clientside/universal/js_recon']
exploitslist += ['tool/ssh_reverse_tunnel']
exploitslist += ['web/easypx41_lfi']
exploitslist += ['web/adaptcms_rfi']
exploitslist += ['web/worksimple_rfi']
exploitslist += ['web/phpskelsite_rfi']
exploitslist += ['web/acutecp_rfi']
exploitslist += ['web/joomlatreeg_rfi']
exploitslist += ['web/joomlaartform_rfi']

#October 2009
exploitslist += ['local/windows/smb2_negotiate_local']
exploitslist += ['remote/windows/smb2_negotiate_remote']
exploitslist += ['web/wpsniplets_rfi']
exploitslist += ['web/strawberry_lfi']
exploitslist += ['web/sitex_lfi']
exploitslist += ['web/cpcommerce_rfi']
exploitslist += ['web/quickteam_rfi']

#November 2009
exploitslist += ['clientside/windows/java_deserialize_win32']
exploitslist += ['command/windows/modify_registry']
exploitslist += ['recon/zeroconf_recon']
exploitslist += ['clientside/windows/ms09_051']
exploitslist += ['DoS/ms09_059']
exploitslist += ['remote/unix/aixcmsd']
exploitslist += ['clientside/windows/acrobat_u3d_mesh']

#December 2009
exploitslist += ['clientside/windows/sun_java_hsbparser']
exploitslist += ['clientside/unix/sun_java_hsbparser_linux']
exploitslist += ["tool/telnet_brute"]
exploitslist += ["clientside/windows/ms09_061_cas"] #.Net Clientside
exploitslist += ["DoS/windows7netbioscrash"]

#January 2010
exploitslist += ['remote/unix/hplaserjet_connect']
exploitslist += ['clientside/windows/acrobat_newplayer']
exploitslist += ['web/test_safemode_bypass']

#February 2010
exploitslist += ['local/unix/usort_safemode']
exploitslist += ['clientside/windows/aurora_flash']
exploitslist += ['remote/unix/nginx']
exploitslist += ['web/piwik']
exploitslist += ['local/windows/ms_ntvdm']
exploitslist += ["clientside/windows/ie_comments"]
exploitslist += ["command/unix/setuid"]

#March 2010
exploitslist += ["command/windows/GetLocale"]
exploitslist += ["command/windows/disable_windows_firewall"]
exploitslist += ["remote/windows/brightstor_cmdexec"]
exploitslist += ["clientside/windows/ie_dumpfiles"]

#April 2010
exploitslist += ["command/windows/GetDrives"]
exploitslist += ["clientside/windows/ie_help"]
exploitslist += ["server/xserver"]
exploitslist += ['command/unix/pty_shell']
exploitslist += ["clientside/windows/acrobat_libtiff"]
exploitslist += ["clientside/windows/ie_peers_setattribute"]
exploitslist += ["clientside/windows/acrobat_exec"]
# exploitslist += ["autoprivesc"] # check canmine #97 for more info

#May 2010
exploitslist += ["command/windows/getloggedinhashes"] #64-bit support not yet included in this module
exploitslist += ["clientside/universal/java_deserialize2"]
exploitslist += ["clientside/universal/java_method_chain"]
exploitslist += ["clientside/windows/acrobat_exec"]
exploitslist += ["remote/windows/ms10_025"]
exploitslist += ["clientside/windows/ms10_026"]

#June 2010
exploitslist += ["clientside/windows/ie_hcp"]
exploitslist += ["clientside/windows/flash_newfunction"]
exploitslist += ["local/windows/ms10_032"]

#July 2010
#removed for until WWW team says they're ready.
#exploitslist += ["WebCrawler"]
#exploitslist += ["WebCrawlerViewer"]

exploitslist += ["web/FCKEditor"]

#August 2010
exploitslist += ["clientside/windows/windows_shell_lnk"]
exploitslist += ["local/windows/ms10_048"]
exploitslist += ["clientside/windows/ms10_060"]

#September 2010
exploitslist += ["remote/windows/ms10_061"]
exploitslist += ["clientside/windows/flash_wild2"]
exploitslist += ["clientside/windows/trendmicro_setowned"]
exploitslist += ["clientside/windows/quick_punk"]
exploitslist += ["web/CF_directory_traversal"]
exploitslist += ["clientside/windows/acrobat_ttf_sing"]
exploitslist += ["remote/unix/xampp_webdav"]

#October 2010
exploitslist += ["local/windows/ms_kblayout"]
exploitslist += ["local/windows/ms_taskscheduler"]



#October 2010, 6.63
exploitslist += ["local/unix/CVE_2010_3847"]
exploitslist += ["local/windows/ms10_059"]
exploitslist += ["clientside/windows/java_docbase"]
exploitslist += ["remote/unix/padding_oracle"]
exploitslist += ["command/windows/getfileversion"]
exploitslist += ["command/windows/get_installed_updates"]

#November 2010, 6.64
exploitslist += ["local/unix/CVE_2010_3856"]
exploitslist += ["clientside/windows/firefox_appendchild"]
exploitslist += ["clientside/windows/ie_setuserclip"]
exploitslist += ["clientside/windows/adobe_flash_button"]
exploitslist += ["remote/universal/aspnet_download"]
exploitslist += ["local/windows/ms_tokenkidnapping"]
exploitslist += ["clientside/windows/adobe_shockwave_rcslchunk"]

#December 2010, 6.65
exploitslist += ["clientside/unix/CVE_2010_1807"]
exploitslist += ["remote/unix/CVE_2010_4344"]
exploitslist += ["local/windows/ms_enableeudc"]
exploitslist += ["clientside/windows/opera_css"]

#January 2011, 6.66
exploitslist += ["local/unix/linux_rds"]
exploitslist += ["DoS/ms10_068"]
exploitslist+=generallist

#February 2011, 6.67
exploitslist += ["clientside/unix/safari_parentstylesheet"]
exploitslist += ["clientside/unix/android_parentstylesheet"]
exploitslist += ["local/unix/android_hotplug"]

#April 2011, 6.68
exploitslist += ["local/unix/CVE_2011_0182"]
exploitslist += ["clientside/windows/ms11_003"]
exploitslist += ["local/windows/ms11_032"]
exploitslist += ["clientside/universal/safari_navaction"]

#May 2011, 6.69
exploitslist += ["local/unix/CVE_2011_1485"]
exploitslist += ["clientside/universal/CVE_2010_4452"]
exploitslist += ["command/unix/pcap_sniffer"]

#June 2011, 6.70
exploitslist += ['remote/unix/CVE_2011_0997'] # dhcp
exploitslist += ['importexport/qualysguard'] # replaces qgimport & qgverify
exploitslist += ['trojan/thunderbird_backdoor_deployer']
exploitslist += ['trojan/thunderbird_backdoor_manager']
exploitslist += ['web/tinymce_joomla']
exploitslist += ['remote/windows/wireshark_dect']
exploitslist += ['server/dns_proxy']

#August 2011, 6.71
exploitslist += ['trojan/BuildDNSCallback']
exploitslist += ['clientside/windows/flash_APSB11_18']
exploitslist += ['local/windows/ms11_054']

#September 2011, 6.72
exploitslist += ['web/jboss_jmxconsole_deployer']
exploitslist += ['clientside/windows/firefox_channelredirect']
exploitslist += ['clientside/windows/safari_renderdestroy']
exploitslist += ['trojan/BuildMOSDEFDLL']

#October 2011, 6.73
exploitslist += ['tool/jboss7_management_deployer']
exploitslist += ['recon/revproxybypass']

#November 2011, 6.74
exploitslist += ['clientside/universal/java_rhino']
exploitslist += ['tool/frontpage_rpc_fileupload']

#December 2011, 6.75
exploitslist += ['web/plone']
exploitslist += ['clientside/windows/pdf_u3d']
exploitslist += ['local/windows/ms11_080']
exploitslist += ['local/windows/ms11_098']

#January 2012, 6.76
exploitslist += ['clientside/windows/ms12_005']
exploitslist += ['remote/unix/dotnetnuke_formbypass']
exploitslist += ['clientside/windows/firefox_array_reduceright']

#February 2012, 6.77
exploitslist += ['local/unix/CVE_2012_0056']

#March 2012, 6.78
exploitslist += ['clientside/universal/java_AtomicReferenceArray']
exploitslist += ['clientside/universal/clientdsample']

#April 2012, 6.79
exploitslist += ['remote/unix/CVE_2012_1182']
exploitslist += ['remote/unix/CVE_2012_1182_NONX']
exploitslist += ['recon/smbversion']

#May 2012, 6.80
exploitslist += ['web/php_cgi_remote']
exploitslist += ['trojan/BuildWARCallbackTrojan']
exploitslist += ['recon/ip_to_vhosts']

#July 2012, 6.81
exploitslist += ['local/unix/SYSRET']
exploitslist += ['clientside/windows/ms12_027']
exploitslist += ['clientside/windows/ms12_004']
exploitslist += ['remote/universal/mysql_login_remote']
exploitslist += ['recon/mysql_version_detection']
exploitslist += ['web/strutsCodeInjection']
exploitslist += ['clientside/windows/adobe_flash_mp4_cprt']

#August 2012, 6.82
exploitslist += ['clientside/windows/ms12_043']
exploitslist += ['clientside/universal/java_forName_getField']
exploitslist += ['remote/unix/evocam']
exploitslist += ['clientside/windows/Itunes_10_6_1']
exploitslist += ['clientside/windows/cutezip_filename']
exploitslist += ['remote/windows/ezserver']
exploitslist += ['remote/windows/OSVDB_65361']
exploitslist += ['remote/windows/OSVDB_65361_0x6']
exploitslist += ['remote/windows/CVE_2011_3175']
exploitslist += ['remote/windows/CVE_2011_3176']

#November 2012, 6.83
exploitslist += ['recon/dellchassis']
exploitslist += ['recon/delldrac']
exploitslist += ['remote/windows/emc_networkerFS']
exploitslist += ['command/windows/passwordhints']
exploitslist += ['local/windows/ms12_042']
exploitslist += ['clientside/windows/ie_execCommand']
exploitslist += ['clientside/windows/ms12_037']
exploitslist += ['clientside/windows/adobe_flash_otf_parsing']
exploitslist += ['remote/windows/CVE_2010_3964']
exploitslist += ['command/windows/info_sessions']
exploitslist += ['command/windows/wlanlist']
exploitslist += ['recon/parallel_portscan']

#December 2012, 6.84
exploitslist += ['command/windows/keylog2mem']
exploitslist += ['clientside/universal/java_CVE_2012_5088']
exploitslist += ['clientside/universal/java_jaxws']

#February 2013, 6.85
exploitslist += ['command/windows/windows_sniffer']
exploitslist += ['clientside/universal/java_MBeanInstantiator_findClass']

#March 2013, 6.86
exploitslist += ['command/windows/threadio']
exploitslist += ['clientside/windows/adobe_flash_regexp']
exploitslist += ['remote/unix/CVE_2012_5613']

#May 2013, 6.87
exploitslist += ['command/universal/inject_from_mem']
exploitslist += ['clientside/universal/java_DynamicBinding']
exploitslist += ['local/windows/novell_nicm']
exploitslist += ['remote/unix/nginx_chunk']
exploitslist += ['remote/windows/mdaemon_control']

#July 2013, 6.88
exploitslist += ['web/moinmoin_rce']
exploitslist += ['local/unix/fs_pipe_race_to_null']
exploitslist += ['clientside/windows/acrobat_xfa']

#August 2013, 6.89
exploitslist += ['clientside/universal/java_generic_mosdef']
exploitslist += ['clientside/windows/ms13_056']
exploitslist += ['local/unix/maptrace']
exploitslist += ['local/unix/perf_swevent_init']

#October 2013, 6.90
exploitslist += ['local/unix/sudo_timestamp']

#December 2013, 6.91
exploitslist += ['local/windows/CVE_2013_3881']
exploitslist += ['clientside/windows/ie_cdisplaypointer']
exploitslist += ['command/windows/wordpress_backdoor']
exploitslist += ['command/windows/wordpress_backdoor_connect']

#January 2014, 6.92
exploitslist += ['clientside/windows/acrobat_toolbutton']
exploitslist += ['local/windows/ndproxy']
exploitslist += ['web/zabbix']
exploitslist += ['recon/wp_finger']

#April 2014, 6.93
exploitslist += ['clientside/windows/ie_cmarkup']
exploitslist += ['clientside/windows/ie_cardspaceclaimcollection']

#June 2014, 6.94
exploitslist += ['local/unix/recvmmsg']
exploitslist += ['local/unix/linux_ptrace_setregs']

#August 2014, 6.95
exploitslist += ['local/unix/linux_pppol2tp']
exploitslist += ['local/unix/linux_tty_race']
exploitslist += ['local/windows/mqac']
exploitslist += ['clientside/windows/firefox_nsSVGValue']
exploitslist += ['recon/owa_ipleak']

#November 2014, 6.96
exploitslist += ['local/unix/linux_futex_requeue']
exploitslist += ['clientside/windows/adobe_flash_copypixelstobytearray']
exploitslist += ['local/windows/ms14_040']
exploitslist += ['web/joomla_mm_rce']
exploitslist += ['local/windows/vbox_guest']
exploitslist += ['web/CVE_2014_5460']
exploitslist += ['web/wpdm_fileupload']
exploitslist += ['web/wptouch_nonce']
exploitslist += ['web/drupal_name_sqli']
exploitslist += ['web/drupal_name_sqli_callback']

#December 2014, 6.97
exploitslist += ['web/CVE_2014_5261']
exploitslist += ['web/wpsymposium_rce']
exploitslist += ['clientside/windows/sandworm']

#January 2015, 6.98
exploitslist += ['local/unix/osx_parsekeymapping']
exploitslist += ['remote/windows/ms14_068']
exploitslist += ['web/wpeasycart_rce']

#February 2015, 6.99
exploitslist += ['local/unix/osx_stickykeysfree']
exploitslist += ['command/windows/psexec']
exploitslist += ['command/universal/kerberos_ticket_list']
exploitslist += ['command/universal/kerberos_ticket_export']

#March 2015, 7.00
exploitslist += ['clientside/windows/ms14_064_ie_oleaut32']
exploitslist += ['recon/shareenum_ng']

#May 2015, 7.01
exploitslist += ['clientside/windows/adobe_flash_domainMemory_uaf']
exploitslist += ['local/windows/ms14_070']
exploitslist += ['local/unix/rootpipe']
exploitslist += ['clientside/windows/lnk_exec']
exploitslist += ['web/elasticsearch_CVE_2015_1427']
exploitslist += ['importexport/nexposeimport']
exploitslist += ['web/CVE_2014_9222']

#June 2015, 7.02
exploitslist += ['local/windows/ms15_051']
exploitslist += ['remote/unix/proftpd_mod_copy']
exploitslist += ['clientside/windows/adobe_flash_intoverflow_apply']

#July 2015, 7.03
exploitslist += ['clientside/windows/adobe_flash_valueof']
exploitslist += ['local/windows/atmfd_pool_buffer_underflow']
exploitslist += ['local/unix/osx_dyld_print_to_file']
exploitslist += ['importexport/avdsimport']

#August 2015, 7.04
exploitslist += ['local/unix/osx_rootpipe2']
exploitslist += ['local/windows/ESET_EpFwNDIS']
exploitslist += ['trojan/BuildPowershellCallback']
exploitslist += ['command/windows/powershellcommand']

#September 2015, 7.05
exploitslist += ['local/windows/ESET_LPC']
exploitslist += ['clientside/windows/ms15_100']
exploitslist += ['local/unix/overlayfs']
exploitslist += ['clientside/windows/hanword_exec']
exploitslist += ['command/windows/ad_getcomputers']
exploitslist += ['command/windows/ad_getlocalusers']
exploitslist += ['command/windows/ad_getdomainusers']
exploitslist += ['command/windows/ad_dlexecute_psmosdef']
exploitslist += ['command/windows/ad_check4PSadmin']
exploitslist += ['command/windows/converttopowershell']
exploitslist += ['command/windows/runpowershellscript']
exploitslist += ['web/citrix_netscaler_soap']

#October 2015, 7.06
exploitslist += ['local/unix/osx_rsh_libmalloc']
exploitslist += ['local/windows/ms14_025']
exploitslist += ['local/windows/ms15_102']
exploitslist += ['command/windows/reg_dump']
exploitslist += ['command/windows/dcsync']

#Next Release
exploitslist += ['command/windows/runpowershellscript']

#New reporting
exploitslist += ['reporting/canvas_report']

#SQL Injection tools
exploitslist += ["web/mssqlinject"]

#DoS
exploitslist += ["DoS/umpnp_dos"]
#
# reserve for oracle tools
oraclelist=[]
oraclelist += ["tool/oraclegetpwd"]
oraclelist += ["tool/oraclegetuser"]
oraclelist += ["tool/oraclegetinfo"]
silicalist += oraclelist
exploitslist+=oraclelist
#testing
exploitslist += ["web/test_cle"]

silicalist += ['remote/unix/asus_samba',
               'remote/windows/ms08_067',
               'clientside/universal/java_deserialize2',
               'remote/unix/basic_auth',
               'remote/unix/netopia_adsl',
               'tool/massattack2',
               'tool/VulnAssess2',
               'clientside/windows/ie_peers_setattribute',
               'clientside/unix/android_parentstylesheet',
               'local/windows/smb2_negotiate_remote',
               'tool/find_null_vnc',
               'server/clientd',
               'server/http_proxy',
               'clientside/universal/js_recon',
               'command/universal/silica_startup',
               'clientside/windows/flash_APSB11_18',
               'command/windows/WiFi_Key_Dumper',
               'command/windows/GetBrowserInfo',
               'command/windows/GetAddressBookInfo',
               'local/windows/ms11_054',
               'clientside/universal/java_AtomicReferenceArray',
               'clientside/windows/adobe_flash_mp4_cprt']

#Fuzzers
exploitslist += ["fuzzer/msrpcfuzz"] #Apr 22, 2008


libs=[]
# files that don't get auto added from libs, (not .xml, .html, .py) go here
#libs['libs/VAASeline/lib/__init__.py']
#libs/VAASeline/lib/VAASeline.py
#libs/VAASeline/vaaseline-demo.py
libs+=['libs/VAASeline/LICENSE']
libs+=['libs/VAASeline/cb_mon.vbs']
#libs/VAASeline/passive_cb_sniff.py
libs+=['libs/VAASeline/README']
libs+=['libs/VAASeline/password.dict']
#libs/VAASeline/__init__.py


# add dirs who get an __init__.py here
directory_with_init_list = [
    "encoder", "gui", "libs", "shellcode", "sounds", "db", "internal",
    "Nodes", "Nodes/mosdef_powershell", "MOSDEF", "MOSDEF/MOSDEFlibc", "MOSDEF/binfmt", "engine",
    "MOSDEFShellServer", "MOSDEF/MOSDEFlibc/asm", "MOSDEF/MOSDEFlibc/asm/Linux",
    "MOSDEF/MOSDEFlibc/asm/Solaris", "gui/WorldMap", "libs/pyPdf", "libs/pygeoip", "osdetection", "libs/opencv",
    "shellcode/standalone", "shellcode/standalone/windows", "shellcode/standalone/osx", "gui/gaphas", "gui/MeatMarket", "CLI",
    "libs/udns",
    "libs/udns/rdtypes",
    "libs/udns/rdtypes/ANY",
    "libs/udns/rdtypes/IN",
    "shellcode/standalone/linux",
    "shellcode/standalone/linux/arm",

]

CANVASMESSAGE="""

Thanks for purchasing Immunity CANVAS. The location to download your copy of
CANVAS is at https://www.immunityinc.com/cgi-bin/getcanvas.py.

Username:
Password:

Please note that Apache adds a \n to the end of the file. Some archival
programs may complain about this when unpacking it. However, no corruption has
occurred.

Please let Immunity know if you have any problems or feedback!

Thanks,
Dave Aitel
Immunity, Inc.
"""

#md5 sums a file
def getmd5sum(filename):
    m=md5.new()
    f=open(filename)
    #insert error checking here
    s=f.read()
    f.close()
    m.update(s)
    return m.hexdigest()

#stolen from  http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/82465
#Python license which is now under CANVAS license
def dmkdir(newdir):
    """works the way a good mkdir should :)
        - already exists, silently complete
        - regular file in the way, raise an exception
        - parent directory(ies) does not exist, make them as well
    """
    if os.path.isdir(newdir):
        pass
    elif os.path.isfile(newdir):
        raise OSError("a file with the same name as the desired " \
                      "dir, '%s', already exists." % newdir)
    else:
        head, tail = os.path.split(newdir)
        if head and not os.path.isdir(head):
            dmkdir(head)
        #print "_mkdir %s" % repr(newdir)
        if tail:
            os.mkdir(newdir)
            #print "Making %s"%newdir
            os.system("chmod 777 \"%s\""%newdir)

from libs.filesystem import lsdashr

def copy_base(directory,number, repoadd=False ):
    global exploitslist
    global silicalist
    filelist=[]

    # our libraries
    filelist+=libs

    # HCN Rootkit
    # filelist += ["rootkits/windows/hcn.sys"]

    # supporting files for ms06_024
    filelist+=["Resources/ms06_024/actions.js.wmx"]
    filelist+=["Resources/ms06_024/immunity.wms"]
    filelist+=['Resources/pulsenull32.so']
    filelist+=['Resources/favicon.ico']

    # supporting files for ms09_070
    filelist += ['Resources/mosdef_x86.dll']

    #supporting file for php safemode break
    filelist += ['Resources/usort.php']

    filelist+=["exploitutils.py"]
    #filelist+=["win32syscallserver.py"]
    #documents
    filelist+=["LICENSE.txt"]
    filelist+=["Changelog.txt"]
    #non stegged encoder
    filelist+=["encoder/makeunicode2.py"]
    filelist+=["encoder/chunkedaddencoder.py"]
    filelist+=["encoder/nibble_encoder.py"]
    filelist+=["encoder/alphanumeric.py"]
    #exploits
    filelist+=["iis5htr.py"]

    filelist+=["ThreadRunner2.py"]
    filelist+=["canvasengine.py"]
    filelist+=["engine/config.py"]
    filelist+=["engine/http_mosdef.py"]
    filelist+=["engine/fWrap.py"]
    filelist+=["engine/features.py"]
    filelist+=["canvas.conf"]

    # osdetection files
    filelist+=["osdetection/ftp.py"]
    filelist+=["osdetection/language.py"]
    filelist+=["osdetection/osexception.py"]
    filelist+=["osdetection/smb.py"]
    filelist+=["osdetection/ssh.py"]
    filelist+=["osdetection/http.py"]
    filelist+=["osdetection/local.py"]
    filelist+=["osdetection/rpc.py"]
    filelist+=["osdetection/smtp.py"]
    filelist+=["osdetection/telnet.py"]
    filelist+=["osdetection/mdns.py"]
    filelist+=["osdetection/servicepack.py"]
    filelist+=["osdetection/sql.py"]
    filelist+=["osdetection/dtspcd.py"]
    filelist+=["osdetection/ntp.py"]
    filelist+=["canvastimer.py"]
    filelist+=["versionsinfos.py"]
    filelist+=["timeoutsocket.py"]
    filelist+=["canvasexploit.py"]
    filelist+=["helium/helium.py"]
    filelist+=["helium/other.py"]
    filelist+=["helium/client.py"]
    filelist+=["sunrpc.py"]
    filelist+=["alx_memprofiler.py"]
    #filelist+=["shellcode/heapwin32shellcode.c"]
    #filelist+=["shellcode/heapwin32shellcode.txt"]
    #filelist+=["shellcode/heap2.c","shellcode/heap2.out"]
    #filelist+=["shellcode/win32reverttoself.c"]
    #filelist+=["shellcode/sunstuff.tgz"]
    filelist+=["shellcode/solarisshell.py"]
    #filelist+=["shellcode/win32search.c"]
    filelist+=["shellcode/linuxshell.py"]
    #filelist+=["shellcode/linux_findsock.c"]
    #filelist+=["shellcode/linux_GOsock.c"]
    filelist+=["shellcode/x86asm.py"]
    #filelist+=["shellcode/win32mallocload.c"]
    #filelist+=["shellcode/win32iis.c"]
    #filelist+=["shellcode/recvexec.s"]

    # solaris mosdef
    filelist+=["solarisMosdefShellServer.py"]
    filelist+=["solarisNode.py"]
    filelist+=["shellcode/solarisSPARCshellcodeGenerator.py"]
    filelist+=["shellcode/sparcShellcodeGenerator.py"]
    filelist+=["shellcode/solarisx86shellcodegenerator.py"]
    filelist+=["MOSDEF/sparcparse.py"]
    filelist+=["MOSDEF/cparse2.py"]
    filelist+=["MOSDEF/vartree.py"]
    filelist+=["MOSDEF/sparcscan.py"]
    filelist+=["MOSDEF/sparcassembler.py"]
    filelist+=["MOSDEF/solarisremoteresolver.py"]

    # osx mosdef
    filelist+=["osxMosdefShellServer.py"]
    filelist+=["osxNode.py"]
    filelist+=["shellcode/osxPPCshellcodeGenerator.py"]
    filelist+=["shellcode/ppcShellcodeGenerator.py"]
    filelist+=["MOSDEF/ppcparse.py"]
    filelist+=["MOSDEF/ppcscan.py"]
    filelist+=["MOSDEF/ppcassembler.py"]
    filelist+=["MOSDEF/osxremoteresolver.py"]
    filelist+=["MOSDEF/il2ppc.py"]
    filelist+=["MOSDEF/il2x64.py"]
    filelist+=["MOSDEFShellServer/OSX.py"]

    # intel mosdef
    filelist+=["shellcode/osxX86shellcodegenerator.py"]

    # aix mosdef
    filelist+=["aixNode.py"]
    filelist+=["shellcode/aixShellcodeGenerator.py"]
    filelist+=["MOSDEFShellServer/AIX.py"]

    # pjl mosdef
    filelist+=['MOSDEFShellServer/PJL.py']

    #Solaris x86
    filelist+=["MOSDEFShellServer/Solaris.py"]

    # ARM mosdef (October 2011)_
    filelist += ["MOSDEF/arm9assembler.py"]
    filelist += ["MOSDEF/arm9parse.py"]
    filelist += ["MOSDEF/arm9scan.py"]
    filelist += ["MOSDEF/il2arm9.py"]

    # Cert for SSL MOSDEF
    filelist += ['Resources/mosdefcert.pem']

    #CC for MOSDEF
    filelist+=["MOSDEF/cc.py"]

    filelist+=["dunicode.py"]
    filelist+=["msrpc.py"]
    filelist+=["canvas.bat"]
    filelist+=["securecrt.py"]
    filelist+=["securecrt.py"]
    filelist+=["tcpexploit.py"]
    filelist+=["httpclientside.py"]
    filelist+=["shelllistener.py"]
    filelist+=["sqllistener.py"]
    filelist+=["tns.py"]
    filelist+=["INSTALL.txt"]
    #filelist+=["dcedump.py"]
    filelist+=["samba_client.py"]
    filelist+=["smb.py"]
    filelist+=["nmb.py"]
    filelist+=["ieurlmon.py"]
    #MOSDEF (beta)
    filelist+=["linuxMosdefShellServer.py"]
    filelist+=["MOSDEF/remoteresolver.py"]
    filelist+=["MOSDEF/mosdef.py"]
    filelist+=["MOSDEF/mosdefutils.py"]
    filelist+=["MOSDEF/ast.py"]
    filelist+=["MOSDEF/atandtparse.py"]
    filelist+=["MOSDEF/atandtscan.py"]
    filelist+=["MOSDEF/cpp.py"]
    filelist+=["MOSDEF/cparse.py"]
    filelist+=["MOSDEF/spark.py"]
    filelist+=["MOSDEF/x86opcodes.py"]
    filelist+=["MOSDEF/x86scan.py","MOSDEF/x86parse.py"]
    filelist+=["MOSDEF/makeexe.py"]
    filelist+=["MOSDEF/il2x86.py"]
    filelist+=["MOSDEF/il2x86_decoder.py"]
    filelist+=['MOSDEF/il2x64.py']
    filelist+=["MOSDEF/test.c"]
    filelist+=["MOSDEF/struct_endian.py"]
    filelist+=["MOSDEF/pelib.py"]
    filelist+=["MOSDEF/binfmt/elf.py"]
    filelist+=["MOSDEF/binfmt/elf_const.py"]
    filelist+=["MOSDEF/binfmt/macho.py"]
    filelist+=["MOSDEF/win32remoteresolver.py"]
    filelist+=['MOSDEF/win64remoteresolver.py']
    filelist+=["MOSDEF/win32peresolver.py"]
    filelist+=["MOSDEF/riscassembler.py"]
    filelist+=["MOSDEF/riscparse.py"]
    filelist+=["MOSDEF/riscscan.py"]
    filelist+=["MOSDEF/asmparse.py"]
    filelist+=["MOSDEF/asmscan.py"]
    filelist+=["MOSDEF/il2proc.py"]
    filelist+=["MOSDEF/il2risc.py"]
    filelist+=["MOSDEF/linuxremoteresolver.py"]
    filelist+=["MOSDEF/mosdefctypes.py"]
    filelist+=["MOSDEF/mosdef_errno.py"]
    filelist+=["MOSDEF/lex.py"]
    filelist+=["MOSDEF/lex2.py"]
    filelist+=["MOSDEF/yacc.py"]
    filelist+=["MOSDEF/yacc2.py"]
    filelist+=["MOSDEF/il2sparc.py"]
    filelist+=["MOSDEF/bsdremoteresolver.py"]
    ##New for CParse2 - Rich Jan 2009
    filelist+=["MOSDEF/cparse2.py"]
    filelist+=["MOSDEF/vartree.py"]
    ##Resolver for linux/osx common bits
    filelist+=["MOSDEF/unixremoteresolver.py"]
    ##
    filelist+=["MOSDEF/MOSDEFlibc/MLCutils.py"]
    filelist+=["MOSDEF/MOSDEFlibc/subC.py"]
    filelist+=["MOSDEF/MOSDEFlibc/C_headers.py"]
    filelist+=["MOSDEF/MOSDEFlibc/ANSI.py"]
    filelist+=["MOSDEF/MOSDEFlibc/POSIX.py"]
    filelist+=["MOSDEF/MOSDEFlibc/UNIX.py"]
    filelist+=["MOSDEF/MOSDEFlibc/GNU.py"]
    filelist+=["MOSDEF/MOSDEFlibc/UnixSystemV.py"]
    filelist+=["MOSDEF/MOSDEFlibc/SVR4.py"]
    filelist+=["MOSDEF/MOSDEFlibc/BSD.py"]
    filelist+=["MOSDEF/MOSDEFlibc/OSF1.py"]
    filelist+=["MOSDEF/MOSDEFlibc/Linux.py"]
    filelist+=["MOSDEF/MOSDEFlibc/SunOS.py"]
    filelist+=["MOSDEF/MOSDEFlibc/Solaris.py"]
    filelist+=["MOSDEF/MOSDEFlibc/AIX.py"]
    filelist+=["MOSDEF/MOSDEFlibc/IRIX.py"]
    filelist+=["MOSDEF/MOSDEFlibc/Win32.py"]
    filelist+=['MOSDEF/MOSDEFlibc/Win64.py']
    filelist+=["MOSDEF/MOSDEFlibc/FreeBSD.py"]
    filelist+=["MOSDEF/MOSDEFlibc/NetBSD.py"]
    filelist+=["MOSDEF/MOSDEFlibc/OSX.py"]
    filelist+=["MOSDEF/MOSDEFlibc/Darwin.py"]
    filelist+=["MOSDEF/MOSDEFlibc/Mach.py"]
    filelist+=["MOSDEF/MOSDEFlibc/NextSTEP.py"]
    filelist+=["MOSDEF/MOSDEFlibc/OPENSTEP.py"]
    filelist+=["MOSDEF/MOSDEFlibc/Rhapsody.py"]
    filelist+=["MOSDEF/MOSDEFlibc/asm/Linux/i386.py"]
    filelist+=["MOSDEF/MOSDEFlibc/asm/Linux/arm.py"]
    # For x86_64 Linux MOSDEF
    filelist+=["MOSDEF/MOSDEFlibc/asm/Linux/amd64.py"]
    if PPC:
        filelist+=["MOSDEF/MOSDEFlibc/asm/Linux/ppc.py"]
    filelist+=["MOSDEF/MOSDEFlibc/asm/Solaris/i386.py"]
    filelist+=["MOSDEF/MOSDEFlibc/__init__.py"]
    filelist+=["backdoors/mosdef_callbacks/Makefile"]
    filelist+=["backdoors/mosdef_callbacks/tcpstuff.c"]
    filelist+=["backdoors/mosdef_callbacks/tcpstuff.h"]
    filelist+=["backdoors/mosdef_callbacks/utils.c"]
    filelist+=["backdoors/mosdef_callbacks/utils.h"]
    filelist+=["backdoors/php_callback.php"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_win64.exe"]

    filelist+=["extras/do_all_ips.py"]

    # testvuln1 is for coders testing
    #filelist+=["extras/testvuln1.c"]
    #filelist+=["extras/testvuln1.exe"]
    #filelist+=["extras/testvuln1_linux_i386"]
    #filelist+=["extras/testvuln1_linux_mipsel"]
    #filelist+=["extras/testvuln1_linux_powerpc"] # not yet supported
    #filelist+=["extras/testvuln1_solaris_sparc"]
    #filelist+=["extras/testvuln1_solaris_x86"]
    #filelist+=["extras/testvuln1_fbsd_i386"]
    #filelist+=["extras/testvuln1_macosx_powerpc"] # XXX miss GOOOcode
    #filelist+=["extras/testvuln1_aix_powerpc"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback.c"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback.exe"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_linux_i386"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_universal_linux_i386"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_universal.c"]
#    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_http.exe"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_universal_win32.exe"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_universal_win64.exe"]

    # For SYSRET
    filelist += ['backdoors/mosdef_callbacks/mosdef_callback_fbsd9_i386']

    #filelist+=["extras/mosdef_callback__linux_mipsel"] # XXX miss connectback shellcode
    #filelist+=["extras/mosdef_callback__linux_powerpc"] # not yet supported
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_fbsd_i386"] # -> fbsd -> xbsd -> bsd coz it's the same bin for all xBSD ?
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_fbsd7"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_solaris_sparc"]
    #filelist+=["extras/mosdef_callback__solaris_x86"] # add once xBSD stuff standarized
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_macosx_powerpc"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_macosx_intel"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_solaris_i386"]
    #filelist+=["extras/mosdef_callback__aix_powerpc"] # XXX miss il2ppc fix, do we officially support it?
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_linux_powerpc"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_aix51_powerpc"]
    filelist+=["backdoors/mosdef_callbacks/mosdef_callback_aix52_powerpc"]
    filelist+=["backdoors/mosdefservice.exe"]
    filelist+=["backdoors/win-simple-service-64.exe"]
    filelist+=["backdoors/win-simple-service-32.exe"]
    filelist+=["backdoors/osx-mosdef-upgrade-64"]
    filelist+=["backdoors/osx-mosdef-upgrade-32"]
    filelist+=["backdoors/linux-mosdef-upgrade-64"]
    filelist+=["backdoors/linux-mosdef-upgrade-32"]
    filelist+=["extras/ret_search.py"]
    filelist+=["extras/pop3d.py"]
    #filelist+=["extras/PySystemAPI.c"]
    filelist+=["commandlineInterface.py"]
    filelist+=['cmdline.py']
    filelist+=["shellserver.py"]
    filelist+=["fortunes.txt"]
    filelist+=["ttdb.py"]
    filelist+=["kcms.py"]
    filelist+=["bin2root.sh"]
    filelist+=["sniffer.py"]
    filelist+=["dep_check.py"]

    filelist+=["canvashost.py"]
    filelist+=["servcert.cer"] #used for Insight.py
    filelist+=["hostlistener.py"]
    #Dmitry's stuff - LGPLed according to his e-mail
    #filelist+=["ntlm_procs.py","ntlmutils.py","des_c.py","U32.py","des.py","des_data.py","md4.py"]
    filelist+=["encoder/chunk.py"]
    filelist+=["encoder/chunkize.py"]
    filelist+=["encoder/printable.py"]
    filelist+=["encoder/xorencoder.py"]
    filelist+=["encoder/widechar.py"]
    filelist+=["encoder/babbel.py"]
    filelist+=["exploitmanager.py"]

    filelist+=["gui/canvasguigtk2.py"]
    filelist+=["gui/newgui.py"]
    filelist+=["gui/file_browser.py"]
    filelist+=["gui/ad_browser.py"]
    #add everything in the locale directory except .svn files

    filelist+=["gui/locale/po/CANVAS.pot"]
    filelist+=["gui/locale/HOWTO"]
    filelist+=["gui/locale/Makefile"]


    filelist+=[canvasgui_glade_file]
    filelist+=["gui/gtk_license.py"]
    filelist+=["gui/license_view.glade"]
    filelist+=["gui/progressbar.py"]
    filelist+=["gui/progress.glade"]
    filelist+=["gui/text_with_markup.py"]
    filelist+=["gui/defaultgui.py"]
    filelist+=["gui/gui_queue.py"]
    filelist+=['gui/immterm.py']
    filelist+=["gui/pixmaps/canvas.gif"]
    filelist+=["gui/pixmaps/immunity.ico"]
#    filelist+=["gui/immunity.ico"] #sheesh - putting it here because that's where libglade wants it!
    filelist+=["gui/pixmaps/screen32.ico"]
    filelist+=["gui/pixmaps/canvas_spray.png"]
    filelist+=["gui/pixmaps/canvas_spray_trans.png"]
    filelist+=["gui/pixmaps/spray-canvas-immunity.png"]

    #AD Browser related
    filelist+=["gui/pixmaps/ad_computer.png"]
    filelist+=["gui/pixmaps/group.png"]
    filelist+=["gui/pixmaps/administrator.png"]
    filelist+=["gui/pixmaps/user.png"]
    filelist+=["gui/pixmaps/ad_dc.png"]

    # MOSDEF Graphing
    filelist+=["gui/WorldMap/canvasgraph.py"]
    filelist+=["gui/WorldMap/nasa_map.png"]
    filelist+=["gui/WorldMap/README.TXT"]
    filelist+=["gui/WorldMap/ubuntu.sh"]

    # MeatMarket GUI
    filelist+=["gui/MeatMarket/MeatMarket.py"]

    # Gaphas libs
    filelist += ['gui/gaphas/__init__.py']
    filelist += ['gui/gaphas/aspect.py']
    filelist += ['gui/gaphas/canvas.py']
    filelist += ['gui/gaphas/connector.py']
    filelist += ['gui/gaphas/constraint.py']
    filelist += ['gui/gaphas/decorators.py']
    filelist += ['gui/gaphas/examples.py']
    filelist += ['gui/gaphas/freehand.py']
    filelist += ['gui/gaphas/gaphas_extras.py']
    filelist += ['gui/gaphas/geometry.py']
    filelist += ['gui/gaphas/guide.py']
    filelist += ['gui/gaphas/item.py']
    filelist += ['gui/gaphas/matrix.py']
    filelist += ['gui/gaphas/painter.py']
    filelist += ['gui/gaphas/picklers.py']
    filelist += ['gui/gaphas/quadtree.py']
    filelist += ['gui/gaphas/segment.py']
    filelist += ['gui/gaphas/solver.py']
    filelist += ['gui/gaphas/state.py']
    filelist += ['gui/gaphas/table.py']
    filelist += ['gui/gaphas/tool.py']
    filelist += ['gui/gaphas/tree.py']
    filelist += ['gui/gaphas/util.py']
    filelist += ['gui/gaphas/view.py']
    filelist += ['gui/gaphas/weakset.py']

    # new commandline stuff
    filelist += ['CLI/canvascode.py']
    filelist += ['CLI/cli.py']
    filelist += ['CLI/xmlrpc.py']
    filelist += ['CLI/pyconsole.py']

    filelist+=["localsniffer.py"]
    filelist+=["openssl_client.py"]
    filelist+=["RC4.py"]
    filelist+=["shellcode/shellcodeGenerator.py"]
    filelist+=["shellcode/mosdef_shellcodeGenerator.py"]
    filelist+=["shellcode/x86shellcodegenerator.py"]
    filelist+=["shellcode/linuxX86shellcodegenerator.py"]
    filelist+=["shellcode/win32shellcodegenerator.py"]
    filelist+=["shellcode/win32shell.py"]
    filelist+=["shellcode/win32ipv6.py"]
    filelist+=["shellcode/win32knownshellcodegenerator.py"]
    filelist+=["shellcode/bsdX86shellcodegenerator.py"]
    filelist+=["shellcode/linuxshellcodegenerator.py"]
    # developer friendly payload engine for win32
    filelist+=["shellcode/standalone/windows/basecode.py"]
    filelist+=["shellcode/standalone/windows/payloads.py"]
    filelist+=['shellcode/standalone/windows/basecode64.py']
    filelist+=['shellcode/standalone/windows/payloads64.py']
    filelist+=['shellcode/standalone/windows/secondstages64.py']
    # same for osx
    filelist+=['shellcode/standalone/osx/basecode64.py']
    filelist+=['shellcode/standalone/osx/payloads64.py']
    filelist+=['shellcode/standalone/osx/basecode.py']
    filelist+=['shellcode/standalone/osx/payloads.py']


    filelist+=["daemon2root.sh"]
    filelist+=["win32MosdefShellServer.py"]
    filelist+=["linuxMosdefShellServer.py"]

    # android shellcodes
    filelist+=['shellcode/linux_arm_eabi_android.s']
    filelist+=['shellcode/linux_arm_eabi_android_universal_mosdef.s']

    # android standalone
    filelist+=['shellcode/standalone/linux/__init__.py']
    filelist+=['shellcode/standalone/linux/arm/__init__.py']
    filelist+=['shellcode/standalone/linux/arm/basecode.py']
    filelist+=['shellcode/standalone/linux/arm/payloads.py']


    filelist+=["sounds/sound.py"]
    filelist+=["sounds/sound.cfg"]
    filelist+=["sounds/welcome.ogg"]
    filelist+=["sounds/hgn.ogg"]

    filelist+=["localNode.py"]
    filelist+=["CANVASNode.py"]
    filelist+=["canvaserror.py"]
    filelist+=["ScriptNode.py"]
    filelist+=["phplistener.py"]
    filelist+=["ScriptShellServer.py"]
    filelist+=["hostKnowledge.py"]
    filelist+=["listenerLine.py"]
    filelist+=["win32Node.py"]
    filelist+=['win64Node.py']
    filelist+=["MOSDEFNode.py"]
    filelist+=["unixShellNode.py"]
    filelist+=["linuxNode.py"]
    filelist+=["MOSDEFSock.py"]
    filelist+=["SQLNode.py"]
    filelist+=["SQLShellServer.py"]
    filelist+=["VFSNode.py"]
    filelist+=["SMBNode.py"]
    filelist+=["msrpcexploit.py"]
    filelist+=["smbserver.py"]
    filelist+=["ntstatus.py"]
    #filelist+=["Exploits.xls"]
    filelist+=["upxtestvuln.exe"]
    filelist+=["localPipe.py"]
    filelist+=["bsdNode.py"]
    filelist+=["bsdMosdefShellserver.py"]
    ##Deprecated as of new interface grabbing code
    #filelist+=["GETIFS2.exe"]
    #filelist+=["IPV6IFS.exe"]
    filelist+=["runcanvas.sh"]
    filelist+=["runcanvas.py"]
    filelist+=["vsrun.bat"]
    filelist+=["tcpscan.exe"]
    #filelist+=["canvas_win32api.pyd"]
    #filelist+=["internal/PySystemAPI_macosx_powerpc_python23.so"]
    #filelist+=["internal/PySystemAPI_macosx_powerpc_python24.so"]

    filelist+=["internal/uniqlist.py"]
    filelist+=["internal/colors.py"]
    filelist+=["internal/utils.py"]
    filelist+=["internal/debug.py"]
    filelist+=["internal/logging.py"]
    filelist+=["internal/portability.py"]
    filelist+=["internal/path.py"]
    filelist+=["internal/threadutils.py"]
    filelist+=["internal/PySystemAPI.py"]
    filelist+=["db/oui.py"]
    filelist+=["db/oui-stripped.gz"]
    #filelist+=["db/UserAgent.py"] # removed on 07/27/2006, approved by nico, he will restore it later.
    filelist+=["MOSDEFShellServer/MSSgeneric.py"]
    filelist+=["MOSDEFShellServer/MSSnetwork.py"]
    filelist+=["MOSDEFShellServer/MSSsystem.py"]
    filelist+=["MOSDEFShellServer/Linux.py"]
    filelist+=['MOSDEFShellServer/Win64.py']
    filelist+=["MOSDEFShellServer/BSD.py"]
    filelist+=["MOSDEFShellServer/SMB.py"]
    filelist+=["MOSDEFShellServer/__init__.py"]
    filelist+=["MOSDEFShellServer/MSStemp.py"]
    filelist+=["MOSDEFShellServer/MSSpathops.py"]
    filelist+=["MOSDEFShellServer/MSSfile.py"]
    filelist+=["MOSDEFShellServer/MSSerror.py"]
    filelist+=["MOSDEFShellServer/MSScache.py"]
    filelist+=["greenapple.py"] #for gapple_client
    #filelist+=["osxruncanvas.sh"] # DO NOT INCLUDE
    filelist+=["canvas.css"]
    filelist+=["JavaNode.py"]
    filelist+=["PowerShellNode.py"]

    # Nodes
    filelist+=["Nodes/NodeUtils.py"]
    filelist+=["Nodes/javalistener.py"]
    filelist+=["Nodes/JavaShellServer.py"]
    filelist+=['Nodes/PJLNode.py']
    filelist+=['Nodes/PSShellServer.py']
    filelist+=['Nodes/mosdef_powershell/mosdef_powershell.py']
    filelist+=['Nodes/mosdef_powershell/src/psMosdefTCPCallback.ps1']
    filelist+=['Nodes/powershelllistener.py']

    # backdoors
    filelist+=["backdoors/rootshell.c"]
    filelist+=["backdoors/cback_mmap_rwx.c"]
    filelist+=["backdoors/cback_mmap_universal_rwx.c"]
    #filelist+=["backdoors/cback_mmap_W^X.c"] # MOSDEF not yet ready for W^X
    filelist+=["backdoors/mosdef_escale_666.c"]
    filelist+=["backdoors/javaNode.java"]
    filelist+=["backdoors/java2jsp.py"]
    filelist+=["backdoors/http_commander.py"]
    filelist+=["backdoors/aix_privesc.c"]
    filelist+=["backdoors/aix52_privesc"]

    #rootkits
    filelist+=["rootkits/windows/memdump.sys"]

#    filelist+=["rootkits/windows/mosdef_win2k3sp1.sys"]
#    filelist+=["rootkits/windows/mosdef_win2k.sys"]
#    filelist+=["rootkits/windows/mosdef_winxp.sys"]
    filelist+=["rootkits/linux/immrt"] # script
    # linux binaries
    #filelist+=["rootkits/linux/immrt.ko"] # LKM
    filelist+=["rootkits/linux/backdoor/immrtbkd"] # userland backdoor
    # linux sources - bas
    #filelist+=["rootkits/linux/src/DR.c"]
    #filelist+=["rootkits/linux/src/hooktable.h"]
    #filelist+=["rootkits/linux/src/Makefile"]
    # linux sources - daniel
    filelist+=["rootkits/linux/backdoor/immbkd.c"]
    filelist+=["rootkits/linux/backdoor/Makefile"]
    filelist+=["rootkits/linux/backdoor/md5.c"]
    filelist+=["rootkits/linux/backdoor/md5.h"]
    # linux docs
    filelist+=["rootkits/linux/docs/USAGE"]
    #filelist+=["rootkits/linux/README"]
    filelist+=["rootkits/linux/src/README"]

    # Resources
    filelist += ["Resources/ifids.txt"]
    filelist += ["Resources/router_brute"]
    filelist += ["Resources/wpa-passwd.txt"]
    filelist += ["Resources/vulnassess.txt"]
    filelist += ["Resources/server.cert"]
    filelist += ["Resources/server.pkey"]
    filelist += ["Resources/x11screengrab.sh"]
    filelist += ["Resources/test2.pdf"]
    filelist += ["Resources/javanode.jar"]
    filelist += ["Resources/base.odb"]
    filelist += ["Resources/blank.pdf"]
    filelist += ["Resources/ms07_066.exe"]
    filelist += ["Resources/ms08_025.exe"]
    filelist += ["Resources/ms08_049.exe"]
    filelist += ["Resources/icmp_proxy.exe"]
    filelist += ["Resources/newmodules.txt"]
    filelist += ["Resources/favmodules.txt"]
    filelist += ["Resources/Redemption.dll"]
    filelist += ["Resources/getOutlookAddressBook.vbs"]
    filelist += ["Resources/dns.txt"]
    filelist += ["Resources/dns-short.txt"]
    filelist += ["Resources/nm.py"]
    filelist += ["Resources/CANVAS_AX.cab"]
    filelist += ["Resources/CANVAS_AX.ocx"]
    filelist += ["Resources/immunity_report_banner.jpg"]


    #For binder exploit
    filelist += ["Resources/templates/template_cert.doc"]
    filelist += ["Resources/templates/template_cert.ppt"]
    filelist += ["Resources/templates/template_cert.xls"]

    # For java_deserialize
    filelist += ["Resources/javatest.jar"]
    filelist += ["Resources/javatest_win32.jar"]

    # For urlmangle
    filelist += ["Resources/tld.txt"]

    #Reports
    filelist += ["Resources/header.gif"]
    filelist += ["Resources/immunity.css"]

    if silica_build:
        filelist += ["Resources/silicareport.css"]
        filelist += ["Resources/silicareport.gif"]
        filelist += ["Resources/bg-body.gif"]

    #For VAASeline
    filelist += ["Resources/mosdef_callback.exe"]
    filelist += ["Resources/HTTPMOSDEF2.exe"]
    filelist += ["Resources/cb_mon.vbs"]

    #For CLOUDBURST
    filelist += ["Resources/CLOUDBURST/cloudburst.sys"]
    filelist += ["Resources/CLOUDBURST/cloudburst.exe"]
    filelist += ["Resources/CLOUDBURST/mosdefd3d.exe"]

    #For ms09_022_loaddll
    filelist += ["Resources/printer.dll"]

    # for safari_file_stealing
    filelist += ['Resources/safari_file_stealing/filelist.txt']
    filelist += ['Resources/safari_file_stealing/SafariError.jar']
    filelist += ['Resources/safari_file_stealing/usernames.txt']

    # for acrobat flash
    filelist += ['Resources/acrobat_flash/sploit.swf']
    filelist += ['Resources/acrobat_flash/heapspray.swf']

    # for dot_dot_slash
    filelist += ['Resources/dot_dot_slash/filelist.txt']

    #For WiFi_Key_Dumper
    filelist += ["Resources/wirelesskeyservice.exe"]

    #For js_recon
    filelist += ["Resources/DetectPluginVersion.class"]

    #For sun_java_hsbparser
    filelist += ["Resources/sun_java_hsbparser/HSBSiteError_Windows.jar"]
    filelist += ["Resources/sun_java_hsbparser/HSBSiteError_Linux.jar"]

    #For ms09_061_cas
    filelist += ["Resources/ms09_061_cas/pageerror.xbap"]
    filelist += ["Resources/ms09_061_cas/Application Files/pageerror_1_0_0_19/CombinePoCHelper.dll.deploy"]
    filelist += ["Resources/ms09_061_cas/Application Files/pageerror_1_0_0_19/pageerror.exe.deploy"]
    filelist += ["Resources/ms09_061_cas/Application Files/pageerror_1_0_0_19/pageerror.xbap"]
    filelist += ["Resources/ms09_061_cas/Application Files/pageerror_1_0_0_19/pageerror.exe.manifest"]

    #For ms_ntvdm
    filelist += ["Resources/ms_ntvdm/ms_ntvdm.dll"]
    filelist += ["Resources/ms_ntvdm/ms_ntvdm.exe"]

    #for aurora_flash
    filelist += ["Resources/aurora_flash/sploitbig.swf"]
    filelist += ["Resources/aurora_flash/spray.swf"]

    #for flash_newfunction
    filelist +=["Resources/flash_newfunction/Main.swf"]

    #ms10_032
    filelist += ["Resources/ms10_032.exe"]

    #for brute forcers
    filelist += ["Resources/passwords.txt"]

    #for ie_hcp
    filelist += ["Resources/notuseful.jpg"]

    #for spike proxy ssl
    filelist += ["Resources/cacert.pem"]
    filelist += ["Resources/cakey.pem"]

    #for Screengrab on osx
    filelist += ["Resources/snap.class"]

    #for flash_APSB11_18
    filelist += ["Resources/CVE_2011_2110/APSB11_18.swf"]

    #for pythonUnixShell
    filelist += ["pythonUnixShell.py"]
    filelist += ["pythonUnixShellCrypto.py"]

    #for java_AtomicReferenceArray
    filelist += ["Resources/javaAtomicReferenceArray.jar"]

    #for java_DynamicBinding
    filelist += ['Resources/deployJava.js']
    filelist += ['Resources/applet_jnlp_launch.html']
    filelist += ['Resources/applet_security_bypass.jnlp']

    #3rd Party
    filelist += ["3rdparty/README.txt"]

    #generic exploits
    filelist += ["ExploitTypes/ftpexploit.py"]
    filelist += ["ExploitTypes/__init__.py"]
    filelist += ["ExploitTypes/CommandLineExecuter.py"]
    filelist += ["ExploitTypes/blindStack.py"]
    filelist += ["ExploitTypes/phpexploit.py"]
    filelist += ["ExploitTypes/php_multi.py"]
    filelist += ["ExploitTypes/BruteForcer.py"]
    filelist += ["ExploitTypes/php_serialize.py"]
    filelist += ["ExploitTypes/php_break_safemode.py"]
    filelist += ["ExploitTypes/localexploit.py"]
    filelist += ["ExploitTypes/linuxLocalExploit.py"]
    filelist += ["ExploitTypes/osxLocalExploit.py"]
    filelist += ["ExploitTypes/windowsLocalExploit.py"]
    filelist += ["ExploitTypes/localcommand.py"]
    filelist += ["ExploitTypes/utility.py"]

    # AIX stuff
    filelist += ["libs/aixroot/mosdef_reexec_52.a"]
    filelist += ["libs/aixroot/mosdef_reexec_shared.c"]

    #Everything in libs is included by default - so not sure why these
    #are here.
    # Solaris stuff
    filelist += ['libs/solroot/mosdef_reexec_sol10_intel.so']
    filelist += ['libs/solroot/mosdef_reexec_shared.c']

    # pygeoip stuff
    filelist += ['libs/pygeoip/const.py']
    filelist += ['libs/pygeoip/util.py']

    #testomatic

    # filelist += ['testomatic/fulltest.py']
    # filelist += ['testomatic/targets.py']
    # filelist += ['testomatic/testomaticnode.py']
    # filelist += ['testomatic/testomaticnode.py']
    # filelist += ['testomatic/testomatic.py']
    # filelist += ['testomatic/testomaticOutput.py']
    # filelist += ['testomatic/testomaticnode.py']
    # filelist += ['testomatic/js/MochiKit.js']
    # filelist += ['testomatic/tmpl/testomatic.html']
    # filelist += ['testomatic/vix.py']
    # filelist += ['testomatic/testvix.py']


    #PyELF (October 2011)
    filelist += ['libs/PyELF/AsmLoader.py']
    filelist += ['libs/PyELF/BINFMT']
    filelist += ['libs/PyELF/ElfLoader.py']
    filelist += ['libs/PyELF/Elf.py']
    filelist += ['libs/PyELF/loader32.S']
    filelist += ['libs/PyELF/loader64.S']
    filelist += ['libs/PyELF/MmanHeader.py']
    filelist += ['libs/PyELF/README']
    filelist += ['libs/PyELF/Syscall.py']
    filelist += ['libs/PyELF/t32']
    filelist += ['libs/PyELF/t64']
    filelist += ['libs/PyELF/t.c']
    filelist += ['libs/PyELF/__init__.py']

    #YAML (July 2012)
    filelist += ['libs/yaml/composer.py']
    filelist += ['libs/yaml/constructor.py']
    filelist += ['libs/yaml/cyaml.py']
    filelist += ['libs/yaml/dumper.py']
    filelist += ['libs/yaml/emitter.py']
    filelist += ['libs/yaml/error.py']
    filelist += ['libs/yaml/events.py']
    filelist += ['libs/yaml/__init__.py']
    filelist += ['libs/yaml/loader.py']
    filelist += ['libs/yaml/nodes.py']
    filelist += ['libs/yaml/parser.py']
    filelist += ['libs/yaml/reader.py']
    filelist += ['libs/yaml/representer.py']
    filelist += ['libs/yaml/resolver.py']
    filelist += ['libs/yaml/scanner.py']
    filelist += ['libs/yaml/serializer.py']
    filelist += ['libs/yaml/tokens.py']

    #ua_parser (July 2012)
    filelist += ['libs/ua_parser/__init__.py']
    filelist += ['libs/ua_parser/user_agent_parser.py']
    filelist += ['libs/ua_parser/LICENSE']
    filelist += ['libs/ua_parser/data/regexes.yaml']

    #New reporting (July 2012)
    filelist += ['Documentation/ReportsAPI/_sources/collector.txt']
    filelist += ['Documentation/ReportsAPI/_sources/document.txt']
    filelist += ['Documentation/ReportsAPI/_sources/index.txt']
    filelist += ['Documentation/ReportsAPI/_sources/reference.txt']
    filelist += ['Documentation/ReportsAPI/_sources/reporter.txt']
    filelist += ['Documentation/ReportsAPI/_sources/tutorial.txt']
    filelist += ['Documentation/ReportsAPI/_sources/utils.txt']

    filelist += ['Documentation/ReportsAPI/_static/ajax-loader.gif']
    filelist += ['Documentation/ReportsAPI/_static/basic.css']
    filelist += ['Documentation/ReportsAPI/_static/comment-bright.png']
    filelist += ['Documentation/ReportsAPI/_static/comment-close.png']
    filelist += ['Documentation/ReportsAPI/_static/comment.png']
    filelist += ['Documentation/ReportsAPI/_static/default.css']
    filelist += ['Documentation/ReportsAPI/_static/doctools.js']
    filelist += ['Documentation/ReportsAPI/_static/down.png']
    filelist += ['Documentation/ReportsAPI/_static/down-pressed.png']
    filelist += ['Documentation/ReportsAPI/_static/file.png']
    filelist += ['Documentation/ReportsAPI/_static/jquery.js']
    filelist += ['Documentation/ReportsAPI/_static/minus.png']
    filelist += ['Documentation/ReportsAPI/_static/plus.png']
    filelist += ['Documentation/ReportsAPI/_static/pygments.css']
    filelist += ['Documentation/ReportsAPI/_static/searchtools.js']
    filelist += ['Documentation/ReportsAPI/_static/sidebar.js']
    filelist += ['Documentation/ReportsAPI/_static/underscore.js']
    filelist += ['Documentation/ReportsAPI/_static/up.png']
    filelist += ['Documentation/ReportsAPI/_static/up-pressed.png']
    filelist += ['Documentation/ReportsAPI/_static/websupport.js']

    filelist += ['Documentation/ReportsAPI/.buildinfo']
    filelist += ['Documentation/ReportsAPI/collector.html']
    filelist += ['Documentation/ReportsAPI/document.html']
    filelist += ['Documentation/ReportsAPI/genindex.html']
    filelist += ['Documentation/ReportsAPI/index.html']
    filelist += ['Documentation/ReportsAPI/objects.inv']
    filelist += ['Documentation/ReportsAPI/py-modindex.html']
    filelist += ['Documentation/ReportsAPI/reference.html']
    filelist += ['Documentation/ReportsAPI/reporter.html']
    filelist += ['Documentation/ReportsAPI/search.html']
    filelist += ['Documentation/ReportsAPI/searchindex.js']
    filelist += ['Documentation/ReportsAPI/tutorial.html']
    filelist += ['Documentation/ReportsAPI/utils.html']

    filelist += ['Resources/report_template.odt']

    filelist += ['libs/reports/__init__.py']
    filelist += ['libs/reports/canvas_report.py']
    filelist += ['libs/reports/collector.py']
    filelist += ['libs/reports/document.py']
    filelist += ['libs/reports/generate.py']
    filelist += ['libs/reports/reporter.py']
    filelist += ['libs/reports/utils.py']

    filelist += ['libs/py3o/__init__.py']
    filelist += ['libs/py3o/template/__init__.py']
    filelist += ['libs/py3o/template/main.py']
    filelist += ['libs/pyjon/__init__.py']
    filelist += ['libs/pyjon/utils/__init__.py']
    filelist += ['libs/pyjon/utils/base_converter.py']
    filelist += ['libs/pyjon/utils/main.py']
    filelist += ['libs/pyjon/utils/test/test_base_converter.py']
    filelist += ['libs/pyjon/utils/test/test_substitute.py']
    filelist += ['libs/pyjon/utils/test/test_utilities.py']

    filelist += ['libs/odf/APACHE-LICENSE-2.0.txt']
    filelist += ['libs/odf/README']
    filelist += ['libs/odf/__init__.py']
    filelist += ['libs/odf/anim.py']
    filelist += ['libs/odf/attrconverters.py']
    filelist += ['libs/odf/chart.py']
    filelist += ['libs/odf/config.py']
    filelist += ['libs/odf/dc.py']
    filelist += ['libs/odf/dr3d.py']
    filelist += ['libs/odf/draw.py']
    filelist += ['libs/odf/easyliststyle.py']
    filelist += ['libs/odf/element.py']
    filelist += ['libs/odf/elementtypes.py']
    filelist += ['libs/odf/form.py']
    filelist += ['libs/odf/grammar.py']
    filelist += ['libs/odf/load.py']
    filelist += ['libs/odf/manifest.py']
    filelist += ['libs/odf/math.py']
    filelist += ['libs/odf/meta.py']
    filelist += ['libs/odf/namespaces.py']
    filelist += ['libs/odf/number.py']
    filelist += ['libs/odf/odf2moinmoin.py']
    filelist += ['libs/odf/odf2xhtml.py']
    filelist += ['libs/odf/odfmanifest.py']
    filelist += ['libs/odf/office.py']
    filelist += ['libs/odf/opendocument.py']
    filelist += ['libs/odf/presentation.py']
    filelist += ['libs/odf/script.py']
    filelist += ['libs/odf/style.py']
    filelist += ['libs/odf/svg.py']
    filelist += ['libs/odf/table.py']
    filelist += ['libs/odf/teletype.py']
    filelist += ['libs/odf/text.py']
    filelist += ['libs/odf/thumbnail.py']
    filelist += ['libs/odf/userfield.py']
    filelist += ['libs/odf/xforms.py']


    filelist += ['libs/genshi/__init__.py']
    filelist += ['libs/genshi/_speedups.c']
    filelist += ['libs/genshi/builder.py']
    filelist += ['libs/genshi/core.py']
    filelist += ['libs/genshi/filters/__init__.py']
    filelist += ['libs/genshi/filters/html.py']
    filelist += ['libs/genshi/filters/i18n.py']
    filelist += ['libs/genshi/filters/tests/__init__.py']
    filelist += ['libs/genshi/filters/tests/html.py']
    filelist += ['libs/genshi/filters/tests/i18n.py']
    filelist += ['libs/genshi/filters/tests/transform.py']
    filelist += ['libs/genshi/filters/transform.py']
    filelist += ['libs/genshi/input.py']
    filelist += ['libs/genshi/output.py']
    filelist += ['libs/genshi/path.py']
    filelist += ['libs/genshi/template/__init__.py']
    filelist += ['libs/genshi/template/_ast24.py']
    filelist += ['libs/genshi/template/ast24.py']
    filelist += ['libs/genshi/template/astutil.py']
    filelist += ['libs/genshi/template/base.py']
    filelist += ['libs/genshi/template/directives.py']
    filelist += ['libs/genshi/template/eval.py']
    filelist += ['libs/genshi/template/interpolation.py']
    filelist += ['libs/genshi/template/loader.py']
    filelist += ['libs/genshi/template/markup.py']
    filelist += ['libs/genshi/template/plugin.py']
    filelist += ['libs/genshi/template/text.py']
    filelist += ['libs/genshi/template/tests/__init__.py']
    filelist += ['libs/genshi/template/tests/base.py']
    filelist += ['libs/genshi/template/tests/directives.py']
    filelist += ['libs/genshi/template/tests/eval.py']
    filelist += ['libs/genshi/template/tests/interpolation.py']
    filelist += ['libs/genshi/template/tests/loader.py']
    filelist += ['libs/genshi/template/tests/markup.py']
    filelist += ['libs/genshi/template/tests/plugin.py']
    filelist += ['libs/genshi/template/tests/text.py']
    filelist += ['libs/genshi/template/tests/templates/__init__.py']
    filelist += ['libs/genshi/template/tests/templates/functions.html']
    filelist += ['libs/genshi/template/tests/templates/functions.txt']
    filelist += ['libs/genshi/template/tests/templates/new_syntax.txt']
    filelist += ['libs/genshi/template/tests/templates/test.html']
    filelist += ['libs/genshi/template/tests/templates/test.txt']
    filelist += ['libs/genshi/template/tests/templates/test_no_doctype.html']
    filelist += ['libs/genshi/util.py']
    filelist += ['libs/genshi/tests/__init__.py']
    filelist += ['libs/genshi/tests/builder.py']
    filelist += ['libs/genshi/tests/core.py']
    filelist += ['libs/genshi/tests/input.py']
    filelist += ['libs/genshi/tests/output.py']
    filelist += ['libs/genshi/tests/path.py']
    filelist += ['libs/genshi/tests/util.py']

    # for f in os.listdir("testomatic/img"):
    #     if f==".svn":
    #         continue
    #     filelist += ["testomatic/img/"+f]

    # for f in os.listdir("testomatic/large_icons"):
    #     if f==".svn":
    #         continue
    #     filelist += ["testomatic/large_icons/"+f]

    #MAY 2010
    #java_deserialize2
    filelist += ["Resources/javatest2.jar"]
    #Java Method Chain
    filelist += ["Resources/javatest4.jar"]
    #ie_peers_flash
    filelist += ["Resources/ie_peers_flash/sploitbig.swf"]

    #java_rhino
    filelist += ['Resources/JavaRhino.jar']

    # java_forName_getField
    filelist += ['Resources/CVE-2012-4681.jar']

    # December 2012, 6.84
    filelist += ['Resources/CVE-2012-5076.jar']
    filelist += ['Resources/CVE-2012-5088.jar']

    fuzzbase=["__init__.py","dcefuzz.py","spike.py","dcefuzz_msdns.py"]
    for f in fuzzbase:
        filelist += ["fuzzers/"+f]
    spkscripts= ["imap1","tftpd2","tftpd5","base64","imap_ntlm","tftpd3"]
    spkscripts+=["tftpd6","tftpd1","tftpd4"]
    #then we add the spike scripts
    for f in spkscripts:
        filelist += ["fuzzers/SPIKESCRIPTS/"+f+".spk"]



    # add dirs who get an __init__.py here
    for d in directory_with_init_list:
        if not silica_build:
            print "Adding __init__ to %s"%d
        filelist += ["%s/__init__.py" % d]


    #do directories correctly
    filelist2=[]
    for f in filelist:
        if f.count("/"):
            files=f.split("/")
            f=os.path.join(*files)
        filelist2.append(f)

    filelist=filelist2

    basedir="libs"
    files,dirs=lsdashr(basedir,["CVS",".svn"])

    if not silica_build:
        print "Files=%s Dirs=%s"%(files,dirs)

    #libdir=directory+"/libs/"
    #dmkdir(libdir)
    for dir in dirs:
        dirtomake=os.path.join(directory,dir)
        #print "Making Dir: %s"%dirtomake
        dmkdir(dirtomake)
    for file in files:
        if file.count("dialog.glade2")\
            or file.lower()[-3:]==".py"\
            or file.lower().count("license")\
            or file.lower()[-5:]==".html"\
            or file.lower()[-4:]==".xml":
            filelist+=[file]

    ###################################################
    #VISUALSPIKE Directory
    #our plan: copy whole thing except .pyc and .bak, generate_vs.py
    basedir="VisualSpike"
    files,dirs=lsdashr(basedir,["CVS",".svn"],[".pyc",".bak","generate_vs.py"])
    #print "Files=%s Dirs=%s"%(files,dirs)
    for dir in dirs:
        dirtomake=os.path.join(directory,dir)
        #print "Making Dir: %s"%dirtomake
        dmkdir(dirtomake)
    filelist+=files

    ###################################################

    #LOCALE directory (translations)
    basedir="gui/locale"
    files,dirs=lsdashr(basedir,["CVS",".svn"])
    #print "Files=%s Dirs=%s"%(files,dirs)

    #libdir=directory+"/libs/"
    #dmkdir(libdir)
    for dir in dirs:
        dirtomake=os.path.join(directory,dir)
        #print "Making Dir: %s"%dirtomake
        dmkdir(dirtomake)
    for file in files:
        #get all the files in this directory
        filelist+=[file]

    #print "Filelist=%s"%filelist
    #sys.exit(1)


    if silica_build:
        silicadeps = []
        blacklist_prefix = ["fuzzers", "testomatic", "rootkits", "WorldMap", "gaphas", "VAASeline","canvasguigtk2.py","pixmaps","WorldMap",'canvasgui2_default.glade', 'runcanvas', 'canvas.bat', 'helium', 'VisualSpike']
        exploitslist = silicalist
        newfilelist = []

        for x in range(len(filelist)):
            fd = filelist[x]
            tpass = True
            for blacklist in blacklist_prefix:
                if blacklist in fd:
                    tpass = False
                    break
            if tpass:
                newfilelist.append(filelist[x])

        newfilelist += silicadeps
        filelist = newfilelist


    for srcfile in filelist:
        #print "Copying: %s"%srcfile
        filename = os.path.join(directory,srcfile)
        shutil.copy(srcfile, filename)
        if repoadd:
            os.system("svn add \"%s\""%srcfile)

    #shellcodelist=["CONTENTS.txt","davehash.c","davehash.exe"]
    shellcodelist=[]
    for srcfile in shellcodelist:
        srcpath = os.path.join("shellcode",srcfile)
        shutil.copy(srcpath,os.path.join(directory,srcpath ))
        if repoadd:
            os.system("svn add \"%s\""%srcpath)

    if not silica_build:
        dirs+=["TEMPLATES"]
        morefiles,template_dirs=lsdashr("TEMPLATES",["CVS"])
        dirs+=template_dirs
        files+=morefiles
        files+=["TEMPLATES/dialog.glade2"]
        #tag the end of canvasguigtk2.py
        directory2=os.path.join(directory,"gui")
        fname=os.path.join(directory2,"canvasguigtk2.py")
        fd=open(fname,"rb")
        data=fd.read()
        fd.close()
        os.unlink(fname)
        fd=open(fname,"wb+")
        if number in dateDict:
            date=dateDict[number]
        else:
            date="Unknown"

        email="Unknown"
        if number in emailDict:
            email=emailDict[number]

        data=data.replace("EXPIREDATE",date)
        data=data.replace("CONTACTEMAIL",email)
        data+=" "*number
        fd.write(data)
        fd.close()
        os.chmod(fname,0755)
        documentationlist = ["canvas5.0api.txt", "canvas5.0user.txt", "Spike-SSL-MITM.txt", "ARM_notes.txt", "Strategic.txt"]
        # documentationlist += ["Debian_install.txt", "commandline_usage.txt", "shellcode.txt", "CANVAS_Basics.pdf", "CANVAS_ExploitPacks.txt","hcn_for_canvas_brochure.pdf", "Linux_Install.pdf", "Windows_Install.pdf", "OSX_Install.pdf"]
        documentationlist += ["Debian_install.txt", "commandline_usage.txt", "shellcode.txt", "CANVAS_Basics.pdf", "CANVAS_ExploitPacks.txt", "Linux_Install.pdf", "Windows_Install.pdf", "OSX_Install.pdf"]
        documentationlist+=["CANVAS_Clientd.odt"]

        for srcfile in documentationlist:
            srcpath=os.path.join("Documentation",srcfile)
            shutil.copy(srcpath,os.path.join(directory,srcpath) )
            if repoadd:
                os.system("svn add \"%s\""%srcpath)


        ##Include a directory with all our releasenotes in
        releasenotes = os.listdir(os.path.join("Documentation","ReleaseNotes"))
        for note in releasenotes:
            if note[-4:] == ".txt":
                srcpath=os.path.join("Documentation","ReleaseNotes",note)
                shutil.copy(srcpath,os.path.join(directory,srcpath) )
                if repoadd:
                    os.system("svn add \"%s\""%srcpath)

        ##Include a directory with all our Tutorials in
        tutorials = os.listdir(os.path.join("Documentation","Tutorials"))
        for note in tutorials:
            if note[-4:] == ".pdf":
                srcpath = os.path.join("Documentation","Tutorials",note)
                shutil.copy(srcpath,os.path.join(directory,srcpath) )
                if repoadd:
                    os.system("svn add \"%s\""%srcpath)

        ##Linux installer
        #shutil.copy(os.path.join("installCANVAS","installCANVAS.sh"),os.path.join(directory,"installCANVAS","installCANVAS.sh") )
        #if repoadd:
            #os.system("svn add \"%s\""%os.path.join("installCANVAS","installCANVAS.sh"))

    for filename in exploitslist:
        exploitpath=os.path.join("exploits",filename)
        dest=os.path.join(directory,exploitpath)
        dmkdir(dest)
        if repoadd:
            os.system("svn add \"%s/.\""%exploitpath)
        #print "DEST=%s"%dest
        try:
            srcpath=os.path.join(modulesdir,filename,"dialog.glade2")
            shutil.copy(srcpath,dest)
            if repoadd:
                os.system("svn add \"%s\""%srcpath)
        # some exploits don't have a dialog
        except:
            print "Note exploit: ", filename, "doesn't have a dialog file"
            pass
        exploitfilepath=os.path.join("exploits", filename, os.path.basename(filename) + ".py")
        shutil.copy(exploitfilepath,dest)
        if repoadd:
            os.system("svn add \"%s\""%exploitfilepath)

        #ok, now try to read that exploit's MANIFEST and copy the files in the MANIFEST over.
        manifestname = os.path.join(exploitpath, "MANIFEST.txt")
        if not silica_build:
            print "Manifest Name: %s"%manifestname
        fd = None
        if os.path.exists(manifestname):
            #also need to copy the manifest over!
            shutil.copy(manifestname, dest)
            try:
                fd = open(manifestname, "r")
            except IOError:
                #no manifest
                fd = None

        if fd:
            print "Doing manifest file: %s"%manifestname
            #Generally you want to use find exploits/NAME/ | grep -v ".pyc" | grep -v ".svn" and
            #then do some very slight pruning to generate your MANIFEST.txt
            for line in fd.readlines():
                #some small parsing here to allow "comments"
                if len(line)==0:
                    continue
                if line[0] == "#":
                    continue
                line=line.strip() #get rid of \r/\n
                filepath = os.path.join(exploitpath, line)

                #add this to the repository if that's what we're looking to do here.
                if repoadd:
                    os.system("svn add \"%s/.\""%filepath)

                #first, make sure the directory exists
                destpath = os.path.join(directory, "exploits", filename, line)
                print "Manifest file dest path: %s"%destpath
                dmkdir(os.path.dirname(destpath)) #make sure directory exists (also accounts for parents! :>)

                #now we have to copy the file over
                if not os.path.isdir(filepath):
                    #copy the file over
                    shutil.copy(filepath,destpath)
                else:
                    #just make the directory
                    dmkdir(destpath)



    ##Has to be done here as until now the /exploits/ms09_051 doesnt exist
    if not silica_build:
        shutil.copy(os.path.join("exploits","clientside/windows/ms09_051","MS09051.wma"),
                    os.path.join(directory,"exploits","clientside/windows/ms09_051","MS09051.wma"))

    return


def create_encoder(number):
    """
    Creates a addencoder.pyo in our directory
    """
    oldfile="encoder/addencoder.py"
    newfile="addencoder.py"
    tagline="random.seed(10)"
    newline="random.seed(%d) "%number

    inf=open(oldfile,"rb").read()
    out=inf.replace(tagline,newline)
    open(newfile,"wb").write(out)

    return newfile



def create_mssql(number):
    oldfile="mssql_hello_template.py"
    newfile="mssql_hello.py"
    tagline="evalnum=10"
    newline="evalnum=%d"%number

    inf=open(oldfile,"rb").read()
    out=inf.replace(tagline,newline)
    open(newfile,"wb").write(out)
    os.system("python -OO -c \"import mssql_hello\"")
    return newfile+"o"

def usage():
    print "Usage: %s -n number [-t tmpdir] [-P platform] [-C (include Control/Strategic)] [-S (SILICA build)] [-X (include stuff for exec package)] [-R (to add to svn repository)]" % sys.argv[0]
    print "       default tmpdir is %s" % tmpdir
    sys.exit()


if __name__ == '__main__':
    import getopt

    try:
        (opts, args) = getopt.getopt(sys.argv[1:],"pn:aTVt:P:CSWUXR")
    except getopt.GetoptError:
        usage()

    specificnumber  = 0
    testing         = 0
    all             = 0
    paid            = 0
    vulnshare       = 0
    silica_build    = False

    # April/2014: Strategic is built-in to all releases now
    strategic_build = True

    PACKAGE         = False
    repoadd         = False

    for o, a in opts:
        if o == "-n":
            specificnumber = int(a)
        elif o == "-a":
            all=1
        elif o == "-p":
            paid=1
        elif o == "-T":
            testing=1
        elif o == "-V":
            vulnshare=1
        elif o == "-t":
            tmpdir = a
        elif o == "-P":
            canvas_platform = a
        elif o == "-R":
            repoadd = True
        elif o == "-S":
            print "SILICA build"
            silica_build     = True
        elif o == "-X":
            print "executable package build"
            PACKAGE = True

    if not all and not paid and not vulnshare:
        #if specificnumber==0:
        #    usage()

        #if not customersDict.has_key(specificnumber):
        #    print "No customer for that key: %d"%specificnumber
        #    usage()
        numberlist=[specificnumber]

    else:
        numberlist=customersDict.keys()


    import time
    today="%4.4d%2.2d%2.2d"%time.localtime()[:3]
    print "Today is %s"%today
    if socket.gethostname()!="fist":
        os.system("rm -rf %s/CANVAS_*"%tmpdir)
    created=0
    for number in numberlist:
        print "Handling number %s"%number

        date=dateDict.get(number,today)
        print "Testing date: %d:%s"%(number,date)
        if specificnumber==0 and date<today:
            continue
        created+=1
        if testing:
            print "Would create CANVAS for %d"%number
            print "Total Created: %d"%created
            continue

        if silica_build:
            directory=os.path.join(tmpdir,"CANVAS_S")
        else:
            directory=os.path.join(tmpdir,"CANVAS_"+customersDict[number])

        os.system("rm -rf %s"%directory)

        print "Creating "+directory
        dmkdir(directory)
        #add other directories here
        other_directories  = directory_with_init_list[:]
        other_directories += ["exploits", "helium", "extras", "backdoors", "backdoors/mosdef_callbacks","rootkits", "rootkits/windows","rootkits/linux","rootkits/linux/backdoor", "rootkits/linux/docs", "rootkits/linux/src", "Resources", "Resources/CLOUDBURST","Resources/ms06_024","Resources/templates","gui/pixmaps", "gui/locale", "gui/locale/po", "Nodes/mosdef_powershell/src"]
        other_directories += ["Resources/ie_peers_flash"]
        other_directories += ["Saved_Hosts"]
        other_directories += ["Reports", "ExploitTypes", "3rdparty"]
        other_directories += ['Resources/safari_file_stealing']
        other_directories += ['Resources/dot_dot_slash']
        other_directories += ['Resources/acrobat_flash']
        other_directories += ['Resources/sun_java_hsbparser']
        other_directories += ['Resources/CVE_2011_2110']
        other_directories += ['Resources/aurora_flash']
        other_directories += ['Resources/flash_newfunction']
        other_directories += ['Resources/ms09_061_cas']
        other_directories += ['Resources/ms09_061_cas/Application Files']
        other_directories += ['Resources/ms09_061_cas/Application Files/pageerror_1_0_0_19']
        other_directories += ['Resources/ms_ntvdm']

        #other_directories += ['testomatic', 'testomatic/img', 'testomatic/reports', 'testomatic/js', 'testomatic/large_icons','testomatic/node', 'testomatic/tmpl']

        other_directories += ['Documentation/ReportsAPI']
        other_directories += ['Documentation/ReportsAPI/_sources']
        other_directories += ['Documentation/ReportsAPI/_static']

        if PACKAGE:
            #other_directories += ['ReleaseBuilder']
            shutil.copytree('ReleaseBuilder', os.path.join(directory,"ReleaseBuilder"))

        if strategic_build:
            shutil.copytree('control', os.path.join(directory, 'control'), ignore=shutil.ignore_patterns('*.pyc', 'docs', 'log', 'sessions'))

        if not silica_build:
            other_directories += ["fuzzers", "fuzzers/SPIKESCRIPTS", "Documentation", "Documentation/ReleaseNotes", "Documentation/Tutorials"]#"installCANVAS"]

        for adir in other_directories:
            # print "Adding directory: %s" % (os.path.join(directory, adir))
            dmkdir(os.path.join(directory, adir))
            if repoadd:
                os.system("svn add \"%s\"/."%adir)

        newencoder=create_encoder(number)

        print "Copying Base Files"
        copy_base(directory,number, repoadd=repoadd)

        shutil.copy(newencoder,os.path.join(directory,"encoder",newencoder))

        if not silica_build:
            from VisualSploit.generate_vs import copy_base as vs_copy_base
            os.chdir("VisualSploit")
            vs_copy_base(os.path.join(directory,'VisualSploit'), number)
            os.chdir("..")

        ########### White Phosphorus integration
        wp_dest = os.path.join(directory, "3rdparty", "White_Phosphorus")

        ## Take out the 0days
        wp_0day_list = [
                        "wp_hanspark_pdfsnap2",
                        "wp_slavaproxy_socks4",
                        "wp_stdu_viewer",
                        "wp_stdu_explorer",
                        "wp_bladeapimonitor_unsanitizedscript",
                        "wp_sorax_reader",
                        "wp_swftools_pdf2swf",
                        "wp_clubdjpro_prodj",
                        "wp_net2ftp_rfi"
                        ]

        print "Copying: White_Phosphorus into %s" % wp_dest
        shutil.copytree('3rdparty/White_Phosphorus', wp_dest, ignore=shutil.ignore_patterns('*.pyc', *wp_0day_list))

        print "CANVAS Customer number %d %s"%(number,getmd5sum(newencoder))
        print "Unlinking"
        os.unlink(newencoder)
        print "Tarring up into a nice package in %s"%tmpdir
        if os.name=="nt":
            tmpdir=os.path.join("C:",tmpdir)
            tmpdir=tmpdir.replace("\\","/")


        if silica_build:
            command="cd %s; tar czf CANVAS_S.tar.gz CANVAS_S/"%tmpdir
        else:
            command="cd %s; tar czf CANVAS_%s.tar.gz CANVAS_%s/"%(tmpdir,customersDict[number], customersDict[number])
        if os.name=="nt":
            command="c:\\cygwin\\bin\\bash -c \"%s\""%command
        print "Running %s"%command
        os.system(command)
        print "Check in directory: %s"%directory

    #don't need this anymore since we only distro CANVAS_DEMO to canvas.immunityinc.com
    #if 1 and socket.gethostname()!="fist":
    #    os.system("cd %s; tar cvf C.tar CANVAS*.tar.gz"%tmpdir)

    print "Done!"


