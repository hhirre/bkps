#
# ioctlizer
# Copyright (C) 2007 Justin Seitz <jms@bughunter.ca>
#
# $Id$
#
# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program; if not, write to the Free
# Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#

'''
@author:       Justin Seitz
@license:      GNU General Public License 2.0 or later
@contact:      jms@bughunter.ca
'''


import utils
import sys
import cPickle

from pydbg import *
from pydbg.defines import *



class ioctlizer:

    def __init__(self,output_file,pid=None,exec_path=None,mode=None):
        
        
        self.dbg                 = pydbg()
        self.output_file         = output_file # The pickled list of captured IOCTLs
        self.file_names          = {}          # The dictionary of symlinked filenames we retrieved
        self.trapped_ioctls      = {}          # The actual IOCTL request dictionary
        self.decoded_requests    = []          # The final list that we ship off.
        self.read_write_enabled  = False       # If you want to trap the noisy read/writes feel free, but it slows things down
        
        # Get debug privileges
        self.dbg.get_debug_privileges()
        
        
        if mode == "attach":
            
            self.dbg.attach(pid)
            self.pid        = pid
            self.set_kernel32_hooks()
            
        elif mode == "open":
            
            self.dbg.set_callback(LOAD_DLL_DEBUG_EVENT, self.dll_load_handler)
            self.dbg.load(exec_path)
            self.pid = self.dbg.pid
        
        # Fire up the user-mode process
        self.dbg.run()
        
    
    def set_kernel32_hooks(self):
        '''
        This function simply creates hooks on the relvant system calls
        that we need to hook in order to build valid test cases.
        '''
        
        # Resolve the function addresses for hooking
        create_file = self.dbg.func_resolve("kernel32","CreateFileW")
        dev_ioctl   = self.dbg.func_resolve("kernel32","DeviceIoControl")
        close_handle= self.dbg.func_resolve("kernel32","CloseHandle")
        
        # Install the hooks
        self.hooks = utils.hook_container()
        self.hooks.add(self.dbg,create_file,7,None,self.create_file_exit)
        self.hooks.add(self.dbg,close_handle,1,self.close_handle_entry,None)
        self.hooks.add(self.dbg,dev_ioctl,8,None,self.dev_ioctl_exit)
        
        # Check to see if we want to trap the noisy 
        # read/write calls as well.
        if self.read_write_enabled == True:
            write_file  = self.dbg.func_resolve("kernel32","WriteFile")
            read_file   = self.dbg.func_resolve("kernel32","ReadFile")
            
            self.hooks.add(self.dbg,read_file,5,None,self.read_file_exit)
            self.hooks.add(self.dbg,write_file,5,None,self.write_file_exit)
            
    def dll_load_handler (self,dbg):
        """
        In the case of spawning the process ourselves,
        we have to make sure that kernel32.dll is loaded
        before we begin setting hooks.
        """
        last_dll = dbg.get_system_dll(-1)
        
        if last_dll.name.lower() == "kernel32.dll":
            
            self.set_kernel32_hooks()
            
        return DBG_CONTINUE
    
    
    def read_file_exit(self,dbg,args,ret):
        """
        This traps calls to kernel32.ReadFile, and is only enabled
        if the self.read_write_enabled = True
        """
        
        h_file            = args[0]
        out_buffer_ptr    = args[1]
        read_num_bytes    = args[2]
        num_bytes_ret     = args[3]
        
        try:
            filename    = self.file_names[h_file]
        except:
            filename    = "UNRESOLVED"
        
        # If we actually get some bytes returned by the call
        # then we want to trap them and add it to the global
        # list of decoded requests
        if num_bytes_ret > 0:
            
            out_buffer = self.dbg.read_process_memory(out_buffer_ptr,read_num_bytes)
            self.decoded_requests.append([filename,"READ",read_num_bytes,out_buffer])
            
            # Dumps the list to a file
            self.save_results()
            
    def write_file_exit(self,dbg,args,ret):
        """
        Traps calls to kernel32.WriteFile, and is only enabled
        if the self.read_write_enabled = True
        """
        
        h_file        = args[0]
        in_buffer_ptr = args[1]
        write_num_bytes= args[2]
        num_bytes_ret = args[3]
        
        try:
            filename    =    self.file_names[h_file]
        except:
            filename    =    "UNRESOLVED"
        
        # If we actually get some bytes returned by the call
        # then we want to trap them and add it to the global
        # list of decoded requests        
        if num_bytes_ret > 0:
            
            in_buffer = self.dbg.read_process_memory(in_buffer_ptr,write_num_bytes)
            self.decoded_requests.append([filename,"WRITE",in_buffer])
            
            # Dumps the list to a file
            self.save_results()
        
    def dev_ioctl_exit(self,dbg,args,ret):
        """
        Here we are trapping the actual IOCTL as it's finishing
        up. This is so we can determine whether to read the out_buffer
        or not based on the bytes returned by the call.
        """
        print "[*] IOCTL Trapped"
        h_device       = args[0]
        ioctl_code     = args[1]
        in_buffer_ptr  = args[2]
        in_buf_size    = args[3]
        out_buffer_ptr = args[4]
        out_buf_size   = args[5]
        bytes_returned = args[6]
                
        try:
            filename   = self.file_names[h_device]
        except:
            filename   = "UNRESOLVED"
            
        # If the input buffer size is greater than 0 then read it in
        if in_buf_size > 0:
            in_buf = self.dbg.read_process_memory(in_buffer_ptr,in_buf_size)
            print "In Buffer: %s" % in_buf.encode("HEX")
        else:
            in_buf = ""
            
        # Check for output
        if out_buf_size > 0 and bytes_returned > 0:
            out_buf = self.dbg.read_process_memory(out_buffer_ptr,out_buf_size)
            print "Out Buffer: %s" % out_buf.encode("HEX")
            
            self.decoded_requests.append([filename,"IOCTL",ioctl_code,in_buf,out_buf_size])
            
            # Save the results to the file
            self.save_results()
            
    def save_results(self):
        '''
        This function saves the trapped IOCTLs to a Python pickled
        file. The filename is specified when you first start up the 
        trap.
        '''
        
        # Dump this to the pickle, we do this every call
        # incase something goes sideways, at least we keep our
        # data. TODO: improve this ;)
        output_handle = open(self.output_file,"wb")
        cPickle.dump(self.decoded_requests,output_handle)
        output_handle.close()
        
        return
    
    def close_handle_entry(self,dbg,args):
        """
        Here we are removing the handle thats being closed
        from the global handle list.
        """
        try:
            # Remove the entry with the handle being closed
            del self.file_names[args[0]]
        except:
            pass
        
        return DBG_CONTINUE
        
        
    def create_file_exit(self,dbg,args,ret):
        """
        This is just hooking successful CreateFileW calls
        so that we can trap any reads/writes/ioctl requests
        to an actual filename. This is used by the fuzzer.
        """
        
        # If the CreateFileW didn't fail
        # then figure out the filename
        if ret != 0xffffffff:
            # This is my attempt at a unicode string reader
            double_null = False
            counter     = 0 
            clean_buf   = ""
            
            # We search in memory for a unicode null terminator
            while double_null == False:
                buffer = self.dbg.read_process_memory(args[0]+counter,32)
                if buffer is not None and buffer != 0:
                    match = buffer.find("\x00\x00")
        
                
                    if match != -1:
                        clean_buf += buffer[0:match]
                        double_null = True
                        break
                    else:
                        clean_buf += buffer
                        
                    print counter    
                    counter += 32
                else:
                    break    
                
            # Associate this handle with a filename
            # so that we can reference read/write/ioctl
            self.file_names[ret] = clean_buf
            
        return DBG_CONTINUE


mode        = raw_input("Select (P)ID or (O)pen Process:  ")

if mode.lower() == "p":
    pid         = raw_input("Enter Pid: ")
    output_file = raw_input("Output file (ex. wireshark.ioctl):")
    ioctl = ioctlizer(output_file,pid=int(pid),mode="attach")     

else:
    file_name   = raw_input("Enter executable path (ex. C:\\WINDOWS\\system32\\calc.exe):  ")
    output_file = raw_input("Output file (ex. wireshark.ioctl):")
    ioctl = ioctlizer(output_file,exec_path=file_name,mode="open")     

