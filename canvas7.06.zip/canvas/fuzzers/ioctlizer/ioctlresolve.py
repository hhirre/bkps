"""
(c) Immunity, Inc. 2004-2007


U{Immunity Inc.<http://www.immunityinc.com>}

"""
import getopt
import cPickle


from immutils        import * 
from immlib          import *

# Global flag whether we found the IOCTL
# dispatcher
found_dispatch      =    False

# functions that are suspected to have IOCTLs
# or at least know the whereabouts :)
target_funcs        =    []
possible_funcs      =    []

# Track any possible dispatch function pointers
dispatch_funcs      =    {}
rdispatch_funcs     =    {}
recursed_dispatch   =    False

# Global IOCTL lists
possible_ioctls     =    []
final_ioctls        =    []


def op_code_byte_match(op_code,imm):
    
    op_code_addr = op_code.getAddress()
    
    # Let's test for the bytes that actually
    # set the struct member 
    op_dump = op_code.getDump().split(" ")
    
    # We first try to match against the opcodes
    # which are in the form MOV DWORD PTR [REG+70], CONSTANT
    if len(op_dump) == 3:

        # if the first byte is C7 keep going
        if op_dump[0][0:2] == "C7" and op_dump[1][0:2] == "70":
            
            if dispatch_funcs.has_key(op_code_addr):
                pass
            else:
                dispatch_address = op_code.getOpData()[0]
                dispatch_funcs[op_code_addr] = dispatch_address
                imm.Log("[*] Possible opcode match: %s" % op_code.getDump(),op_code_addr)
                return True
        else:
            return False

    # Now let's try to match the trickier format of
    # MOV DWORD PTR DS:[REG+70], REG this means that if 
    # we get a hit, we have to disassemble backwards to find out
    # the value of the register, which will contain the function
    # pointer to the dispatcher
    if len(op_dump) == 2:
        
        if op_dump[0][0:2] == "89" and op_dump[1][0:2] == "70":
            
            register = op_code.getDisasm().split(",")[1]
                  
            if dispatch_funcs.has_key(op_code_addr):
                pass
            else:
                # Send this op_code off for some more processing
                resolve_register(op_code,register,imm)

def resolve_register(op_code,register,imm):
    
    # Now let's disassemble backwards looking for
    # MOV, MOVS, LEA to put the dispatch function
    # pointer into the register we are looking at
    found_match    = False
    disasm_address  = op_code.getAddress()
    
    while found_match == False:
        
        # Start working through the opcodes in reverse
        rev_op_code = imm.disasmBackward(disasm_address)
        disasm_address = rev_op_code.getAddress()
        
        rev_op_list = rev_op_code.getDump().split(" ")
        
        # Look for the MOV instruction for now, nothing
        # more sophisticated is needed as far as I can tell
        if rev_op_list[0][0:1] == "B":
            
            # Ok so we have hit a MOV instruction
            # now let's see if it is modifying the
            # register we want
            op_dis = rev_op_code.getDisasm().split(",")
            op_match = "MOV %s" % register
            
            # We have matched a possible MOV instruction
            # that has the value of our dispatch pointer
            if op_dis[0] == op_match:
                dispatch_address = rev_op_code.getOpData()[0]
                dispatch_funcs[op_code.getAddress()] = dispatch_address
                found_match = True


def check_jmp_const(jmp_const,func_list,imm):

    # I have seen some weirdness where a function will get
    # decoded at one address but the real entry point is a couple
    # bytes off. Let's take those rare cases and test for them
    if func_list.count(jmp_const) != 0:
        target_funcs.append(jmp_const)
    elif func_list.count(jmp_const + 2) != 0:
        target_funcs.append(jmp_const + 2)
    elif func_list.count(jmp_const - 2) != 0:
        target_funcs.append(jmp_const - 2)
    else:
        possible_funcs.append(jmp_const)

def enumerate_target_funcs(func_list,imm):
    
    # Maintain a list of the functions we have already
    # covered, we can end up with duplicates this will
    # prevent recursion problems
    resolved_funcs = {}
    
    for i in target_funcs:
        if resolved_funcs.has_key(i):
            pass
        else:
            dispatch_search(i,func_list,imm)
            resolved_funcs[i] = True
            
    for i in possible_funcs:
        if resolved_funcs.has_key(i):
            pass
        else:
            dispatch_search(i,func_list,imm)
            resolved_funcs[i] = True
            
def dispatch_search(entry_point,func_list,imm,flag=None,recursion=False):
    
    # Grab the function
    entry_func     = imm.getFunction(entry_point)
    
    # Let's grab a total instruction count so that
    # if we can't decode this first function properly
    # we give up :)
    inst_count = 0
    
    try:
        bb_list    = entry_func.getBasicBlocks()
    except:
        return
    
    for bb in bb_list:
        inst_count = inst_count + len(bb.getInstructions(imm))
    
    # Now start disassembling forward until we
    # either find a JMP/CALL or a MOV DWORD PTR etc
    counter        = 0
    disasm_address = entry_point
    
    op_code             =    None
    
    
    while counter <= inst_count:
        
        # Start disassembling forward from the beginning
        # of the function, although more typically you will
        # see the DRIVER_OBJECT assignment near the end of a
        # function I was having problems with libanalize not
        # correctly finding the end of a func...anyways
        op_code = imm.disasmForward(disasm_address)
        
        # Set this as the next disassembly point
        disasm_address = op_code.getAddress()
        
        if flag == None:
            # check to see if we are doing a JMP/CALL to another 
            # function inside our own driver, if we are then we 
            # will want to store it in the list of possible candidates
            jmp_const = op_code.getJmpConst()
                            
            if jmp_const != 0:
                check_jmp_const(jmp_const,func_list,imm)
            
            test = op_code_byte_match(op_code,imm)
            if test == True:
                break
        
        # We use the dispatch flag to look for constants 
        # that are being used in this instruction we also
        # have a check that will tell us if this dispatch function
        # just does a JMP/CALL to the "real" dispatch function
        elif flag == "dispatch":
            
            # Let's check to make sure we aren't being redirected
            # as well let's flag this function if one of the calls
            # is to CompleteIofRequest() that makes it the
            if recursion == False:
                if op_code.isJmp() is True or op_code.isCall() is True:
                        
                        # Make sure this is a JMP/CALL to an internal routine
                        # and not one that's in a system binary
                        jmp_addr = op_code.getJmpAddr()
                        module = imm.getModulebyAddress(jmp_addr)
        
                        if module is not None and imm.getDebuggedName() == module.name:
                            rdispatch_funcs[op_code.getAddress()] = jmp_addr
                        
            # Check if there is a constant used in this instruction
            # this isn't going to be 100% accurate, but the benefit
            # of getting too many IOCTLs is better than not catching
            # all of them
            if op_code.getOpData()[0] != 0:
                possible_ioctls.append(op_code)
            
        counter += 1
    
def final_op_code_match(op_code):
    
    first_op = op_code.getDisasm().split(" ")[0]
    if first_op == "CMP" or first_op == "SUB":
        
        ioctl = op_code.getOpData()[0]
        
        if final_ioctls.count(ioctl) == 0 and ioctl != 0xffffffff:
            final_ioctls.append(ioctl)
                    
def enumerate_dispatch(funcs,imm,flag=False):
     '''
     This will enumerate through the possible dispatch routines.
     The flag variable sets a recursion flag so that we aren't 
     adding entries to the dictionary of functions that we are 
     iterating over.
     '''
     
     for i in funcs.iteritems():
        
        imm.Log("[*] Dispatch Function at: %08x" % int(i[1]),int(i[1]))
        
        dispatch_search(int(i[1]),None,imm,flag="dispatch",recursion=flag)
        
        # We have narrowed the list of possible matches
        # down to opcodes with decodable constants now
        # let's apply some simple heuristsics, we want
        # SUB XYZ, CMP XYZ and that's it for now
        for i in possible_ioctls:
            
            # Send the opcode object off for analysis
            final_op_code_match(i)
        
        

def scan_dispatch(imm):
    
    #    TODO:
    #    If it really is the IO dispatch, then I think it should be 
    #    terminated by an IofCompleteRequest (IoCompleteRequest)
    #    I will put another check in there at some point to handle this
        
    # Now let's work through the dispatch function.
    # This can take some time, as generally they are 
    # freaking huge! Go grab a cup of coffee
    funcs = dispatch_funcs
    recurse_flag = False
   
    while len(final_ioctls) == 0:
        
        enumerate_dispatch(funcs,imm,flag=recurse_flag)
        
        # After we have recursed one level deep
        # let's break our analysis loop
        if recurse_flag == True:
            break
        
        # If we didn't even find a top-level dispatch
        # routine let's break out of the loop
        if len(dispatch_funcs) == 0:
            break
        
        # If we found that there could be a recursion into
        # the real dispatch function we want to pass it to 
        # our enumerator
        if len(rdispatch_funcs) > 0:
            
            # Let's iterate through our recursed list
            funcs = rdispatch_funcs
            
            # Set the flag so that the recursion doesn't 
            # clobber the dictionary we are iterating through
            recurse_flag = True
            
def usage( imm ):
    
    imm.Log("!ioctlresolve - Test case generator for ioclizer.py (c) Immunity")
    imm.Log("!ioctlresolve -o outputfile -d device")
    imm.Log("Ex:")
    imm.Log("!ioctlresolve -o driver.test -d \\\\.\\Global\\NPF_NdisWanIp")

    return

def main(args):
    imm = Debugger()
    
    if len(args) == 0:
        usage(imm)
        imm.updateLog()
        imm.createLogWindow()
        
        return "Incorrect Arguments"
    try:
        opts, argo = getopt.getopt(args, "o:d:")
    except getopt.GetoptError:
        usage(imm)          
        imm.updateLog()
        imm.createLogWindow()
        return "Incorrect Arguments"

    device_driver = ""
    output_file   = ""
    for o,a in opts:
        
        if o == "-o":
            output_file = a
        
        if o == "-d":
            device_driver = a
            
    imm.Log("%s" % args)
    imm.Log("%s" % output_file)
    imm.Log("[*] Starting driver analysis....")
    
    
    # First let's get a valid MODULE()
    driver = imm.getModule(imm.getDebuggedName())
    #imm.analyseCode(driver.getCodebase())
    func_list      = imm.getAllFunctions(driver.getCodebase())  
    
    # Grab the entry point this is where 
    # our analysis will begin
    entry_point = driver.getEntry()
    
    dispatch_search(entry_point,func_list,imm)
    
    if len(target_funcs) > 0 or found_dispatch == False:
        
        
        # Now let's enumerate our target functions
        # currently only recurse once, anything deeper 
        # and it's gonna take awhile
        enumerate_target_funcs(func_list,imm)
    
    # Now we have our list of possible dispatch functions
    # we needt to crawl into each of them looking for 
    # what could be IOCTL codes
    scan_dispatch(imm)
    
    imm.Log("[*] Analysis complete.")
    imm.createLogWindow()
    
    # Just output the final IOCTL list
    output_handle = open(output_file,"wb")
    #cPickle.dump(self.decoded_requests,output_handle)
    #output_handle.close()
    
    final_test_cases = []
    
    if len(final_ioctls) > 0:
        for i in final_ioctls:
            final_test_cases.append((device_driver,"0x%08x" % i))
            imm.Log("[*] IOCTL: 0x%08x" % i)
    else:
        imm.Log("[*] No IOCTL control codes could be found.")
    

    cPickle.dump(final_test_cases, output_handle)
    output_handle.close()
        
    return "Driver has been analyzed."
    