# Copyright Immunity Inc. blah blah blah
import asyncore
import asynchat
import socket
import struct


class debug_request( asynchat.async_chat ):
    
    def __init__(self, connection, address ):
        
        asynchat.async_chat.__init__(self, connection)
        self.inbuffer = []
        self.set_terminator("|")
        self.connection = connection
        self.address    = address
    
    def collect_incoming_data( self, data ):
        print data + "\r\n"
        self.inbuffer.append( data)
        
    
class debug_server(asyncore.dispatcher):

    def __init__(self, port):
        asyncore.dispatcher.__init__(self)
        self.port = port
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.bind(("", port))
        self.listen(5)
        print "listening on port", self.port

    def handle_accept(self):
        connection, address = self.accept()
        debug_request( connection, address )


if __name__ == "__main__":
    
    port = 8080
    server = debug_server( port )
    print "Started the debug server.....\n"
    
    try:
        asyncore.loop( timeout = 2 )
    except KeyboardInterrupt:
        print "Cancelled.\n"
        
