"""
(c) Immunity, Inc. 2004-2007


U{Immunity Inc.<http://www.immunityinc.com>}

"""
import struct
import sys
import getopt
import time
import random
import cPickle
import socket
from ctypes import *

kernel32 = windll.kernel32
psapi    = windll.psapi

# Defines for Win32 API Calls
GENERIC_READ    = 0x80000000
GENERIC_WRITE   = 0x40000000
OPEN_EXISTING   = 0x3

class ioctlizer:

    def __init__(self,test_case_list,num_iterations):
        
        self.max_array_size    =    30000            # This is used to allocate a buffer to hold all our device names
        self.sorted_devices    =    {}               # Creates a list of devices that we can access
        self.num_iterations    =    num_iterations   # Tracks the number of fuzzing iterations
        self.selected_device   =    None             # The currently selected device we are fuzzing
        self.disable_read      =    True             # If we didn't find any ReadFile test cases we disable them
        self.disable_write     =    True             # If we didn't find any WriteFile test cases we disable them
        
        # Test case management
        self.test_case_list    =    test_case_list   # The global test case list that we import from ioctltrap
        self.selected_test_case=    None             # Come on this is pretty self explanatory
        self.ioctl_requests    =    []               # The imported list of IOCTL requests from the pickled file.
        self.read_requests     =    []               # The imported list of ReadFile test cases
        self.write_requests    =    []               # The imported list of WriteFile test cases
        
        self.device_name       =    None
        self.iteration         =    0                # The current iteration the fuzzer is on
            
    def prepare_test_cases(self):
        """
        We need to separate the different modes of attack (read/write/ioctl).
        """

        # Setup the device name
        self.device_name = self.test_case_list[0][0]
        
        for i in self.test_case_list:
           print i[0]
           self.ioctl_requests.append( i[1] )
            
        if len(self.ioctl_requests) != 0:
            print "[*] Found %d IOCTL test cases." % len(self.ioctl_requests)
            raw_input("\r\n[*] Press any key to begin fuzzing....")
        else:
            print "[*] Sorry there were no good test cases to use. Try retrapping the process."
            sys.exit(2) 
        
    def enumerate_devices(self):
        """
        This will read through all of the registered devices.
        We need this information so that we can obtain file handles
        to each device for fuzzing.
        """
               
        # We want to enumerate all of the registered device
        # handles, as each of them is a fuzzable object.
        # However, we don't know which are accessible by a non-priv
        # user.
        device_array = (c_char * self.max_array_size)()
        
        # result will store the length of the bytes returned to our 
        # device array buffer. If we get zero and GetLastError returns
        # an 0x122 then we have to increase the size of the buffer
        result = kernel32.QueryDosDeviceA(None,byref(device_array),sizeof(device_array))
        
        # Test for success, fail on error
        if result > 0:
            names = device_array[:result].split("\x00")
            self.device_paths(names)
    
        elif result == 0 and kernel32.GetLastError() == 122:
            print "[*] We didn't allocate a big enough buffer. Try setting self.max_array_size to something larger."
            sys.exit(2)
            
    def device_paths(self,names):    
        """
        This just simply prints out all of the devices.
        It then asks the user which one it would like to fuzz.
        
        """
        counter = 0
        names.sort()
        
        for i in names:
            
            if i is not None and i != "":
                self.sorted_devices[i] = counter
                counter += 1
                print i

            
    def begin_fuzzing(self):
        """
        This will actually start the process of the fuzzination.
        Because this can be really volatile, it ships its test cases 
        off to the RPC server, as well as any returned memory reads.
        """
       
        while self.iteration < self.num_iterations:
            
            # For now we only do IOCTLs
            file_name = self.device_name
            
            print "\r\n[*****] Iteration: %d" % self.iteration
            device_file =  u"%s" % self.device_name  
            
            driver_handle = kernel32.CreateFileW(device_file, GENERIC_READ|GENERIC_WRITE,0,None,OPEN_EXISTING,0,None)
        
            if driver_handle != -1:
                # We move on to more interesting things now
                print "[*] Device: %s" % device_file
                print "[*] Device Handle Acquired: %08x" % driver_handle
                # I haven't received any feedback yet from Yuriy, so here
                # is what I propose: we randomize between reads, writes and IOCTL request.
                # We weight more heavily on the IOCTL requests however, until I have a better
                # idea of how to fuzz this.            
                self.mutator(driver_handle,3)
            else:
                
                print "[*] Cannot allocate a handle to this driver. Ensure it is enabled for access or that you have the right device path."

                error_code = kernel32.GetLastError()
                print "[*] Error Code: 0x%08x" % error_code
            
            
            # Close the handle
            kernel32.CloseHandle(driver_handle)
            
            print "[*****] Completed: %d" % self.iteration
            self.iteration += 1
            
    def mutator(self,driver_handle,mode):
        """
        This is what does the actual work of messing with
        the driver. Returns back to the main fuzzing loop.
        Dumb fuzzer so far, but let's see how it works!
        """
            
        if mode > 2:
            
            
            # We will randomly determine how to attack this IOCTL
            attack_list = [1,2,3,4,5,6]
            attack = random.shuffle(attack_list)
            attack = attack_list[0]
            
            # Store some information from the test case            
            ioctl_code     = int(self.ioctl_requests[random.randint(0,len(self.ioctl_requests)-1)],16)
            orig_buffer    = "A" * 250
            out_length     = len(orig_buffer)
            
            mutated_buffer = ""
            counter = 0
            # Take the same input buffer
            # and only flip non-zero values
            # leave size unchanged
            print attack
            if attack == 1:
                while counter < len(orig_buffer):
                    if orig_buffer[counter].encode("HEX") != "00":
                        mutated_buffer += struct.pack("H",random.getrandbits(8)).replace("\x00","",1)
                    else:
                        mutated_buffer += orig_buffer[counter]
                    counter += 1
            
            # Take the same input buffer
            # and flip all bytes randomly 
            # leave size unchanged
            if attack == 2:
                while counter < len(orig_buffer):
                    mutated_buffer += struct.pack("H",random.getrandbits(8)).replace("\x00","",1)
                    counter += 1
            
            # Take the same input buffer
            # and flip all bytes to 0x41 
            # leave size unchanged
            if attack == 3:
                mutated_buffer = "\x41" * len(orig_buffer)
            
            # Create a bigassed buffer
            # full of 0x41s
            if attack == 4:
                attack_length = random.randint(1,20000)
                mutated_buffer = "\x41" * attack_length
                out_length = attack_length
            
            # Here we flip all zero bytes to 0xff
            # leave size unchanged
            if attack == 5:
                while counter < len(orig_buffer):
                    if orig_buffer[counter].encode("HEX") == "00":
                        mutated_buffer += "\xff"
                    else:
                        mutated_buffer += orig_buffer[counter]
                    counter += 1
                    
            # Here we take the original request
            # then extend it by a random number of bytes
            if attack == 6:
                attack_length = random.randint(1,20000)
                attack_string = struct.pack("H",random.getrandbits(8)).replace("\x00","",1)
                final_attack  = attack_string * attack_length
                
                mutated_buffer = orig_buffer + final_attack
                out_length     = len(mutated_buffer)
            
            print "[*] Original Buffer (Truncated): %s " % orig_buffer[0:100].encode("HEX")
            print "[*] Mutated Buffer (Truncated):  %s" % mutated_buffer[0:100].encode("HEX")    
            
            sock = socket.socket( socket.AF_INET, socket.SOCK_STREAM )
            sock.connect(( "192.168.77.105", 8080 ))
            sock.send("IOCTL CODE TESTED: %s\n" % ioctl_code )
            sock.send("BUFFER: %s\n|" % mutated_buffer )
            sock.close()
                       
            
            time.sleep(1)
            
            # Now run the IOCTL
            out_buf = (c_char * out_length)()
            out_size = c_ulong(out_length)
            
            ret = kernel32.DeviceIoControl(driver_handle,ioctl_code,mutated_buffer,len(mutated_buffer),byref(out_buf),out_length,byref(out_size),None)
            
            if ret == 0:
                value = "NULL"
            else:
                value = out_buf.value[0:out_length].encode("HEX")
            
            print "[*] Returned from memory: %s" % value
            print "[*] IOCTL Code Used: 0x%08x" % ioctl_code
            
        
        
        
            
        
test_cases = "c:\driver4.test"      
num_iterations = 2000

try:
    file_handle = open(test_cases,"r")
except:
    print "[*] Sorry I couldn't find that file. Fixup your path!"

test_case_list = cPickle.load(file_handle)


ioctl = ioctlizer(test_case_list,num_iterations)
ioctl.enumerate_devices()
ioctl.prepare_test_cases()
ioctl.begin_fuzzing()

print "\r\n[*] All finished. Completed %d iterations." % ioctl.num_iterations
        

  