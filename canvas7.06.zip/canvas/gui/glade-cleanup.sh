#!/bin/bash
sed -i -e "s/swapped=\"no\"//g" ./canvasgui2_default.glade
