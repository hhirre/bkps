wget -c http://www.maxmind.com/download/geoip/database/GeoLiteCity.dat.gz
gunzip GeoLiteCity.dat.gz
#ubuntu
apt-get install python-geoip

