#run this as root!
yum install wget
wget -c http://www.maxmind.com/download/geoip/database/GeoLiteCity.dat.gz
gunzip GeoLiteCity.dat.gz
#ubuntu
yum install python-GeoIP

