import os
import re

properties = [
    'use_action_appearance',
    'primary_icon_activatable',
    'secondary_icon_activatable',
    'primary_icon_sensitive',
    'secondary_icon_sensitive',
    'invisible_char_set',
    ]

rx_template = '.*%s.*\n'

rx = re.compile('|'.join([rx_template % prop for prop in properties]))

files_stripped = 0
props_stripped = 0
for root, dirs, files in os.walk('.'):
    for fname in files:
        if '.glade' not in fname:
            continue
        path = os.path.join(root, fname)
        with open(path) as f:
            data = f.read()
            result, subs = rx.subn('', data)
        if subs:
            print '%*s: %s' % (5, subs, path)
            with open(path, 'w+') as f:
                f.write(result)
            files_stripped += 1
            props_stripped += subs

print
print 'files stripped:', files_stripped
print 'props stripped:', props_stripped
